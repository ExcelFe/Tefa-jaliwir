<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiswaXII extends Model
{
    protected $table = 'tb_murid_xii';
    protected $primaryKey = 'nis_xii';
    public $timestamps = false;

    protected $fillable = [
        'nis_xii',
        'nama',
        'absen',
        'kelamin',
        'kelas',
    ];
}

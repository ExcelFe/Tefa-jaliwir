<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class AkunGuru extends Authenticatable
{
    use Notifiable;

    protected $table = 'tb_akun_guru';
    public $timestamps = false;

    protected $fillable = [
        'kode_guru',
        'email',
        'password',
    ];

    protected $hidden = [
        'password',
    ];

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'kode_guru', 'kode_guru');
    }

    public function getNamaAttribute(): string
    {
        return $this->guru?->nama ?? $this->email;
    }

    public function getMapelAttribute(): string
    {
        return $this->guru?->mapel ?? '-';
    }
}

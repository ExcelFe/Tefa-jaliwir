<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiswaXI extends Model
{
    protected $table = 'tb_murid_xi';
    protected $primaryKey = 'nis_xi';
    public $timestamps = false;

    protected $fillable = [
        'nis_xi',
        'nama',
        'absen',
        'kelamin',
        'kelas',
    ];
}

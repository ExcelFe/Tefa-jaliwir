<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Guru extends Model
{
    protected $table = 'tb_guru';
    protected $primaryKey = 'kode_guru';
    public $timestamps = false;

    protected $fillable = [
        'kode_guru',
        'nama',
        'mapel',
        'kelamin',
        'tugas_tambahan',
    ];

    public function akun()
    {
        return $this->hasOne(AkunGuru::class, 'kode_guru', 'kode_guru');
    }

    public function jadwal()
    {
        return $this->hasMany(MapelGuru::class, 'kode_guru', 'kode_guru');
    }

    public function jurnal()
    {
        return $this->hasMany(Jurnal::class, 'kode_guru', 'kode_guru');
    }
}
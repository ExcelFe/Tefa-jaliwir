<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Jurnal extends Model
{
    protected $table = 'tb_jurnal';
    public $timestamps = false;

    protected $fillable = [
        'kode_guru',
        'kelas',
        'tanggal',
        'jam_sekolah',
        'nama_mapel',
        'sub_kompetensi',
        'pertemuan',
        'keterangan',
    ];

    public function guru()
    {
        return $this->belongsTo(Guru::class, 'kode_guru', 'kode_guru');
    }
}

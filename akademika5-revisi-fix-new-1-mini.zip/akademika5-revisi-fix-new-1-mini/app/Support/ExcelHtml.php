<?php

namespace App\Support;

/**
 * Pembuat file Excel (.xls berbasis tabel HTML), sama seperti rekap absensi siswa di dashboard guru.
 * Tidak membutuhkan library tambahan.
 */
class ExcelHtml
{
    /** Escape teks sel agar aman. */
    public static function e($nilai): string
    {
        return htmlspecialchars((string) $nilai, ENT_QUOTES, 'UTF-8');
    }

    /** Bungkus isi (judul, meta, tabel) menjadi dokumen HTML yang dibuka Excel. */
    public static function dokumen(string $isi): string
    {
        $html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        $html .= '<head><meta charset="utf-8">';
        $html .= '<style>
            table { border-collapse: collapse; font-family: Arial, sans-serif; }
            th { background-color: #1e3a8a; color: #ffffff; border: 1px solid #94a3b8; padding: 8px 12px; font-weight: bold; text-align: center; vertical-align: middle; }
            td { border: 1px solid #cbd5e1; padding: 6px 10px; vertical-align: top; }
            .center { text-align: center; }
            .left { text-align: left; }
            .hadir { background-color: #dcfce7; color: #15803d; font-weight: bold; }
            .sakit { background-color: #ede9fe; color: #6d28d9; font-weight: bold; }
            .izin { background-color: #fef9c3; color: #a16207; font-weight: bold; }
            .alpa { background-color: #fee2e2; color: #b91c1c; font-weight: bold; }
            .title { font-size: 16pt; font-weight: bold; text-align: center; margin-bottom: 4px; }
            .meta { font-size: 10pt; color: #475569; text-align: center; margin-bottom: 12px; }
            .kosong { text-align: center; color: #64748b; font-style: italic; }
        </style>';
        $html .= '</head><body>' . $isi . '</body></html>';

        return $html;
    }

    /** Kirim sebagai unduhan Excel. */
    public static function unduh(string $html, string $namaFile)
    {
        return response($html, 200, [
            'Content-Type'        => 'application/vnd.ms-excel; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="' . $namaFile . '"',
            'Cache-Control'       => 'max-age=0',
        ]);
    }
}

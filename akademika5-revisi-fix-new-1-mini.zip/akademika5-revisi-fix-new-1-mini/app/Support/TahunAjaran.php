<?php

namespace App\Support;

use Carbon\Carbon;

/**
 * Tahun ajaran berjalan dari Juli sampai Juni.
 * Contoh: 29 Okt 2026 -> 2026/2027, 15 Mar 2027 -> 2026/2027.
 */
class TahunAjaran
{
    /** Tahun mulai tahun ajaran untuk sebuah tanggal. */
    public static function tahunMulai(?Carbon $tanggal = null): int
    {
        $tanggal = $tanggal ?? Carbon::now('Asia/Makassar');

        return $tanggal->month >= 7 ? $tanggal->year : $tanggal->year - 1;
    }

    /** Label seperti "2026/2027". */
    public static function label(?int $tahunMulai = null): string
    {
        $tahunMulai = $tahunMulai ?? self::tahunMulai();

        return $tahunMulai . '/' . ($tahunMulai + 1);
    }

    /** Batas tanggal tahun ajaran: [awal, akhir] dalam format Y-m-d. */
    public static function rentang(?int $tahunMulai = null): array
    {
        $tahunMulai = $tahunMulai ?? self::tahunMulai();

        return [$tahunMulai . '-07-01', ($tahunMulai + 1) . '-06-30'];
    }

    /** Semester berjalan untuk sebuah tanggal: 1 = Ganjil (Juli-Desember), 2 = Genap (Januari-Juni). */
    public static function semester(?Carbon $tanggal = null): int
    {
        $tanggal = $tanggal ?? Carbon::now('Asia/Makassar');

        return $tanggal->month >= 7 ? 1 : 2;
    }

    /** Nama semester: "Ganjil" atau "Genap". */
    public static function namaSemester(int $semester): string
    {
        return $semester === 1 ? 'Ganjil' : 'Genap';
    }

    /**
     * Enam bulan dalam satu semester sebagai daftar [tahun, bulan].
     * Ganjil: Juli-Desember tahun mulai. Genap: Januari-Juni tahun berikutnya.
     */
    public static function bulanSemester(int $tahunMulai, int $semester): array
    {
        $bulan = [];
        if ($semester === 1) {
            for ($m = 7; $m <= 12; $m++) {
                $bulan[] = [$tahunMulai, $m];
            }
        } else {
            for ($m = 1; $m <= 6; $m++) {
                $bulan[] = [$tahunMulai + 1, $m];
            }
        }

        return $bulan;
    }

    /** Batas tanggal semester: [awal, akhir] dalam format Y-m-d. */
    public static function rentangSemester(int $tahunMulai, int $semester): array
    {
        $bulan = self::bulanSemester($tahunMulai, $semester);
        [$tAwal, $mAwal] = $bulan[0];
        [$tAkhir, $mAkhir] = $bulan[5];

        return [
            Carbon::create($tAwal, $mAwal, 1)->startOfMonth()->toDateString(),
            Carbon::create($tAkhir, $mAkhir, 1)->endOfMonth()->toDateString(),
        ];
    }

    /** Nama bulan Indonesia (1-12). */
    public static function namaBulan(int $bulan): string
    {
        $nama = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
        ];

        return $nama[$bulan] ?? '';
    }

    /**
     * Daftar tahun mulai tahun ajaran yang dipilih di form unduhan:
     * dari tahun ajaran data tertua (bila ada) sampai tahun ajaran berjalan, terbaru di atas.
     */
    public static function opsiTahunMulai(?string $tanggalTertua = null): array
    {
        $sekarang = self::tahunMulai();
        $awal = $sekarang;

        if ($tanggalTertua) {
            try {
                $awal = min($sekarang, self::tahunMulai(Carbon::parse($tanggalTertua)));
            } catch (\Exception $e) {
                $awal = $sekarang;
            }
        }

        return range($sekarang, $awal);
    }
}

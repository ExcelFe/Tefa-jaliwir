<?php

namespace App\Support;

/**
 * Pemetaan kode_guru (tb_guru) ke file foto di public/media/profil.
 * Guru yang belum punya foto akan memakai placeholder di tampilan.
 */
class FotoGuru
{
    private const PETA = [
        1  => 'manajemen/kepalasekolah.jpg',
        2  => 'manajemen/wakakurikulum.jpeg',
        3  => 'manajemen/wakasarpras.jpeg',
        4  => 'manajemen/wakahumas.jpeg',
        5  => 'manajemen/wakakesiswaan.jpeg',
        6  => 'kaprog/kaprogpplg.jpeg',
        7  => 'kaprog/kaprogdkv.jpeg',
        8  => 'kaprog/kaprogtjkt.jpeg',
        9  => 'kaprog/kaprogbd.jpeg',
        11 => 'staff/assmarkom.jpeg',
        12 => 'produktif/darmamatik.jpeg',
        13 => 'produktif/muliawanpenjas.jpeg',
        14 => 'produktif/murniproduktif.jpeg',
        15 => 'produktif/kantianimatik.jpeg',
        16 => 'produktif/yanpancasila.jpeg',
        17 => 'produktif/ratihpkwu.jpeg',
        18 => 'produktif/ditaipas.jpeg',
        19 => 'produktif/lalaipas.jpeg',
        20 => 'produktif/sinthyabing.jpeg',
        21 => 'produktif/wahyuproduktif.jpeg',
        22 => 'produktif/candrabindo.jpeg',
        23 => 'produktif/imeldajapan.jpeg',
        24 => 'produktif/oktiabing.jpeg',
        25 => 'produktif/thessaproduktif.jpeg',
        26 => 'produktif/bintabindo.jpeg',
        27 => 'produktif/samsulislam.jpeg',
        28 => 'produktif/ratnasenibudaya.jpeg',
        29 => 'produktif/meirahindu.jpeg',
        30 => 'staff/urusankesiswaan.jpeg',
        31 => 'staff/asslab.jpeg',
        32 => 'kaprog/kaprogdkv.jpeg',
        34 => 'produktif/masrikristen.jpeg',
        35 => 'staff/kepalatatausaha.jpeg',
    ];

    /**
     * URL foto guru, atau null jika tidak ada fotonya.
     */
    public static function url($kodeGuru): ?string
    {
        if ($kodeGuru === null || !isset(self::PETA[(int) $kodeGuru])) {
            return null;
        }

        $path = 'media/profil/' . self::PETA[(int) $kodeGuru];

        return file_exists(public_path($path)) ? asset($path) : null;
    }

    /** Inisial nama untuk placeholder bila foto belum ada. */
    public static function inisial(?string $nama): string
    {
        $nama = trim((string) $nama);
        if ($nama === '') {
            return '?';
        }

        return mb_strtoupper(mb_substr($nama, 0, 1));
    }
}

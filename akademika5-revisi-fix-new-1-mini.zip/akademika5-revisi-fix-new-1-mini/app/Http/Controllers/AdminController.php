<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Support\ExcelHtml;
use App\Support\TahunAjaran;

class AdminController extends Controller
{
    /** Diubah oleh turunan (rekap untuk guru piket) */
    protected bool $izinkanGuru = false;
    protected string $viewRekapGuru = 'admin.admin-rekap-guru';
    protected string $viewRekapJurnal = 'admin.admin-rekap-jurnal';

    /** Map nama hari Indonesia */
    private $daftarHari = [
        1 => 'senin',
        2 => 'selasa',
        3 => 'rabu',
        4 => 'kamis',
        5 => 'jumat',
    ];

    /** Helper: format DATE ke bahasa Indonesia */
    protected function formatTanggalIndo(string $dateStr): string
    {
        return PiketAbsenController::formatTanggalIndo($dateStr);
    }

    /** Helper cek akses admin */
    protected function checkAdmin()
    {
        if (!session('sudah_login')) {
            return false;
        }
        $jenis = session('jenis_akun');

        return $jenis === 'admin' || ($this->izinkanGuru && $jenis === 'guru');
    }

    // =========================================================================
    // 1. STATUS GURU (Melihat status kehadiran & mengajar semua guru secara real-time)
    // =========================================================================
    public function status(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $now = Carbon::now('Asia/Makassar');
        $hariDb = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';

        $tanggalPilihan = $request->query('tanggal', $now->toDateString());
        $tanggalFormatted = $this->formatTanggalIndo($tanggalPilihan);

        $guruList = DB::table('tb_guru')->orderBy('kode_guru')->get();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggalPilihan)
            ->get()
            ->keyBy('kode_guru');

        $jadwalHariIni = DB::table('tb_mapel_guru')
            ->where('hari', $hariDb)
            ->orderBy('jam_mulai')
            ->get()
            ->groupBy('kode_guru');

        $jamMenitSekarang = (float) $now->format('H.i');

        $isToday = ($tanggalPilihan === $now->toDateString());
        if ($absenDb->isEmpty() && !$isToday) {
            $dataGuru = collect();
        } else {
            $dataGuru = $guruList->map(function ($guru) use ($absenDb, $jadwalHariIni, $jamMenitSekarang, $tanggalFormatted) {
                $absen = $absenDb[$guru->kode_guru] ?? null;
                $statusRaw = $absen ? strtoupper($absen->status) : null;

                $statusText = match ($statusRaw) {
                    'H'      => 'Hadir',
                    'I'      => 'Izin',
                    'S'      => 'Sakit',
                    'A', 'T' => 'Alpa',
                    default  => 'Belum Diabsen',
                };
                $isHadir = ($statusText === 'Hadir');

                $jadwalGuru = $jadwalHariIni->get($guru->kode_guru, collect());
                $sedangNgajar = null;
                foreach ($jadwalGuru as $j) {
                    $mulai   = (float) str_replace(':', '.', $j->jam_mulai);
                    $selesai = (float) str_replace(':', '.', $j->jam_selesai);
                    if ($jamMenitSekarang >= $mulai && $jamMenitSekarang <= $selesai) {
                        $sedangNgajar = $j->nama_mapel . ' di ' . $j->kelas . ' (' . $j->waktu_pelajaran . ')';
                        break;
                    }
                }

                if (!$sedangNgajar) {
                    $sedangNgajar = $jadwalGuru->isNotEmpty()
                        ? 'Tidak sedang mengajar (' . $jadwalGuru->count() . ' jam hari ini)'
                        : 'Tidak ada jadwal mengajar hari ini';
                }

                return (object) [
                    'kode_guru'         => $guru->kode_guru,
                    'nama'              => $guru->nama,
                    'mapel'             => $guru->mapel ?: '-',
                    'status'            => $statusText,
                    'is_hadir'          => $isHadir,
                    'sedang_ngajar'     => $sedangNgajar,
                    'tanggal_formatted' => $tanggalFormatted,
                ];
            });
        }

        return view('admin.admin-status', compact(
            'dataGuru',
            'tanggalPilihan',
            'tanggalFormatted'
        ));
    }

    // =========================================================================
    // 2. GURU PIKET & GURU PIKET PENGGANTI (Real-time jadwal & penugasan pengganti)
    // =========================================================================
    public function piket(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $now = Carbon::now('Asia/Makassar');
        $hariIni = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';
        $tanggalHariIni = $now->toDateString();
        $tanggalFormatted = $this->formatTanggalIndo($tanggalHariIni);
        $jamMenitSekarang = (float) $now->format('H.i');

        // Tentukan shift aktif saat ini
        $shiftAktif = ($jamMenitSekarang >= 12.30) ? 'siang' : 'pagi';

        // Ambil semua jadwal tetap piket (tb_guru_piket)
        $semuaJadwalPiket = DB::table('tb_guru_piket')
            ->join('tb_guru', 'tb_guru_piket.kode_guru', '=', 'tb_guru.kode_guru')
            ->select('tb_guru_piket.*', 'tb_guru.nama as nama_guru', 'tb_guru.mapel as mapel_guru')
            ->orderByRaw("FIELD(tb_guru_piket.hari, 'senin', 'selasa', 'rabu', 'kamis', 'jumat')")
            ->orderBy('tb_guru_piket.id')
            ->get();

        // Cari guru piket asli untuk hari ini
        $piketHariIniRows = $semuaJadwalPiket->where('hari', $hariIni);

        // Ambil penugasan piket pengganti aktif untuk hari ini
        $penggantiHariIni = DB::table('tb_piket_pengganti')
            ->join('tb_guru', 'tb_piket_pengganti.kode_guru', '=', 'tb_guru.kode_guru')
            ->leftJoin('tb_guru as guru_asli', 'tb_piket_pengganti.kode_guru_asli', '=', 'guru_asli.kode_guru')
            ->whereDate('tb_piket_pengganti.tanggal', $tanggalHariIni)
            ->select(
                'tb_piket_pengganti.*',
                'tb_guru.nama as nama_pengganti',
                'tb_guru.mapel as mapel_pengganti',
                'guru_asli.nama as nama_asli'
            )
            ->get();

        // Tentukan guru piket yang sedang bertugas saat ini
        $piketAktif = null;
        $piketHariIniAktif = $piketHariIniRows->first(function ($p) use ($shiftAktif) {
            return str_contains(strtolower($p->waktu), $shiftAktif);
        }) ?? $piketHariIniRows->first();

        // Cek apakah ada pengganti untuk shift ini atau tanggal ini
        $penggantiAktif = $penggantiHariIni->first(function ($p) use ($shiftAktif) {
            return $p->shift === 'semua' || strtolower($p->shift) === $shiftAktif;
        });

        if ($penggantiAktif) {
            $piketAktif = (object) [
                'nama'          => $penggantiAktif->nama_pengganti,
                'mapel'         => $penggantiAktif->mapel_pengganti,
                'status_label'  => 'Guru Piket Pengganti',
                'waktu_tugas'   => $piketHariIniAktif ? $piketHariIniAktif->waktu : '07.00 - 17.15',
                'is_pengganti'  => true,
                'pengganti_id'  => $penggantiAktif->id,
                'keterangan'    => $penggantiAktif->keterangan ?? 'Menggantikan ' . ($penggantiAktif->nama_asli ?? 'guru piket'),
            ];
        } elseif ($piketHariIniAktif) {
            $piketAktif = (object) [
                'nama'          => $piketHariIniAktif->nama_guru,
                'mapel'         => $piketHariIniAktif->mapel_guru,
                'status_label'  => 'Guru Piket Terjadwal (' . ucfirst($shiftAktif) . ')',
                'waktu_tugas'   => $piketHariIniAktif->waktu,
                'is_pengganti'  => false,
                'kode_guru'     => $piketHariIniAktif->kode_guru,
                'keterangan'    => 'Bertugas sesuai jadwal tetap ' . ucfirst($hariIni),
            ];
        }

        // Daftar semua guru untuk pilihan dropdown pengganti
        $daftarSemuaGuru = DB::table('tb_guru')->orderBy('nama')->get();

        return view('admin.admin-piket', compact(
            'piketAktif',
            'semuaJadwalPiket',
            'penggantiHariIni',
            'daftarSemuaGuru',
            'tanggalFormatted',
            'hariIni',
            'shiftAktif'
        ));
    }

    /** Simpan Guru Piket Pengganti (Admin menugaskan guru lain) */
    public function simpanPiketPengganti(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $request->validate([
            'kode_guru' => 'required|integer',
            'tanggal'   => 'required|date',
            'shift'     => 'nullable|string',
            'keterangan'=> 'nullable|string',
        ]);

        $kodeGuru = (int) $request->input('kode_guru');
        $tanggal  = $request->input('tanggal');
        $shift    = $request->input('shift', 'semua');
        $ket      = $request->input('keterangan', 'Ditugaskan oleh Admin karena guru piket berhalangan');

        // Cari guru piket asli untuk hari dari tanggal tersebut
        $dt = Carbon::parse($tanggal);
        $hariName = $this->daftarHari[$dt->dayOfWeekIso] ?? 'senin';
        $piketAsliRow = DB::table('tb_guru_piket')
            ->where('hari', $hariName)
            ->first();
        $kodeGuruAsli = $piketAsliRow ? $piketAsliRow->kode_guru : null;

        DB::table('tb_piket_pengganti')->insert([
            'kode_guru'       => $kodeGuru,
            'tanggal'         => $tanggal,
            'shift'           => $shift,
            'kode_guru_asli'  => $kodeGuruAsli,
            'keterangan'      => $ket,
            'created_at'      => now(),
            'updated_at'      => now(),
        ]);

        $guruRow = DB::table('tb_guru')->where('kode_guru', $kodeGuru)->first();
        $nama = $guruRow ? $guruRow->nama : 'Guru';

        return redirect()->route('admin.piket')->with('success', "Akses guru piket pengganti berhasil diberikan kepada {$nama}. Notifikasi akses telah dikirimkan ke dashboard guru terkait.");
    }

    /** Batalkan Akses Guru Piket Pengganti */
    public function batalPiketPengganti($id)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        DB::table('tb_piket_pengganti')->where('id', $id)->delete();

        return redirect()->route('admin.piket')->with('success', 'Akses guru piket pengganti berhasil dibatalkan.');
    }

    // =========================================================================
    // 3. REKAP SISWA (Detail per kelas & per tanggal, tabel terperinci)
    // =========================================================================
    public function rekapSiswa(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $allKelas = array_values(array_unique(array_merge(
            DB::table('tb_murid_x')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xi')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xii')->distinct()->pluck('kelas')->toArray()
        )));

        $kelasPilihan = $request->query('kelas', $allKelas[0] ?? 'X PPLG 1');
        $tanggalPilihan = $request->query('tanggal', date('Y-m-d'));
        $tanggalFormatted = $this->formatTanggalIndo($tanggalPilihan);

        $tingkat = 'X';
        if (str_starts_with($kelasPilihan, 'XII ') || $kelasPilihan === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelasPilihan, 'XI ') || $kelasPilihan === 'XI') {
            $tingkat = 'XI';
        }

        $tabelMurid = match ($tingkat) {
            'XI'  => 'tb_murid_xi',
            'XII' => 'tb_murid_xii',
            default => 'tb_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };
        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };

        // Ambil daftar siswa kelas tersebut
        $muridList = DB::table($tabelMurid)
            ->where('kelas', $kelasPilihan)
            ->orderBy('absen')
            ->orderBy('nama')
            ->get();

        // Ambil data absensi tanggal tersebut
        $absenDb = DB::table($tabelAbsen)
            ->where('tanggal', $tanggalPilihan)
            ->get()
            ->keyBy($nisCol);

        $totalHadir = 0;
        $totalSakit = 0;
        $totalIzin = 0;
        $totalAlpa = 0;

        // Jika pada tanggal tersebut belum ada presensi di database, jangan generate data dummy!
        if ($absenDb->isEmpty()) {
            $daftarPresensi = collect();
        } else {
            $daftarPresensi = $muridList->map(function ($m, $idx) use ($nisCol, $absenDb, &$totalHadir, &$totalSakit, &$totalIzin, &$totalAlpa) {
                $nis = $m->$nisCol;
                $absen = $absenDb[$nis] ?? null;
                $statusRaw = $absen ? strtoupper($absen->status) : null;

                $statusText = match ($statusRaw) {
                    'H' => 'Hadir',
                    'S' => 'Sakit',
                    'I' => 'Izin',
                    'A' => 'Alpa',
                    default => 'Belum Diabsen',
                };

                match ($statusText) {
                    'Hadir' => $totalHadir++,
                    'Sakit' => $totalSakit++,
                    'Izin'  => $totalIzin++,
                    'Alpa'  => $totalAlpa++,
                    default => null,
                };

                return (object) [
                    'nis'     => $nis,
                    'no'      => $m->absen ?: ($idx + 1),
                    'nama'    => $m->nama,
                    'status'  => $statusText,
                    'catatan' => $absen ? ($absen->catatan ?? '-') : '-',
                ];
            });
        }

        // Ringkasan per semua kelas untuk overview
        $overviewKelas = [];
        foreach ($allKelas as $k) {
            $t = (str_starts_with($k, 'XII ') || $k === 'XII') ? 'XII' : ((str_starts_with($k, 'XI ') || $k === 'XI') ? 'XI' : 'X');
            $tm = match ($t) { 'XI' => 'tb_murid_xi', 'XII' => 'tb_murid_xii', default => 'tb_murid_x' };
            $cnt = DB::table($tm)->where('kelas', $k)->count();
            $overviewKelas[] = (object) ['kelas' => $k, 'total_siswa' => $cnt];
        }

        return view('admin.admin-rekap-siswa', compact(
            'allKelas',
            'kelasPilihan',
            'tanggalPilihan',
            'tanggalFormatted',
            'daftarPresensi',
            'totalHadir',
            'totalSakit',
            'totalIzin',
            'totalAlpa',
            'overviewKelas'
        ));
    }

    // =========================================================================
    // 4. REKAP GURU (Detail absensi guru per tanggal terperinci)
    // =========================================================================
    public function rekapGuru(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $tanggalPilihan = $request->query('tanggal', date('Y-m-d'));
        $tanggalFormatted = $this->formatTanggalIndo($tanggalPilihan);

        $guruList = DB::table('tb_guru')->orderBy('nama')->get();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggalPilihan)
            ->get()
            ->keyBy('kode_guru');

        $totalHadir = 0;
        $totalSakit = 0;
        $totalIzin = 0;
        $totalAlpa = 0;

        // Jika pada tanggal tersebut tidak ada data absensi di DB, jangan generate data dummy!
        if ($absenDb->isEmpty()) {
            $daftarGuruAbsen = collect();
        } else {
            $daftarGuruAbsen = $guruList->map(function ($guru, $idx) use ($absenDb, &$totalHadir, &$totalSakit, &$totalIzin, &$totalAlpa) {
                $absen = $absenDb[$guru->kode_guru] ?? null;
                $statusRaw = $absen ? strtoupper($absen->status) : null;

                $statusText = match ($statusRaw) {
                    'H' => 'Hadir',
                    'S' => 'Sakit',
                    'I' => 'Izin',
                    'A' => 'Alpa',
                    default => 'Belum Diabsen',
                };

                match ($statusText) {
                    'Hadir'       => $totalHadir++,
                    'Sakit'       => $totalSakit++,
                    'Izin'        => $totalIzin++,
                    'Alpa'        => $totalAlpa++,
                    default       => null,
                };

                return (object) [
                    'no'        => $idx + 1,
                    'kode_guru' => $guru->kode_guru,
                    'nama'      => $guru->nama,
                    'mapel'     => $guru->mapel ?: '-',
                    'status'    => $statusText,
                    'catatan'   => $absen ? ($absen->catatan ?? '-') : '-',
                ];
            });
        }

        // Opsi unduhan rekap semester (Excel)
        $opsiTahun = TahunAjaran::opsiTahunMulai(DB::table('tb_absen_guru')->min('tanggal'));
        $tahunDefault = TahunAjaran::tahunMulai();
        $semesterDefault = TahunAjaran::semester();

        return view($this->viewRekapGuru, compact(
            'tanggalPilihan',
            'tanggalFormatted',
            'daftarGuruAbsen',
            'totalHadir',
            'totalSakit',
            'totalIzin',
            'totalAlpa',
            'opsiTahun',
            'tahunDefault',
            'semesterDefault'
        ));
    }

    // =========================================================================
    // 5. REKAP JURNAL (Melihat rekapan seluruh jurnal mengajar guru dengan filter tanggal/kelas)
    // =========================================================================
    public function rekapJurnal(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $allKelas = array_values(array_unique(array_merge(
            DB::table('tb_murid_x')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xi')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xii')->distinct()->pluck('kelas')->toArray()
        )));

        $kelasPilihan   = $request->query('kelas', '');
        $tanggalPilihan = $request->query('tanggal', '');
        $search         = trim($request->query('q', ''));

        $query = DB::table('tb_jurnal')
            ->join('tb_guru', 'tb_jurnal.kode_guru', '=', 'tb_guru.kode_guru')
            ->select('tb_jurnal.*', 'tb_guru.nama as nama_guru')
            ->orderByDesc('tb_jurnal.tanggal')
            ->orderByDesc('tb_jurnal.jam_sekolah');

        if (!empty($kelasPilihan)) {
            $query->where('tb_jurnal.kelas', $kelasPilihan);
        }
        if (!empty($tanggalPilihan)) {
            $query->whereDate('tb_jurnal.tanggal', $tanggalPilihan);
        }
        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('tb_guru.nama', 'like', "%{$search}%")
                  ->orWhere('tb_jurnal.nama_mapel', 'like', "%{$search}%")
                  ->orWhere('tb_jurnal.sub_kompetensi', 'like', "%{$search}%");
            });
        }

        $jurnals = $query->paginate(25)->through(function ($j) {
            $j->tanggal_formatted = $this->formatTanggalIndo($j->tanggal);
            return $j;
        });

        // Opsi unduhan rekap jurnal (Excel)
        $opsiTahun = TahunAjaran::opsiTahunMulai(DB::table('tb_jurnal')->min('tanggal'));
        $tahunDefault = TahunAjaran::tahunMulai();

        return view($this->viewRekapJurnal, compact(
            'jurnals',
            'allKelas',
            'kelasPilihan',
            'tanggalPilihan',
            'search',
            'opsiTahun',
            'tahunDefault'
        ));
    }

    // =========================================================================
    // 6. EXPORT EXCEL: REKAP KEHADIRAN GURU PER SEMESTER (6 BULAN)
    // =========================================================================
    public function exportRekapGuru(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        // Tahun ajaran (tahun mulai, Juli-Juni) dan semester: 1 = Ganjil (Jul-Des), 2 = Genap (Jan-Jun)
        $tahunQuery = $request->query('tahun');
        $tahunMulai = (is_string($tahunQuery) && preg_match('/^\d{4}$/', $tahunQuery))
            ? (int) $tahunQuery
            : TahunAjaran::tahunMulai();

        $semesterQuery = $request->query('semester');
        $semester = in_array($semesterQuery, ['1', '2'], true)
            ? (int) $semesterQuery
            : TahunAjaran::semester();

        $namaSemester = TahunAjaran::namaSemester($semester);
        $labelTA = TahunAjaran::label($tahunMulai);
        $bulanList = TahunAjaran::bulanSemester($tahunMulai, $semester);
        [$awal, $akhir] = TahunAjaran::rentangSemester($tahunMulai, $semester);

        $guruList = DB::table('tb_guru')->orderBy('nama')->get();

        // Hitung per guru per bulan dengan status H/S/I/A
        $rekap = [];
        $absenRows = DB::table('tb_absen_guru')
            ->whereBetween('tanggal', [$awal, $akhir])
            ->select('kode_guru', 'tanggal', 'status')
            ->get();

        foreach ($absenRows as $row) {
            $status = strtoupper((string) $row->status);
            if ($status === 'T') {
                $status = 'A';
            }
            if (!in_array($status, ['H', 'S', 'I', 'A'], true)) {
                continue;
            }

            $kunciBulan = substr((string) $row->tanggal, 0, 7); // Y-m
            $rekap[$row->kode_guru][$kunciBulan][$status] = ($rekap[$row->kode_guru][$kunciBulan][$status] ?? 0) + 1;
        }

        $e = fn ($v) => ExcelHtml::e($v);

        $jumlahKolom = 3 + (count($bulanList) * 4) + 4 + 2;
        $html = '<div class="title">REKAPITULASI KEHADIRAN GURU - SEMESTER ' . $e(strtoupper($namaSemester)) . '</div>';
        $html .= '<div class="meta"><strong>Tahun Ajaran ' . $e($labelTA) . '</strong> | Periode: '
            . $e(date('d/m/Y', strtotime($awal))) . ' - ' . $e(date('d/m/Y', strtotime($akhir))) . ' (6 bulan)</div>';
        $html .= '<div class="meta">SMK TI Bali Global Badung | Diunduh pada: ' . $e(date('d/m/Y H:i')) . ' WITA</div>';

        $html .= '<table><thead>';
        $html .= '<tr>';
        $html .= '<th rowspan="2" style="width: 40px;">No.</th>';
        $html .= '<th rowspan="2" style="width: 260px;">Nama Guru</th>';
        $html .= '<th rowspan="2" style="width: 200px;">Mata Pelajaran</th>';
        foreach ($bulanList as [$tahunBulan, $bulan]) {
            $html .= '<th colspan="4">' . $e(TahunAjaran::namaBulan($bulan) . ' ' . $tahunBulan) . '</th>';
        }
        $html .= '<th colspan="4">Total Semester</th>';
        $html .= '<th rowspan="2" style="width: 90px;">Total Hari</th>';
        $html .= '<th rowspan="2" style="width: 100px;">Kehadiran (%)</th>';
        $html .= '</tr><tr>';
        foreach ($bulanList as $_) {
            $html .= '<th style="width: 45px;">H</th><th style="width: 45px;">S</th><th style="width: 45px;">I</th><th style="width: 45px;">A</th>';
        }
        $html .= '<th style="width: 55px;">H</th><th style="width: 55px;">S</th><th style="width: 55px;">I</th><th style="width: 55px;">A</th>';
        $html .= '</tr></thead><tbody>';

        $no = 1;
        foreach ($guruList as $guru) {
            $total = ['H' => 0, 'S' => 0, 'I' => 0, 'A' => 0];

            $html .= '<tr>';
            $html .= '<td class="center">' . $no++ . '</td>';
            $html .= '<td class="left">' . $e($guru->nama) . '</td>';
            $html .= '<td class="left">' . $e($guru->mapel ?: '-') . '</td>';

            foreach ($bulanList as [$tahunBulan, $bulan]) {
                $kunciBulan = sprintf('%04d-%02d', $tahunBulan, $bulan);
                $data = $rekap[$guru->kode_guru][$kunciBulan] ?? [];

                foreach (['H' => 'hadir', 'S' => 'sakit', 'I' => 'izin', 'A' => 'alpa'] as $kode => $kelasCss) {
                    $jumlah = (int) ($data[$kode] ?? 0);
                    $total[$kode] += $jumlah;
                    $html .= '<td class="center ' . $kelasCss . '">' . $jumlah . '</td>';
                }
            }

            $totalHari = array_sum($total);
            $persen = $totalHari > 0 ? round(($total['H'] / $totalHari) * 100, 1) . '%' : '-';

            $html .= '<td class="center hadir">' . $total['H'] . '</td>';
            $html .= '<td class="center sakit">' . $total['S'] . '</td>';
            $html .= '<td class="center izin">' . $total['I'] . '</td>';
            $html .= '<td class="center alpa">' . $total['A'] . '</td>';
            $html .= '<td class="center">' . $totalHari . '</td>';
            $html .= '<td class="center" style="font-weight: bold;">' . $persen . '</td>';
            $html .= '</tr>';
        }

        if ($guruList->isEmpty()) {
            $html .= '<tr><td colspan="' . $jumlahKolom . '" class="kosong">Tidak ada data guru.</td></tr>';
        }

        $html .= '</tbody></table>';
        $html .= '<div class="meta" style="margin-top: 12px; text-align: left;">Keterangan: H = Hadir, S = Sakit, I = Izin, A = Alpa. Kehadiran (%) = jumlah Hadir dibagi total hari yang tercatat.</div>';

        $namaFile = 'Rekap_Kehadiran_Guru_Semester_' . $namaSemester . '_TA_' . str_replace('/', '-', $labelTA) . '_' . date('Ymd_His') . '.xls';

        return ExcelHtml::unduh(ExcelHtml::dokumen($html), $namaFile);
    }

    // =========================================================================
    // 7. EXPORT EXCEL: REKAP JURNAL PER KELAS / SEMUA KELAS
    // =========================================================================
    public function exportRekapJurnal(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        // Kelas: kosong atau "all" = semua kelas
        $kelasQuery = $request->query('kelas', '');
        $kelas = is_string($kelasQuery) ? trim($kelasQuery) : '';
        $semuaKelas = ($kelas === '' || strtolower($kelas) === 'all');

        // Tahun ajaran: 4 digit, "semua" = seluruh data, default tahun ajaran berjalan
        $tahunQuery = $request->query('tahun');
        $semuaTahun = ($tahunQuery === 'semua');
        $tahunMulai = (is_string($tahunQuery) && preg_match('/^\d{4}$/', $tahunQuery))
            ? (int) $tahunQuery
            : TahunAjaran::tahunMulai();
        $labelTA = $semuaTahun ? 'Semua Tahun Ajaran' : 'Tahun Ajaran ' . TahunAjaran::label($tahunMulai);

        $query = DB::table('tb_jurnal')
            ->leftJoin('tb_guru', 'tb_jurnal.kode_guru', '=', 'tb_guru.kode_guru')
            ->select('tb_jurnal.*', 'tb_guru.nama as nama_guru')
            ->orderBy('tb_jurnal.tanggal')
            ->orderBy('tb_jurnal.jam_sekolah')
            ->orderBy('tb_jurnal.id');

        if (!$semuaKelas) {
            $query->where('tb_jurnal.kelas', $kelas);
        }
        if (!$semuaTahun) {
            [$awal, $akhir] = TahunAjaran::rentang($tahunMulai);
            $query->whereBetween('tb_jurnal.tanggal', [$awal, $akhir]);
        }

        $jurnalPerKelas = $query->get()->groupBy('kelas');

        if ($semuaKelas) {
            $daftarKelas = array_values(array_unique(array_merge(
                DB::table('tb_murid_x')->distinct()->pluck('kelas')->toArray(),
                DB::table('tb_murid_xi')->distinct()->pluck('kelas')->toArray(),
                DB::table('tb_murid_xii')->distinct()->pluck('kelas')->toArray(),
                $jurnalPerKelas->keys()->toArray()
            )));

            // Urutkan X, XI, XII lalu nama kelas
            $urutTingkat = fn ($k) => str_starts_with($k, 'XII') ? 2 : (str_starts_with($k, 'XI') ? 1 : 0);
            usort($daftarKelas, function ($a, $b) use ($urutTingkat) {
                return [$urutTingkat($a), $a] <=> [$urutTingkat($b), $b];
            });

            $judul = 'REKAPITULASI JURNAL MENGAJAR SEMUA KELAS';
            $namaFile = 'Rekap_Jurnal_Semua_Kelas_';
        } else {
            $daftarKelas = [$kelas];
            $judul = 'REKAPITULASI JURNAL MENGAJAR KELAS ' . strtoupper($kelas);
            $namaFile = 'Rekap_Jurnal_' . preg_replace('/[^A-Za-z0-9_-]/', '_', $kelas) . '_';
        }
        $namaFile .= ($semuaTahun ? 'Semua_TA' : 'TA_' . $tahunMulai . '-' . ($tahunMulai + 1)) . '_' . date('Ymd_His') . '.xls';

        $e = fn ($v) => ExcelHtml::e($v);

        $html = '<div class="title">' . $e($judul) . '</div>';
        $html .= '<div class="meta"><strong>' . $e($labelTA) . '</strong></div>';
        $html .= '<div class="meta">SMK TI Bali Global Badung | Diunduh pada: ' . $e(date('d/m/Y H:i')) . ' WITA</div>';

        foreach ($daftarKelas as $namaKelas) {
            $baris = $jurnalPerKelas->get($namaKelas, collect());

            $html .= '<h3 style="margin-top: 20px; color: #1e3a8a;">Kelas: ' . $e($namaKelas)
                . ' &mdash; ' . $e($labelTA) . ' (' . $baris->count() . ' jurnal)</h3>';
            $html .= '<table><thead><tr>
                <th style="width: 40px;">No.</th>
                <th style="width: 110px;">Tanggal</th>
                <th style="width: 70px;">Jam ke-</th>
                <th style="width: 240px;">Nama Guru</th>
                <th style="width: 220px;">Mata Pelajaran</th>
                <th style="width: 80px;">Pertemuan</th>
                <th style="width: 320px;">Materi / Sub-Kompetensi</th>
                <th style="width: 200px;">Keterangan</th>
            </tr></thead><tbody>';

            if ($baris->isEmpty()) {
                $html .= '<tr><td colspan="8" class="kosong">Belum ada jurnal untuk kelas ini.</td></tr>';
            }

            $no = 1;
            foreach ($baris as $j) {
                $html .= '<tr>';
                $html .= '<td class="center">' . $no++ . '</td>';
                $html .= '<td class="center">' . $e(date('d/m/Y', strtotime((string) $j->tanggal))) . '</td>';
                $html .= '<td class="center">' . $e($j->jam_sekolah) . '</td>';
                $html .= '<td class="left">' . $e($j->nama_guru ?: '-') . '</td>';
                $html .= '<td class="left">' . $e($j->nama_mapel) . '</td>';
                $html .= '<td class="center">' . $e($j->pertemuan) . '</td>';
                $html .= '<td class="left">' . $e($j->sub_kompetensi) . '</td>';
                $html .= '<td class="left">' . $e($j->keterangan ?: '-') . '</td>';
                $html .= '</tr>';
            }

            $html .= '</tbody></table>';
        }

        return ExcelHtml::unduh(ExcelHtml::dokumen($html), $namaFile);
    }
}

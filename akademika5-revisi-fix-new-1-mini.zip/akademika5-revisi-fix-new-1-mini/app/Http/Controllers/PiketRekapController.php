<?php

namespace App\Http\Controllers;

/**
 * Rekap kehadiran guru dan rekap jurnal untuk akun guru / guru piket.
 * Memakai logika AdminController, dengan tampilan dan hak akses guru.
 */
class PiketRekapController extends AdminController
{
    protected bool $izinkanGuru = true;
    protected string $viewRekapGuru = 'guru-piket.piket-rekap-guru';
    protected string $viewRekapJurnal = 'guru-piket.piket-rekap-jurnal';
}

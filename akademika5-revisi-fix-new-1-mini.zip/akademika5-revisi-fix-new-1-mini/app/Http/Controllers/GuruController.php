<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\AkunGuru;
use App\Models\Guru;
use App\Models\Jurnal;
use App\Support\TahunAjaran;

class GuruController extends Controller
{
    /** Map nama hari Indonesia */
    private $daftarHari = [
        1 => 'senin',
        2 => 'selasa',
        3 => 'rabu',
        4 => 'kamis',
        5 => 'jumat',
    ];

    /** Ambil data guru yang sedang login */
    private function getGuruData(): array
    {
        $akun = Auth::guard('guru')->user();

        if (!$akun) {
            $email = session('email_akun');
            if ($email) {
                $akun = AkunGuru::where('email', $email)->first();
                if ($akun) {
                    Auth::guard('guru')->login($akun);
                }
            }
        }

        $kodeGuru = $akun ? $akun->kode_guru : session('kode_guru');

        $guruRow = null;
        if ($kodeGuru) {
            $guruRow = DB::table('tb_guru')->where('kode_guru', $kodeGuru)->first();
        }

        $namaGuru = $guruRow ? strtoupper(trim($guruRow->nama)) : strtoupper(session('nama_guru') ?? 'GURU PENGAJAR');
        $mapelGuru = $guruRow ? trim($guruRow->mapel) : (session('mapel_guru') ?? '-');

        return [
            'akun'      => $akun,
            'kode_guru' => $kodeGuru,
            'nama'      => $namaGuru,
            'mapel'     => $mapelGuru,
        ];
    }

    /** Helper: Ambil daftar semua kelas unik dari X, XI, XII */
    private function getAllKelas(): array
    {
        $kelasX = DB::table('tb_murid_x')->distinct()->orderBy('kelas')->pluck('kelas')->toArray();
        $kelasXI = DB::table('tb_murid_xi')->distinct()->orderBy('kelas')->pluck('kelas')->toArray();
        $kelasXII = DB::table('tb_murid_xii')->distinct()->orderBy('kelas')->pluck('kelas')->toArray();

        return array_values(array_unique(array_merge($kelasX, $kelasXI, $kelasXII)));
    }

    /**
     * Kelas yang benar-benar diajar guru, diambil dari jadwal mengajar (tb_mapel_guru).
     * Nama kelas disesuaikan dengan nama kelas di data siswa; contoh jadwal "XI TJKT 1"
     * dicocokkan ke kelas siswa "XI TJKT" bila nama persisnya tidak ada.
     * Hanya kelas yang punya data siswa yang dikembalikan.
     */
    private function getKelasDiajar($kodeGuru): array
    {
        if (!$kodeGuru) {
            return [];
        }

        $kelasJadwal = DB::table('tb_mapel_guru')
            ->where('kode_guru', $kodeGuru)
            ->whereNotNull('kelas')
            ->distinct()
            ->pluck('kelas')
            ->map(fn ($k) => trim((string) $k))
            ->filter()
            ->all();

        $kelasSiswa = $this->getAllKelas();

        $hasil = [];
        foreach ($kelasJadwal as $kelas) {
            if (in_array($kelas, $kelasSiswa, true)) {
                $hasil[] = $kelas;
                continue;
            }
            $tanpaAngka = trim(preg_replace('/\s+\d+$/', '', $kelas));
            if ($tanpaAngka !== '' && in_array($tanpaAngka, $kelasSiswa, true)) {
                $hasil[] = $tanpaAngka;
            }
        }

        $hasil = array_values(array_unique($hasil));
        $urutTingkat = fn ($k) => str_starts_with($k, 'XII') ? 2 : (str_starts_with($k, 'XI') ? 1 : 0);
        usort($hasil, fn ($a, $b) => [$urutTingkat($a), $a] <=> [$urutTingkat($b), $b]);

        return $hasil;
    }

    /** Apakah guru ini mengajar kelas tersebut? */
    private function guruMengajarKelas($kodeGuru, string $kelas): bool
    {
        return in_array($kelas, $this->getKelasDiajar($kodeGuru), true);
    }

    /** Helper: format DATE ke bahasa Indonesia */
    private function formatTanggalIndo(string $dateStr): string
    {
        return PiketAbsenController::formatTanggalIndo($dateStr);
    }

    /** Helper jam: '07.05' / '07:05' -> menit sejak 00:00 */
    private function jamKeMenit(?string $jam): ?int
    {
        if ($jam !== null && preg_match('/^(\d{1,2})[.:](\d{2})$/', trim($jam), $m)) {
            return (int) $m[1] * 60 + (int) $m[2];
        }
        return null;
    }

    /**
     * Daftar mata pelajaran yang benar-benar diajar guru.
     * Sumber utama: jadwal mengajar (tb_mapel_guru). Bila guru belum punya jadwal,
     * dipakai isi kolom mapel di tb_guru (dipisah koma).
     */
    private function getMapelDiajar($kodeGuru, ?string $mapelText = null): array
    {
        $mapel = [];

        if ($kodeGuru) {
            $mapel = DB::table('tb_mapel_guru')
                ->where('kode_guru', $kodeGuru)
                ->whereNotNull('nama_mapel')
                ->distinct()
                ->pluck('nama_mapel')
                ->map(fn ($m) => trim((string) $m))
                ->filter()
                ->all();
        }

        if (empty($mapel) && !empty($mapelText)) {
            foreach (explode(',', $mapelText) as $bagian) {
                $bagian = trim($bagian);
                if ($bagian !== '') {
                    $mapel[] = $bagian;
                }
            }
        }

        $mapel = array_values(array_unique($mapel));
        sort($mapel, SORT_NATURAL | SORT_FLAG_CASE);

        return $mapel;
    }

    /** Helper: ambil query string sebagai teks aman (abaikan bila bukan string) */
    private function teksQuery(Request $request, string $kunci): string
    {
        $nilai = $request->query($kunci, '');

        return is_string($nilai) ? trim($nilai) : '';
    }

    /** Helper: kembalikan 'Y-m-d' bila input tanggal valid, selain itu null */
    private function tanggalValid($nilai): ?string
    {
        if (!is_string($nilai) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $nilai)) {
            return null;
        }

        try {
            return Carbon::createFromFormat('Y-m-d', $nilai)->format('Y-m-d') === $nilai ? $nilai : null;
        } catch (\Exception $e) {
            return null;
        }
    }

    /** Redirect dashboard ke jadwal */
    public function dashboard(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        return redirect()->route('guru.jadwal');
    }

    // =========================================================================
    // 1. JADWAL GURU
    // =========================================================================
    public function jadwal(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];
        $kodeGuru = $guru['kode_guru'];

        $now = Carbon::now('Asia/Makassar');
        $hariIni = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';
        $tanggalHariIni = $this->formatTanggalIndo($now->toDateString());

        $hariPilihan = strtolower($request->query('hari', $hariIni));
        if (!in_array($hariPilihan, ['senin', 'selasa', 'rabu', 'kamis', 'jumat'])) {
            $hariPilihan = 'senin';
        }

        // Ambil jadwal mengajar hari ini untuk hero card real-time
        $jadwalHariIni = DB::table('tb_mapel_guru')
            ->where('kode_guru', $kodeGuru)
            ->where('hari', $hariIni)
            ->get();

        // Sort berdasarkan waktu mulai aktual (bukan sekadar angka jam_sekolah)
        $jadwalHariIni = $jadwalHariIni->sort(function ($a, $b) {
            $mA = $this->jamKeMenit($a->jam_mulai) ?? 9999;
            $mB = $this->jamKeMenit($b->jam_mulai) ?? 9999;
            if ($mA === $mB) {
                return $a->jam_sekolah <=> $b->jam_sekolah;
            }
            return $mA <=> $mB;
        })->values();

        // Gabungkan baris mapel berurutan untuk kelas yang sama
        $grupToday = [];
        foreach ($jadwalHariIni as $r) {
            $last = count($grupToday) - 1;
            if ($last >= 0 && $grupToday[$last]->kelas === $r->kelas && $grupToday[$last]->nama_mapel === $r->nama_mapel) {
                $grupToday[$last]->jam_akhir = $r->jam_sekolah;
                $grupToday[$last]->jam_selesai = $r->jam_selesai;
                continue;
            }
            $grupToday[] = (object) [
                'nama_mapel'  => $r->nama_mapel,
                'kelas'       => $r->kelas,
                'jam_awal'    => $r->jam_sekolah,
                'jam_akhir'   => $r->jam_sekolah,
                'jam_mulai'   => $r->jam_mulai,
                'jam_selesai' => $r->jam_selesai,
            ];
        }

        foreach ($grupToday as $k => $g) {
            $grupToday[$k]->jam_ke = ($g->jam_awal === $g->jam_akhir)
                ? (string) $g->jam_awal
                : $g->jam_awal . ' - ' . $g->jam_akhir;
            $grupToday[$k]->waktu = trim(($g->jam_mulai ?? '') . ' - ' . ($g->jam_selesai ?? ''), ' -');
        }

        // Tentukan hero card: sedang berlangsung atau yang paling dekat jam waktunya dengan jam saat ini
        $menitNow = $now->hour * 60 + $now->minute;
        $ongoingJadwal = null;
        $upcomingJadwal = null;
        $minUpcomingDiff = PHP_INT_MAX;

        foreach ($grupToday as $g) {
            $mulai = $this->jamKeMenit($g->jam_mulai);
            $selesai = $this->jamKeMenit($g->jam_selesai);

            if ($mulai !== null && $selesai !== null) {
                if ($menitNow >= $mulai && $menitNow < $selesai) {
                    $ongoingJadwal = $g;
                    break;
                } elseif ($mulai > $menitNow) {
                    $diff = $mulai - $menitNow;
                    if ($diff < $minUpcomingDiff) {
                        $minUpcomingDiff = $diff;
                        $upcomingJadwal = $g;
                    }
                }
            }
        }

        $heroJadwal = null;
        if ($ongoingJadwal) {
            $heroJadwal = (object) [
                'kicker'      => 'Sedang Mengajar',
                'jam_ke'      => $ongoingJadwal->jam_ke,
                'waktu'       => $ongoingJadwal->waktu,
                'mapel'       => $ongoingJadwal->nama_mapel,
                'kelas'       => $ongoingJadwal->kelas,
                'status_text' => 'Sedang Berlangsung',
                'status_slug' => 'ongoing',
            ];
        } elseif ($upcomingJadwal) {
            $heroJadwal = (object) [
                'kicker'      => 'Jadwal Mengajar Berikutnya',
                'jam_ke'      => $upcomingJadwal->jam_ke,
                'waktu'       => $upcomingJadwal->waktu,
                'mapel'       => $upcomingJadwal->nama_mapel,
                'kelas'       => $upcomingJadwal->kelas,
                'status_text' => 'Akan Datang',
                'status_slug' => 'upcoming',
            ];
        } elseif (!empty($grupToday)) {
            $last = end($grupToday);
            $heroJadwal = (object) [
                'kicker'      => 'Selesai Mengajar',
                'jam_ke'      => $last->jam_ke,
                'waktu'       => $last->waktu,
                'mapel'       => $last->nama_mapel,
                'kelas'       => $last->kelas,
                'status_text' => 'Selesai',
                'status_slug' => 'finished',
            ];
        }

        // Ambil jadwal lengkap sesuai hari terpilih (tab)
        $jadwalTabRows = DB::table('tb_mapel_guru')
            ->where('kode_guru', $kodeGuru)
            ->where('hari', $hariPilihan)
            ->get();

        // Sort hari terpilih berdasarkan waktu jam_mulai aktual
        $jadwalTabRows = $jadwalTabRows->sort(function ($a, $b) {
            $mA = $this->jamKeMenit($a->jam_mulai) ?? 9999;
            $mB = $this->jamKeMenit($b->jam_mulai) ?? 9999;
            if ($mA === $mB) {
                return $a->jam_sekolah <=> $b->jam_sekolah;
            }
            return $mA <=> $mB;
        })->values();

        $jadwalList = collect();
        $grupTab = [];
        foreach ($jadwalTabRows as $r) {
            $last = count($grupTab) - 1;
            if ($last >= 0 && $grupTab[$last]->kelas === $r->kelas && $grupTab[$last]->nama_mapel === $r->nama_mapel) {
                $grupTab[$last]->jam_akhir = $r->jam_sekolah;
                $grupTab[$last]->jam_selesai = $r->jam_selesai;
                continue;
            }
            $grupTab[] = (object) [
                'nama_mapel'  => $r->nama_mapel,
                'kelas'       => $r->kelas,
                'jam_awal'    => $r->jam_sekolah,
                'jam_akhir'   => $r->jam_sekolah,
                'jam_mulai'   => $r->jam_mulai,
                'jam_selesai' => $r->jam_selesai,
            ];
        }

        $isHariIni = ($hariPilihan === $hariIni);
        foreach ($grupTab as $g) {
            $mulai = $this->jamKeMenit($g->jam_mulai);
            $selesai = $this->jamKeMenit($g->jam_selesai);
            $isOngoing = false;
            $isFinished = false;
            if ($isHariIni && $mulai !== null && $selesai !== null) {
                if ($menitNow >= $mulai && $menitNow < $selesai) {
                    $isOngoing = true;
                } elseif ($menitNow >= $selesai) {
                    $isFinished = true;
                }
            }

            $jamLabel = ($g->jam_awal === $g->jam_akhir)
                ? 'Jam ke ' . $g->jam_awal
                : 'Jam ke ' . $g->jam_awal . ' - ' . $g->jam_akhir;

            // Deteksi tingkatan kelas: 10 (Fase E), 11 (Fase F), 12 (Fase F Lanjutan)
            $tingkat = '10';
            $kelasUpper = strtoupper(trim($g->kelas));
            if (str_starts_with($kelasUpper, 'XII ') || $kelasUpper === 'XII' || str_contains($kelasUpper, 'XII')) {
                $tingkat = '12';
            } elseif (str_starts_with($kelasUpper, 'XI ') || $kelasUpper === 'XI' || str_contains($kelasUpper, 'XI')) {
                $tingkat = '11';
            }

            $jadwalList->push((object) [
                'mapel'      => $g->nama_mapel,
                'kelas'      => $g->kelas,
                'tingkat'    => $tingkat,
                'jam_ke'     => $jamLabel,
                'waktu'      => trim(($g->jam_mulai ?? '') . ' - ' . ($g->jam_selesai ?? ''), ' -'),
                'is_ongoing' => $isOngoing,
                'is_finished' => $isFinished,
            ]);
        }

        // Kelompokkan jadwalList berdasarkan tingkat kelas (10, 11, 12)
        $jadwalByTingkat = [
            '10' => $jadwalList->where('tingkat', '10')->values(),
            '11' => $jadwalList->where('tingkat', '11')->values(),
            '12' => $jadwalList->where('tingkat', '12')->values(),
        ];

        // Deteksi apakah guru ini bertugas sebagai Guru Piket hari ini (baik jadwal tetap maupun pengganti)
        $notifPiket = null;
        $isPiketTetap = DB::table('tb_guru_piket')
            ->where('kode_guru', $kodeGuru)
            ->where('hari', $hariIni)
            ->first();

        $isPiketPengganti = DB::table('tb_piket_pengganti')
            ->where('kode_guru', $kodeGuru)
            ->whereDate('tanggal', $now->toDateString())
            ->first();

        if ($isPiketPengganti) {
            $notifPiket = (object) [
                'tipe'        => 'pengganti',
                'judul'       => 'Tugas Guru Piket Pengganti',
                'pesan'       => 'Anda telah ditugaskan oleh Admin sebagai Guru Piket Pengganti untuk hari ini (' . ucfirst($hariIni) . ', ' . $tanggalHariIni . ').',
                'keterangan'  => $isPiketPengganti->keterangan ?? 'Akses aktif sementara hari ini.',
                'link'        => route('piket.dashboard'),
            ];
        } elseif ($isPiketTetap) {
            $notifPiket = (object) [
                'tipe'        => 'tetap',
                'judul'       => 'Jadwal Tugas Guru Piket',
                'pesan'       => 'Hari ini (' . ucfirst($hariIni) . ') Anda terjadwal bertugas sebagai Guru Piket shift ' . $isPiketTetap->waktu . '.',
                'keterangan'  => 'Silakan masuk ke halaman Guru Piket untuk memproses presensi dan kontrol piket.',
                'link'        => route('piket.dashboard'),
            ];
        }

        return view('guru.guru-jadwal', compact(
            'namaGuru',
            'mapelGuru',
            'tanggalHariIni',
            'hariIni',
            'hariPilihan',
            'heroJadwal',
            'jadwalList',
            'jadwalByTingkat',
            'notifPiket'
        ));
    }

    // =========================================================================
    // 2. ABSEN SISWA (CRUD)
    // =========================================================================
    public function absen(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];

        // Hanya kelas yang diajar guru ini (dari jadwal mengajar di database)
        $daftarKelas = $this->getKelasDiajar($guru['kode_guru']);
        $daftarTingkat = array_values(array_filter(['X', 'XI', 'XII'], function ($t) use ($daftarKelas) {
            foreach ($daftarKelas as $k) {
                $tk = (str_starts_with($k, 'XII ') || $k === 'XII') ? 'XII' : ((str_starts_with($k, 'XI ') || $k === 'XI') ? 'XI' : 'X');
                if ($tk === $t) {
                    return true;
                }
            }
            return false;
        }));

        // Ambil riwayat log absensi gabungan dari tb_absen_murid_x, xi, xii
        $logsX = DB::table('tb_absen_murid_x')
            ->join('tb_murid_x', 'tb_absen_murid_x.nis_x', '=', 'tb_murid_x.nis_x')
            ->select(
                'tb_murid_x.kelas',
                'tb_absen_murid_x.tanggal',
                DB::raw("'X' as tingkat"),
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->whereIn('tb_murid_x.kelas', $daftarKelas)
            ->groupBy('tb_murid_x.kelas', 'tb_absen_murid_x.tanggal');

        $logsXI = DB::table('tb_absen_murid_xi')
            ->join('tb_murid_xi', 'tb_absen_murid_xi.nis_xi', '=', 'tb_murid_xi.nis_xi')
            ->select(
                'tb_murid_xi.kelas',
                'tb_absen_murid_xi.tanggal',
                DB::raw("'XI' as tingkat"),
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->whereIn('tb_murid_xi.kelas', $daftarKelas)
            ->groupBy('tb_murid_xi.kelas', 'tb_absen_murid_xi.tanggal');

        $logsXII = DB::table('tb_absen_murid_xii')
            ->join('tb_murid_xii', 'tb_absen_murid_xii.nis_xii', '=', 'tb_murid_xii.nis_xii')
            ->select(
                'tb_murid_xii.kelas',
                'tb_absen_murid_xii.tanggal',
                DB::raw("'XII' as tingkat"),
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->whereIn('tb_murid_xii.kelas', $daftarKelas)
            ->groupBy('tb_murid_xii.kelas', 'tb_absen_murid_xii.tanggal');

        $search = $this->teksQuery($request, 'q');

        // Filter log absensi
        $filterKelas   = $this->teksQuery($request, 'kelas');
        $filterTingkat = strtoupper($this->teksQuery($request, 'tingkat'));
        $filterStatus  = strtoupper($this->teksQuery($request, 'status'));
        $filterDari    = $this->tanggalValid($request->query('dari'));
        $filterSampai  = $this->tanggalValid($request->query('sampai'));

        if (!in_array($filterTingkat, ['X', 'XI', 'XII'], true)) {
            $filterTingkat = '';
        }
        if (!in_array($filterStatus, ['H', 'S', 'I', 'A'], true)) {
            $filterStatus = '';
        }

        $allLogs = $logsX->unionAll($logsXI)->unionAll($logsXII)->get();

        if (!empty($search)) {
            $allLogs = $allLogs->filter(function ($item) use ($search) {
                return str_contains(strtolower($item->kelas), strtolower($search)) ||
                       str_contains($item->tanggal, $search);
            });
        }

        $allLogs = $allLogs->filter(function ($item) use ($filterKelas, $filterTingkat, $filterStatus, $filterDari, $filterSampai) {
            $tgl = substr((string) $item->tanggal, 0, 10);

            if ($filterKelas !== '' && $item->kelas !== $filterKelas) {
                return false;
            }
            if ($filterTingkat !== '' && $item->tingkat !== $filterTingkat) {
                return false;
            }
            if ($filterDari !== null && $tgl < $filterDari) {
                return false;
            }
            if ($filterSampai !== null && $tgl > $filterSampai) {
                return false;
            }
            // Status: tampilkan log yang memuat minimal satu siswa dengan status tsb
            if ($filterStatus !== '') {
                $jumlah = match ($filterStatus) {
                    'H' => (int) $item->hadir,
                    'S' => (int) $item->sakit,
                    'I' => (int) $item->izin,
                    default => (int) $item->alpa,
                };
                if ($jumlah < 1) {
                    return false;
                }
            }

            return true;
        });

        $allLogs = $allLogs->sortByDesc('tanggal')->values()->map(function ($item) {
            $item->tanggal_formatted = $this->formatTanggalIndo($item->tanggal);
            return $item;
        });

        $adaFilter = $search !== '' || $filterKelas !== '' || $filterTingkat !== ''
            || $filterStatus !== '' || $filterDari !== null || $filterSampai !== null;

        return view('guru.guru-absen', compact(
            'namaGuru',
            'mapelGuru',
            'allLogs',
            'daftarKelas',
            'daftarTingkat',
            'search',
            'filterKelas',
            'filterTingkat',
            'filterStatus',
            'filterDari',
            'filterSampai',
            'adaFilter'
        ));
    }

    /** AJAX: Ambil daftar siswa per kelas beserta absensi pada tanggal tersebut */
    public function getSiswaByKelas(Request $request)
    {
        if (!session('sudah_login')) {
            return response()->json(['error' => 'Silakan login terlebih dahulu'], 401);
        }

        $kelas = trim((string) $request->query('kelas', ''));
        $tanggal = trim((string) $request->query('tanggal', Carbon::now('Asia/Makassar')->toDateString()));

        if (empty($kelas)) {
            return response()->json(['error' => 'Kelas harus dipilih'], 400);
        }

        // Guru hanya boleh membuka kelas yang dia ajar
        if (!$this->guruMengajarKelas($this->getGuruData()['kode_guru'], $kelas)) {
            return response()->json(['error' => 'Anda tidak mengajar kelas ini'], 403);
        }

        // Deteksi tingkat kelas
        $tingkat = 'X';
        if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
            $tingkat = 'XI';
        }

        $tabelMurid = match ($tingkat) {
            'XI'  => 'tb_murid_xi',
            'XII' => 'tb_murid_xii',
            default => 'tb_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };
        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };

        $muridList = DB::table($tabelMurid)
            ->where('kelas', $kelas)
            ->orderBy('absen')
            ->orderBy('nama')
            ->get();

        $absenMap = DB::table($tabelAbsen)
            ->where('tanggal', $tanggal)
            ->get()
            ->keyBy($nisCol);

        $result = $muridList->map(function ($m) use ($nisCol, $absenMap) {
            $nisVal = $m->$nisCol;
            $absenItem = $absenMap[$nisVal] ?? null;

            return [
                'nis'     => $nisVal,
                'absen'   => $m->absen ?? '-',
                'nama'    => $m->nama,
                'status'  => $absenItem ? strtoupper($absenItem->status) : 'H',
                'catatan' => $absenItem ? ($absenItem->catatan ?? '') : '',
            ];
        });

        return response()->json([
            'kelas'   => $kelas,
            'tingkat' => $tingkat,
            'tanggal' => $tanggal,
            'siswa'   => $result,
        ]);
    }

    /** Simpan Absensi Siswa */
    public function simpanAbsen(Request $request)
    {
        $request->validate([
            'kelas'     => 'required|string',
            'tanggal'   => 'required|date',
            'kehadiran' => 'required|array',
        ]);

        $kelas = trim($request->input('kelas'));
        $tanggal = $request->input('tanggal');
        $kehadiran = $request->input('kehadiran'); // [nis => status]

        // Guru hanya boleh menyimpan absensi kelas yang dia ajar
        if (!$this->guruMengajarKelas($this->getGuruData()['kode_guru'], $kelas)) {
            return redirect()->route('guru.absen')->with('error', 'Anda hanya dapat mengisi absensi kelas yang Anda ajar.');
        }
        $catatan = $request->input('catatan', []);

        $tingkat = 'X';
        if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
            $tingkat = 'XI';
        }

        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };

        // Hanya NIS yang benar-benar siswa kelas ini yang disimpan
        $tabelMuridSimpan = match ($tingkat) {
            'XI'  => 'tb_murid_xi',
            'XII' => 'tb_murid_xii',
            default => 'tb_murid_x',
        };
        $nisKelas = DB::table($tabelMuridSimpan)->where('kelas', $kelas)->pluck($nisCol)->map(fn ($n) => (string) $n)->all();

        $now = now();
        foreach ($kehadiran as $nis => $rawStatus) {
            if (!in_array((string) $nis, $nisKelas, true)) {
                continue;
            }

            $statusUpper = strtoupper($rawStatus);
            $statusVal = match ($statusUpper) {
                'HADIR', 'H' => 'H',
                'SAKIT', 'S' => 'S',
                'IZIN', 'I'  => 'I',
                default      => 'A',
            };
            $catatanVal = $catatan[$nis] ?? null;

            DB::table($tabelAbsen)->updateOrInsert(
                [
                    $nisCol   => $nis,
                    'tanggal' => $tanggal,
                ],
                [
                    'status'     => $statusVal,
                    'catatan'    => $catatanVal,
                    'updated_at' => $now,
                ]
            );
        }

        return redirect()->route('guru.absen')->with('success', "Absensi kelas {$kelas} tanggal {$tanggal} berhasil disimpan.");
    }

    /** Hapus Riwayat Absensi Kelas per Tanggal */
    public function hapusAbsen(Request $request)
    {
        $kelas = trim($request->input('kelas', ''));
        $tanggal = trim($request->input('tanggal', ''));

        if (empty($kelas) || empty($tanggal)) {
            return back()->with('error', 'Parameter kelas atau tanggal tidak valid.');
        }

        // Guru hanya boleh menghapus absensi kelas yang dia ajar
        if (!$this->guruMengajarKelas($this->getGuruData()['kode_guru'], $kelas)) {
            return redirect()->route('guru.absen')->with('error', 'Anda hanya dapat menghapus absensi kelas yang Anda ajar.');
        }

        $tingkat = 'X';
        if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
            $tingkat = 'XI';
        }

        $tabelMurid = match ($tingkat) {
            'XI'  => 'tb_murid_xi',
            'XII' => 'tb_murid_xii',
            default => 'tb_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };
        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };

        $nisList = DB::table($tabelMurid)->where('kelas', $kelas)->pluck($nisCol);

        DB::table($tabelAbsen)
            ->where('tanggal', $tanggal)
            ->whereIn($nisCol, $nisList)
            ->delete();

        return redirect()->route('guru.absen')->with('success', "Data absensi kelas {$kelas} pada {$tanggal} berhasil dihapus.");
    }

    // =========================================================================
    // 3. JURNAL KELAS (CRUD)
    // =========================================================================
    public function jurnal(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];
        $kodeGuru = $guru['kode_guru'];

        $daftarKelas = $this->getAllKelas();

        $search = trim($request->query('q', ''));

        $query = DB::table('tb_jurnal')
            ->where('kode_guru', $kodeGuru)
            ->orderByDesc('tanggal')
            ->orderByDesc('jam_sekolah');

        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('kelas', 'like', "%{$search}%")
                  ->orWhere('nama_mapel', 'like', "%{$search}%")
                  ->orWhere('sub_kompetensi', 'like', "%{$search}%")
                  ->orWhere('keterangan', 'like', "%{$search}%");
            });
        }

        $jurnals = $query->get()->map(function ($jurnal) {
            $jurnal->tanggal_formatted = $this->formatTanggalIndo($jurnal->tanggal);
            return $jurnal;
        });

        // Mapel di form jurnal hanya yang diajar guru ini
        $daftarMapel = $this->getMapelDiajar($kodeGuru, $guru['mapel']);
        foreach ($jurnals as $jr) {
            // Jurnal lama dengan mapel di luar daftar tetap bisa diedit
            if (!empty($jr->nama_mapel) && !in_array($jr->nama_mapel, $daftarMapel, true)) {
                $daftarMapel[] = $jr->nama_mapel;
            }
        }
        $daftarMapel = array_values(array_unique($daftarMapel));
        sort($daftarMapel, SORT_NATURAL | SORT_FLAG_CASE);
        $mapelDefault = count($daftarMapel) === 1 ? $daftarMapel[0] : '';

        return view('guru.guru-jurnal', compact(
            'namaGuru',
            'mapelGuru',
            'jurnals',
            'daftarKelas',
            'daftarMapel',
            'mapelDefault',
            'search'
        ));
    }

    /** Simpan / Update Jurnal */
    public function simpanJurnal(Request $request)
    {
        $guru = $this->getGuruData();
        $kodeGuru = $guru['kode_guru'];

        $request->validate([
            'id'             => 'nullable|integer',
            'tanggal'        => 'required|date',
            'jam_sekolah'    => 'required|integer|min:1|max:15', // 1 angka input sesuai instruksi user
            'kelas'          => 'required|string',
            'nama_mapel'     => 'required|string',
            'pertemuan'      => 'required|integer|min:1',
            'sub_kompetensi' => 'required|string',
            'keterangan'     => 'nullable|string',
        ]);

        // Guru hanya boleh membuat jurnal untuk pelajaran yang dia ajar
        $mapelBoleh = $this->getMapelDiajar($kodeGuru, $guru['mapel']);
        $mapelInput = trim((string) $request->input('nama_mapel'));
        $mapelLama = null;
        if ($idLama = $request->input('id')) {
            $mapelLama = DB::table('tb_jurnal')->where('id', $idLama)->where('kode_guru', $kodeGuru)->value('nama_mapel');
        }
        if (!in_array($mapelInput, $mapelBoleh, true) && $mapelInput !== $mapelLama) {
            return redirect()->route('guru.jurnal')
                ->with('error', 'Mata pelajaran tidak sesuai dengan pelajaran yang Anda ajar.')
                ->withInput();
        }

        $data = [
            'kode_guru'      => $kodeGuru,
            'kelas'          => $request->input('kelas'),
            'tanggal'        => $request->input('tanggal'),
            'jam_sekolah'    => (int) $request->input('jam_sekolah'),
            'nama_mapel'     => $request->input('nama_mapel'),
            'sub_kompetensi' => $request->input('sub_kompetensi'),
            'pertemuan'      => (int) $request->input('pertemuan'),
            'keterangan'     => $request->input('keterangan') ?? 'berjalan normal',
        ];

        if ($id = $request->input('id')) {
            DB::table('tb_jurnal')->where('id', $id)->where('kode_guru', $kodeGuru)->update($data);
            $msg = 'Jurnal kelas berhasil diperbarui.';
        } else {
            DB::table('tb_jurnal')->insert($data);
            $msg = 'Jurnal kelas berhasil ditambahkan.';
        }

        return redirect()->route('guru.jurnal')->with('success', $msg);
    }

    /** Hapus Jurnal */
    public function hapusJurnal($id)
    {
        $guru = $this->getGuruData();
        $kodeGuru = $guru['kode_guru'];

        DB::table('tb_jurnal')->where('id', $id)->where('kode_guru', $kodeGuru)->delete();

        return redirect()->route('guru.jurnal')->with('success', 'Jurnal kelas berhasil dihapus.');
    }

    // =========================================================================
    // 4. REKAP ABSENSI SISWA & EXPORT SPREADSHEET (EXCEL)
    // =========================================================================
    public function rekap(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];

        $daftarKelas = $this->getAllKelas();
        $search = trim($request->query('q', ''));

        // Hitung rekapan per kelas
        $rekapPerKelas = [];
        foreach ($daftarKelas as $kelas) {
            if (!empty($search) && !str_contains(strtolower($kelas), strtolower($search))) {
                continue;
            }

            $tingkat = 'X';
            if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
                $tingkat = 'XII';
            } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
                $tingkat = 'XI';
            }

            $tabelMurid = match ($tingkat) {
                'XI'  => 'tb_murid_xi',
                'XII' => 'tb_murid_xii',
                default => 'tb_murid_x',
            };
            $nisCol = match ($tingkat) {
                'XI'  => 'nis_xi',
                'XII' => 'nis_xii',
                default => 'nis_x',
            };
            $tabelAbsen = match ($tingkat) {
                'XI'  => 'tb_absen_murid_xi',
                'XII' => 'tb_absen_murid_xii',
                default => 'tb_absen_murid_x',
            };

            $totalSiswa = DB::table($tabelMurid)->where('kelas', $kelas)->count();

            $absenStats = DB::table($tabelAbsen)
                ->join($tabelMurid, "{$tabelAbsen}.{$nisCol}", '=', "{$tabelMurid}.{$nisCol}")
                ->where("{$tabelMurid}.kelas", $kelas)
                ->select(
                    DB::raw("COUNT(DISTINCT {$tabelAbsen}.tanggal) as total_hari"),
                    DB::raw("COUNT(*) as total_record"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'I' THEN 1 ELSE 0 END) as izin"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'A' THEN 1 ELSE 0 END) as alpa")
                )
                ->first();

            $totalHadir = $absenStats ? (int) $absenStats->hadir : 0;
            $totalRecord = $absenStats ? (int) $absenStats->total_record : 0;
            $persen = $totalRecord > 0 ? round(($totalHadir / $totalRecord) * 100, 1) : 100;

            $rekapPerKelas[] = (object) [
                'kelas'       => $kelas,
                'tingkat'     => $tingkat,
                'total_siswa' => $totalSiswa,
                'total_hari'  => $absenStats ? (int) $absenStats->total_hari : 0,
                'hadir'       => $totalHadir,
                'sakit'       => $absenStats ? (int) $absenStats->sakit : 0,
                'izin'        => $absenStats ? (int) $absenStats->izin : 0,
                'alpa'        => $absenStats ? (int) $absenStats->alpa : 0,
                'persen'      => $persen,
            ];
        }

        return view('guru.guru-rekap', compact(
            'namaGuru',
            'mapelGuru',
            'rekapPerKelas',
            'search'
        ));
    }

    /** Export Rekap Absensi Siswa ke File Spreadsheet / Excel */
    public function exportRekap(Request $request, $kelas = null)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];

        // Tahun ajaran (Juli - Juni). Bisa dipilih lewat ?tahun=2026, default tahun ajaran berjalan.
        $tahunQuery = $request->query('tahun');
        $tahunMulai = (is_string($tahunQuery) && preg_match('/^\d{4}$/', $tahunQuery))
            ? (int) $tahunQuery
            : TahunAjaran::tahunMulai();
        $tahunAjaran = TahunAjaran::label($tahunMulai);
        [$awalTA, $akhirTA] = TahunAjaran::rentang($tahunMulai);
        $tahunFile = str_replace('/', '-', $tahunAjaran);

        if ($kelas === 'all' || empty($kelas)) {
            $targetKelas = $this->getAllKelas();
            $filename = 'Rekap_Absensi_Semua_Kelas_TA_' . $tahunFile . '_' . date('Ymd_His') . '.xls';
            $title = 'REKAPITULASI ABSENSI SEMUA KELAS';
        } else {
            $targetKelas = [$kelas];
            $safeKelas = preg_replace('/[^A-Za-z0-9_-]/', '_', $kelas);
            $filename = 'Rekap_Absensi_' . $safeKelas . '_TA_' . $tahunFile . '_' . date('Ymd_His') . '.xls';
            $title = 'REKAPITULASI ABSENSI KELAS ' . htmlspecialchars(strtoupper($kelas));
        }

        // Siapkan HTML Spreadsheet table
        $html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        $html .= '<head><meta charset="utf-8">';
        $html .= '<style>
            table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }
            th { background-color: #1e3a8a; color: #ffffff; border: 1px solid #94a3b8; padding: 8px 12px; font-weight: bold; }
            td { border: 1px solid #cbd5e1; padding: 6px 10px; }
            .center { text-align: center; }
            .left { text-align: left; }
            .right { text-align: right; }
            .hadir { background-color: #dcfce7; color: #15803d; font-weight: bold; }
            .sakit { background-color: #ede9fe; color: #6d28d9; font-weight: bold; }
            .izin { background-color: #fef9c3; color: #a16207; font-weight: bold; }
            .alpa { background-color: #fee2e2; color: #b91c1c; font-weight: bold; }
            .title { font-size: 16pt; font-weight: bold; text-align: center; margin-bottom: 4px; }
            .meta { font-size: 10pt; color: #475569; text-align: center; margin-bottom: 12px; }
        </style>';
        $html .= '</head><body>';
        $html .= '<div class="title">' . $title . '</div>';
        $html .= '<div class="meta"><strong>Tahun Ajaran ' . $tahunAjaran . '</strong> (' . date('d/m/Y', strtotime($awalTA)) . ' - ' . date('d/m/Y', strtotime($akhirTA)) . ')</div>';
        $html .= '<div class="meta">SMK TI Bali Global Badung | Diunduh oleh: ' . htmlspecialchars($namaGuru) . ' | Tanggal: ' . date('d/m/Y H:i') . ' WITA</div>';

        foreach ($targetKelas as $currentKelas) {
            $tingkat = 'X';
            if (str_starts_with($currentKelas, 'XII ') || $currentKelas === 'XII') {
                $tingkat = 'XII';
            } elseif (str_starts_with($currentKelas, 'XI ') || $currentKelas === 'XI') {
                $tingkat = 'XI';
            }

            $tabelMurid = match ($tingkat) {
                'XI'  => 'tb_murid_xi',
                'XII' => 'tb_murid_xii',
                default => 'tb_murid_x',
            };
            $nisCol = match ($tingkat) {
                'XI'  => 'nis_xi',
                'XII' => 'nis_xii',
                default => 'nis_x',
            };
            $tabelAbsen = match ($tingkat) {
                'XI'  => 'tb_absen_murid_xi',
                'XII' => 'tb_absen_murid_xii',
                default => 'tb_absen_murid_x',
            };

            $students = DB::table($tabelMurid)
                ->where('kelas', $currentKelas)
                ->orderBy('absen')
                ->orderBy('nama')
                ->get();

            $html .= '<h3 style="margin-top: 20px; color: #1e3a8a;">Kelas: ' . htmlspecialchars($currentKelas) . ' &mdash; Tahun Ajaran ' . $tahunAjaran . '</h3>';
            $html .= '<table>';
            $html .= '<thead>';
            $html .= '<tr>
                <th class="center" style="width: 40px;">No.</th>
                <th class="center" style="width: 90px;">NIS</th>
                <th class="left" style="width: 250px;">Nama Siswa</th>
                <th class="center" style="width: 90px;">L/P</th>
                <th class="center" style="width: 80px;">Hadir (H)</th>
                <th class="center" style="width: 80px;">Sakit (S)</th>
                <th class="center" style="width: 80px;">Izin (I)</th>
                <th class="center" style="width: 80px;">Alpa (A)</th>
                <th class="center" style="width: 100px;">Total Hari</th>
                <th class="center" style="width: 100px;">Kehadiran (%)</th>
            </tr>';
            $html .= '</thead><tbody>';

            $no = 1;
            foreach ($students as $st) {
                $nisVal = $st->$nisCol;

                $stats = DB::table($tabelAbsen)
                    ->where($nisCol, $nisVal)
                    ->whereBetween('tanggal', [$awalTA, $akhirTA])
                    ->select(
                        DB::raw("COUNT(*) as total"),
                        DB::raw("SUM(CASE WHEN status = 'H' THEN 1 ELSE 0 END) as h"),
                        DB::raw("SUM(CASE WHEN status = 'S' THEN 1 ELSE 0 END) as s"),
                        DB::raw("SUM(CASE WHEN status = 'I' THEN 1 ELSE 0 END) as i"),
                        DB::raw("SUM(CASE WHEN status = 'A' THEN 1 ELSE 0 END) as a")
                    )
                    ->first();

                $h = $stats ? (int) $stats->h : 0;
                $s = $stats ? (int) $stats->s : 0;
                $i = $stats ? (int) $stats->i : 0;
                $a = $stats ? (int) $stats->a : 0;
                $total = $stats ? (int) $stats->total : 0;
                $pct = $total > 0 ? round(($h / $total) * 100, 1) : 100;

                $html .= '<tr>';
                $html .= '<td class="center">' . $no++ . '</td>';
                $html .= '<td class="center">' . $nisVal . '</td>';
                $html .= '<td class="left">' . htmlspecialchars($st->nama) . '</td>';
                $html .= '<td class="center">' . ($st->kelamin ?? '-') . '</td>';
                $html .= '<td class="center hadir">' . $h . '</td>';
                $html .= '<td class="center sakit">' . $s . '</td>';
                $html .= '<td class="center izin">' . $i . '</td>';
                $html .= '<td class="center alpa">' . $a . '</td>';
                $html .= '<td class="center">' . $total . '</td>';
                $html .= '<td class="center" style="font-weight: bold;">' . $pct . '%</td>';
                $html .= '</tr>';
            }

            $html .= '</tbody></table>';
        }

        $html .= '</body></html>';

        return response($html, 200, [
            'Content-Type'        => 'application/vnd.ms-excel; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            'Cache-Control'       => 'max-age=0',
        ]);
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Models\AkunMurid;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        // Periksa tabel akun admin, guru, dan murid
        $daftarAkun = [
            'admin' => 'tb_akun_admin',
            'guru'  => 'tb_akun_guru',
            'murid' => 'tb_akun_murid',
        ];

        foreach ($daftarAkun as $jenis => $tabel) {
            $akun = DB::table($tabel)
                ->where('email', $request->email)
                ->first();

            // Jika email ditemukan dan password cocok (hash bcrypt atau plain text)
            if ($akun && (Hash::check($request->password, $akun->password) || $request->password === $akun->password)) {
                $request->session()->regenerate();

                $sessionData = [
                    'sudah_login' => true,
                    'jenis_akun'  => $jenis,
                    'email_akun'  => $akun->email,
                ];

                // Cek apakah akun guru
                if ($jenis === 'guru') {
                    $guruModel = \App\Models\AkunGuru::find($akun->id);
                    if ($guruModel) {
                        Auth::guard('guru')->login($guruModel);
                        $sessionData['kode_guru']  = $guruModel->kode_guru;
                        $sessionData['nama_guru']  = $guruModel->nama;
                        $sessionData['mapel_guru'] = $guruModel->mapel;
                    } else {
                        $guruRow = DB::table('tb_guru')->where('kode_guru', $akun->kode_guru)->first();
                        $sessionData['kode_guru']  = $akun->kode_guru;
                        $sessionData['nama_guru']  = $guruRow ? $guruRow->nama : $akun->email;
                        $sessionData['mapel_guru'] = $guruRow ? $guruRow->mapel : '-';
                    }

                    $isGuruPiket = DB::table('tb_guru_piket')
                        ->where('kode_guru', $akun->kode_guru)
                        ->exists();

                    if ($isGuruPiket) {
                        $sessionData['is_guru_piket'] = true;
                    }
                }

                // Cek akun murid
                if ($jenis === 'murid') {
                    $muridModel = AkunMurid::find($akun->id);
                    if ($muridModel) {
                        Auth::guard('murid')->login($muridModel);
                        $sessionData['nama_murid'] = $muridModel->nama;
                        $sessionData['kelas_murid'] = $muridModel->kelas;
                    }
                }

                $request->session()->put($sessionData);

                // Arahkan ke dashboard sesuai jenis akun
                return match ($sessionData['jenis_akun']) {
                    'admin'      => redirect()->route('admin.dashboard'),
                    'guru_piket' => redirect()->route('piket.status'),
                    'guru'       => redirect()->route('guru.dashboard'),
                    'murid'      => redirect()->route('siswa.dashboard'),
                };
            }
        }

        return back()
            ->withErrors([
                'email' => 'Email atau password salah.',
            ])
            ->onlyInput('email');
    }

    public function logout(Request $request)
    {
        if (Auth::guard('murid')->check()) {
            Auth::guard('murid')->logout();
        }
        if (Auth::guard('guru')->check()) {
            Auth::guard('guru')->logout();
        }

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}

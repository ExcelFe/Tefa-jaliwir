<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Akun yang sudah login tidak boleh membuka halaman login atau login ke akun lain.
 * Ia diarahkan kembali ke dashboard akunnya sendiri sampai menekan logout.
 */
class RedirectJikaSudahLogin
{
    public function handle(Request $request, Closure $next): Response
    {
        if ($request->session()->get('sudah_login')) {
            $tujuan = match ($request->session()->get('jenis_akun')) {
                'admin' => route('admin.dashboard'),
                'guru'  => route('guru.dashboard'),
                'murid' => route('siswa.dashboard'),
                default => null,
            };

            if ($tujuan !== null) {
                return redirect($tujuan)
                    ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');
            }
        }

        $response = $next($request);

        // Halaman login tidak boleh di-cache agar tombol "back" setelah logout tidak menampilkan data lama.
        $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');

        return $response;
    }
}

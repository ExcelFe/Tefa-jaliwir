<?php

require __DIR__ . '/../vendor/autoload.php';
$app = require_once __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;

if (!Schema::hasTable('tb_piket_pengganti')) {
    Schema::create('tb_piket_pengganti', function (Blueprint $table) {
        $table->id();
        $table->integer('kode_guru');
        $table->date('tanggal');
        $table->string('shift', 50)->default('semua');
        $table->integer('kode_guru_asli')->nullable();
        $table->string('keterangan', 255)->nullable();
        $table->timestamps();
    });
    echo "Table tb_piket_pengganti created.\n";
} else {
    echo "Table tb_piket_pengganti already exists.\n";
}

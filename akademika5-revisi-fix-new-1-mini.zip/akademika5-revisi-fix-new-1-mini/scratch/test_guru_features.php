<?php

require __DIR__ . '/../vendor/autoload.php';
$app = require_once __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;
use App\Models\AkunGuru;

$akunGuru = AkunGuru::first();
if (!$akunGuru) {
    echo "No teacher account found\n";
    exit(1);
}

echo "Testing with teacher: " . $akunGuru->email . " (kode_guru: " . $akunGuru->kode_guru . ")\n";

session([
    'sudah_login' => true,
    'role' => 'guru',
    'email_akun' => $akunGuru->email,
    'kode_guru' => $akunGuru->kode_guru,
    'nama_guru' => $akunGuru->nama,
    'mapel_guru' => $akunGuru->mapel,
]);

// Test routes via request
$controller = app()->make(App\Http\Controllers\GuruController::class);

// 1. Jadwal
$request = Illuminate\Http\Request::create('/guru/jadwal', 'GET');
$res = $controller->jadwal($request);
echo "Jadwal rendered successfully, status: " . ($res ? "OK" : "FAIL") . "\n";

// 2. Absen
$request = Illuminate\Http\Request::create('/guru/absen', 'GET');
$res = $controller->absen($request);
echo "Absen rendered successfully, status: " . ($res ? "OK" : "FAIL") . "\n";

// 3. Jurnal
$request = Illuminate\Http\Request::create('/guru/jurnal', 'GET');
$res = $controller->jurnal($request);
echo "Jurnal rendered successfully, status: " . ($res ? "OK" : "FAIL") . "\n";

// 4. Rekap
$request = Illuminate\Http\Request::create('/guru/rekap', 'GET');
$res = $controller->rekap($request);
echo "Rekap rendered successfully, status: " . ($res ? "OK" : "FAIL") . "\n";

// 5. Export
$request = Illuminate\Http\Request::create('/guru/rekap/export/all', 'GET');
$res = $controller->exportRekap($request, 'all');
echo "Export Excel stream created, header Content-Type: " . $res->headers->get('content-type') . "\n";

// 6. Test get siswa
$request = Illuminate\Http\Request::create('/guru/absen/siswa?kelas=XI+PPLG+1&tanggal=2026-10-26', 'GET');
$res = $controller->getSiswaByKelas($request);
$data = json_decode($res->getContent(), true);
echo "Siswa returned for XI PPLG 1: " . count($data['siswa'] ?? []) . " students\n";

echo "ALL TESTS PASSED!\n";

<?php

require __DIR__ . '/../vendor/autoload.php';
$app = require_once __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;

$rawMapels = DB::table('tb_guru')->pluck('mapel');
$unique = collect();
foreach ($rawMapels as $m) {
    if (empty($m)) continue;
    $parts = explode(',', $m);
    foreach ($parts as $p) {
        $trimmed = trim($p);
        if (!empty($trimmed)) $unique->push($trimmed);
    }
}
$list = $unique->unique()->sort()->values()->toArray();
echo json_encode($list, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);

<?php
require __DIR__ . '/../vendor/autoload.php';
$app = require_once __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\Hash;

$hash = '$2y$12$ShidiQZNZ7KvAT9cWxy8bev9cjI.afwHB2YD5Mn5NrfCvWOgOwWUS';
$passwords = ['guru', 'guru123', 'password', '12345678', '123456', 'smktibali', 'smktibadung', 'globaliti', 'indra', '123', 'admin'];
foreach ($passwords as $p) {
    if (Hash::check($p, $hash)) {
        echo "FOUND GURU PASS: $p\n";
    }
}

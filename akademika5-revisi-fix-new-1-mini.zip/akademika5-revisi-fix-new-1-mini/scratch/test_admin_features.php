<?php

require __DIR__ . '/../vendor/autoload.php';
$app = require_once __DIR__ . '/../bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use Illuminate\Support\Facades\DB;

session([
    'sudah_login' => true,
    'jenis_akun'  => 'admin',
    'email_akun'  => 'adminakademik@smkti.akademik.id',
]);

$controller = app()->make(App\Http\Controllers\AdminController::class);

// 1. Status
$req = Illuminate\Http\Request::create('/admin/status', 'GET');
$res = $controller->status($req);
echo "Admin Status: OK\n";

// 2. Piket
$req = Illuminate\Http\Request::create('/admin/piket', 'GET');
$res = $controller->piket($req);
echo "Admin Piket: OK\n";

// 3. Rekap Siswa
$req = Illuminate\Http\Request::create('/admin/rekap-siswa', 'GET');
$res = $controller->rekapSiswa($req);
echo "Admin Rekap Siswa: OK\n";

// 4. Rekap Guru
$req = Illuminate\Http\Request::create('/admin/rekap-guru', 'GET');
$res = $controller->rekapGuru($req);
echo "Admin Rekap Guru: OK\n";

// 5. Rekap Jurnal
$req = Illuminate\Http\Request::create('/admin/rekap-jurnal', 'GET');
$res = $controller->rekapJurnal($req);
echo "Admin Rekap Jurnal: OK\n";

echo "ALL ADMIN ENDPOINTS VERIFIED!\n";

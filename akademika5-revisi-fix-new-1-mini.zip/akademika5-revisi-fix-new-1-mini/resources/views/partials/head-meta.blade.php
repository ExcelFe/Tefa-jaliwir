{{-- HEAD META: title, description, favicon set, Open Graph, Twitter.
     Pakai: @include('partials.head-meta', ['title' => '...', 'description' => '...'])
     Opsional: 'robots' => 'noindex, nofollow' (halaman setelah login), 'ogImage' => 'media/xxx.jpg' --}}
@php
    $metaTitle = $title ?? config('site.nama');
    $metaDesc  = $description ?? config('site.deskripsi');
    $metaImage = asset($ogImage ?? 'media/og-image.jpg');
@endphp
<title>{{ $metaTitle }}</title>
<meta name="description" content="{{ $metaDesc }}">
@if (!empty($robots))
<meta name="robots" content="{{ $robots }}">
@endif
<meta name="theme-color" content="#1d4ed8">

{{-- Favicon set --}}
<link rel="icon" href="{{ asset('favicon.ico') }}" sizes="any">
<link rel="icon" type="image/png" sizes="32x32" href="{{ asset('favicon-32x32.png') }}">
<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('favicon-16x16.png') }}">
<link rel="apple-touch-icon" sizes="180x180" href="{{ asset('apple-touch-icon.png') }}">
<link rel="manifest" href="{{ asset('site.webmanifest') }}">

{{-- Open Graph + Twitter (pratinjau saat link dibagikan) --}}
<meta property="og:type" content="website">
<meta property="og:site_name" content="{{ config('site.nama') }}">
<meta property="og:locale" content="id_ID">
<meta property="og:title" content="{{ $metaTitle }}">
<meta property="og:description" content="{{ $metaDesc }}">
<meta property="og:url" content="{{ url()->current() }}">
<meta property="og:image" content="{{ $metaImage }}">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="Logo dan nama {{ config('site.nama') }}">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{{ $metaTitle }}">
<meta name="twitter:description" content="{{ $metaDesc }}">
<meta name="twitter:image" content="{{ $metaImage }}">

{{-- NAVBAR halaman publik tambahan (404, privasi, S&K). $active = 'welcome' | 'profil' | 'program' | null --}}
<header class="navbar">
    <div class="container navbar-inner">
        <a href="{{ route('welcome') }}" class="brand">
            <div class="img-slot logo-slot"><img src="{{ asset('media/logo.webp') }}" alt="Logo SMK TI Bali Global Badung"></div>
            <span>SMK TI<br><span class="brand-sub">Bali Global Badung</span></span>
        </a>
        <button type="button" class="nav-toggle" aria-label="Buka menu" aria-expanded="false" aria-controls="nav-panel">
            <span class="nav-toggle-bar"></span>
        </button>
        <div class="nav-panel" id="nav-panel">
            <div class="nav-panel-inner">
                <nav class="nav-links" aria-label="Navigasi utama">
                    <a href="{{ route('welcome') }}"@if (($active ?? null) === 'welcome') class="is-active" aria-current="page"@endif>Beranda</a>
                    <a href="{{ route('profil') }}"@if (($active ?? null) === 'profil') class="is-active" aria-current="page"@endif>Profil Manajemen</a>
                    <a href="{{ route('program') }}"@if (($active ?? null) === 'program') class="is-active" aria-current="page"@endif>Program Sekolah</a>
                </nav>
                <a href="{{ route('login') }}" class="btn-login">Login <i class="fa-solid fa-arrow-right-to-bracket" aria-hidden="true"></i></a>
            </div>
        </div>
    </div>
</header>

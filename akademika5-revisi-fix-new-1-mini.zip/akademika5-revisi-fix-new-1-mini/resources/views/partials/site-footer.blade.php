{{-- FOOTER: dipakai semua halaman publik. Data kontak: config/site.php --}}
<footer class="footer">
    <div class="container footer-grid">
        <div>
            <div class="brand">
                <div class="img-slot logo-slot lg"><img src="{{ asset('media/logo.webp') }}" alt="Logo SMK TI Bali Global Badung"></div>
                <span>SMK TI<br><span class="brand-sub">Bali Global Badung</span></span>
            </div>
            <p class="footer-desc">Sekolah kejuruan berbasis teknologi informasi yang mencetak lulusan kompeten, berkarakter, dan siap bersaing di era digital.</p>
            <!-- Social links: ubah di config/site.php -->
            <div class="sosmed">
                <a href="{{ config('site.sosmed.instagram') }}" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                <a href="{{ config('site.sosmed.facebook') }}" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><i class="fa-brands fa-facebook"></i></a>
                <a href="{{ config('site.sosmed.tiktok') }}" target="_blank" rel="noopener noreferrer" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                <a href="{{ config('site.sosmed.youtube') }}" target="_blank" rel="noopener noreferrer" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a>
            </div>
        </div>
        <div>
            <h3>Navigasi</h3>
            <ul>
                <li><a href="{{ route('welcome') }}">Beranda</a></li>
                <li><a href="{{ route('profil') }}">Profil Manajemen</a></li>
                <li><a href="{{ route('program') }}">Program Sekolah</a></li>
                <li><a href="{{ route('welcome') }}#fasilitas">Fasilitas</a></li>
            </ul>
        </div>
        <div>
            <h3>Program Studi</h3>
            <ul>
                <li><a href="{{ route('program') }}#tjkt">TJKT</a></li>
                <li><a href="{{ route('program') }}#pplg">PPLG</a></li>
                <li><a href="{{ route('program') }}#dkv">DKV</a></li>
                <li><a href="{{ route('program') }}#bd">BD</a></li>
            </ul>
        </div>
        <div>
            <h3>Kontak</h3>
            <ul class="footer-contact">
                <li><i class="fa-solid fa-location-dot" aria-hidden="true"></i><a href="{{ config('site.maps_url') }}" target="_blank" rel="noopener noreferrer">{{ config('site.alamat') }}</a></li>
                <li><i class="fa-solid fa-phone" aria-hidden="true"></i><a href="tel:{{ config('site.telepon_tel') }}">{{ config('site.telepon') }}</a></li>
                <li><i class="fa-brands fa-whatsapp" aria-hidden="true"></i><a href="https://wa.me/{{ config('site.whatsapp_id') }}" target="_blank" rel="noopener noreferrer">{{ config('site.whatsapp') }}</a></li>
                <li><i class="fa-solid fa-envelope" aria-hidden="true"></i><a href="mailto:{{ config('site.email') }}">{{ config('site.email') }}</a></li>
            </ul>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <p>&copy; {{ date('Y') }} {{ config('site.nama') }}. All rights reserved.</p>
            <nav aria-label="Informasi hukum"><a href="{{ route('privacy') }}">Kebijakan privasi</a><a href="{{ route('terms') }}">Syarat &amp; Ketentuan</a></nav>
        </div>
    </div>
</footer>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jurnal Kelas - Dashboard Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .jurnal-meta-tag {
            display: inline-flex;
            align-items: center;
            padding: 0.15rem 0.55rem;
            border-radius: var(--radius-pill);
            font-size: 0.72rem;
            font-weight: 600;
            background: rgba(59, 130, 246, 0.1);
            color: #2563eb;
            margin-right: 0.4rem;
        }
        [data-theme="dark"] .jurnal-meta-tag {
            background: rgba(96, 165, 250, 0.18);
            color: #93c5fd;
        }
        .dash-card__desc {
            font-size: 0.825rem;
            color: var(--dash-muted);
            margin-top: 0.35rem;
            line-height: 1.4;
        }
        .dash-card__keterangan {
            font-size: 0.75rem;
            font-style: italic;
            color: var(--dash-muted);
            margin-top: 0.2rem;
        }
        .alert-toast {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid #86efac;
            padding: 0.75rem 1.25rem;
            border-radius: var(--radius-md);
            margin-bottom: 1rem;
            font-size: 0.875rem;
            font-weight: 600;
        }
        .alert-toast--danger {
            background: #fee2e2;
            color: #b91c1c;
            border-color: #fca5a5;
        }
        .dash-action-group {
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }
        .btn-delete-jurnal {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 0.4rem;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.7;
            transition: opacity 0.2s, background 0.2s;
        }
        .btn-delete-jurnal:hover {
            opacity: 1;
            background: rgba(239, 68, 68, 0.1);
        }
        .btn-delete-jurnal svg {
            width: 18px;
            height: 18px;
            fill: #ef4444;
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru">
                <a class="dash-menu__item" href="{{ route('guru.jadwal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
                <a class="dash-menu__item" href="{{ route('guru.absen') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24">
                    Absen Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('guru.jurnal') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Jurnal Kelas
                </a>
                <a class="dash-menu__item" href="{{ route('guru.rekap') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Absensi
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" title="{{ $namaGuru }}" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">{{ $namaGuru }}</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">{{ $mapelGuru }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-guru-jurnal').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-guru-jurnal" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @if(session('success'))
                    <div class="alert-toast">
                        {{ session('success') }}
                    </div>
                @endif
                @if(session('error'))
                    <div class="alert-toast alert-toast--danger">
                        {{ session('error') }}
                    </div>
                @endif

                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Log Jurnal Kelas</h1>
                    </div>
                    <div class="dash-tools">
                        <form method="GET" action="{{ route('guru.jurnal') }}" class="dash-search" role="search">
                            <input type="search" name="q" value="{{ $search }}" placeholder="Cari jurnal..." aria-label="Search log">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </form>

                        <button type="button" class="dash-btn" id="btn-tambah-jurnal" data-modal-open="modal-jurnal">
                            Tambah Jurnal
                            <img class="dash-icon" src="{{ asset('media/vector/add-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>

                <ul class="dash-list">
                    @forelse($jurnals as $jurnal)
                        <li class="dash-item" data-jurnal-item>
                            <div class="dash-card">
                                <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                    <span class="dash-card__name">{{ $jurnal->kelas }}</span>
                                    <span class="jurnal-meta-tag">Jam ke-{{ $jurnal->jam_sekolah }}</span>
                                    <span class="jurnal-meta-tag">Pertemuan {{ $jurnal->pertemuan }}</span>
                                </div>
                                <span class="dash-card__meta">{{ $jurnal->tanggal_formatted }} &bull; {{ $jurnal->nama_mapel }}</span>
                                <div class="dash-card__desc">
                                    <strong>Materi:</strong> {{ $jurnal->sub_kompetensi }}
                                </div>
                                @if(!empty($jurnal->keterangan))
                                    <div class="dash-card__keterangan">
                                        Catatan: {{ $jurnal->keterangan }}
                                    </div>
                                @endif
                            </div>
                            <div class="dash-action-group">
                                <button type="button" class="dash-action btn-edit-jurnal"
                                    data-id="{{ $jurnal->id }}"
                                    data-tanggal="{{ $jurnal->tanggal }}"
                                    data-jam="{{ $jurnal->jam_sekolah }}"
                                    data-kelas="{{ $jurnal->kelas }}"
                                    data-mapel="{{ $jurnal->nama_mapel }}"
                                    data-pertemuan="{{ $jurnal->pertemuan }}"
                                    data-sub="{{ $jurnal->sub_kompetensi }}"
                                    data-keterangan="{{ $jurnal->keterangan }}"
                                    aria-label="Edit jurnal {{ $jurnal->kelas }}, {{ $jurnal->tanggal_formatted }}">
                                    <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                                </button>
                                <form action="{{ route('guru.jurnal.hapus', $jurnal->id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus jurnal ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-delete-jurnal" title="Hapus Jurnal">
                                        <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </form>
                            </div>
                        </li>
                    @empty
                        <li class="dash-item" style="padding: 2.5rem 1rem; text-align: center; color: var(--dash-muted); display: block;">
                            <p style="font-size: 0.95rem;">Belum ada log jurnal kelas yang tercatat.</p>
                            <small>Klik tombol <strong>"Tambah Jurnal"</strong> di atas untuk membuat entri jurnal mengajar.</small>
                        </li>
                    @endforelse
                </ul>
            </div>
        </main>
    </div>

    <!-- Pop-up: Form Tambah/Edit Jurnal -->
    <div class="dash-modal" id="modal-jurnal" role="dialog" aria-modal="true" aria-labelledby="modal-jurnal-title">
        <form class="dash-modal__box" id="form-jurnal" action="{{ route('guru.jurnal.simpan') }}" method="post" tabindex="-1">
            @csrf
            <input type="hidden" name="id" id="jurnal-id" value="">

            <div class="dash-modal__head">
                <h2 class="dash-modal__title" id="modal-jurnal-title">Tambah Jurnal</h2>
            </div>
            <div class="dash-modal__body">
                <div class="dash-form-grid">
                    <!-- Hari / Tanggal: calendar input -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-tanggal">Hari / Tanggal</label>
                        <input class="dash-input dash-input--center" type="date" id="jurnal-tanggal" name="tanggal" value="{{ date('Y-m-d') }}" required>
                    </div>

                    <!-- Jam ke-: 1 huruf/angka saja input nya (sesuai permintaan user) -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-jam">Jam ke-</label>
                        <input class="dash-input dash-input--center" type="number" id="jurnal-jam" name="jam_sekolah" placeholder="1" min="1" max="15" required>
                    </div>

                    <!-- Kelas: Dropdown -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-kelas">Kelas</label>
                        <div class="dash-select">
                            <select class="dash-input" id="jurnal-kelas" name="kelas" required>
                                <option value="" selected disabled>Pilih Kelas</option>
                                @foreach($daftarKelas as $k)
                                    <option value="{{ $k }}">{{ $k }}</option>
                                @endforeach
                            </select>
                            <img class="dash-icon" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </div>
                    </div>

                    <!-- Mata Pelajaran: select dropdown populated from official teacher subjects -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-mapel">Mata Pelajaran</label>
                        <div class="dash-select">
                            <select class="dash-input" id="jurnal-mapel" name="nama_mapel" required>
                                <option value="" selected disabled>Pilih Mata Pelajaran</option>
                                @foreach($daftarMapel as $m)
                                    <option value="{{ $m }}" @selected($m === $mapelDefault)>{{ $m }}</option>
                                @endforeach
                            </select>
                            <img class="dash-icon" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </div>
                    </div>

                    <!-- Pertemuan ke-: 1 number input -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-pertemuan">Pertemuan ke-</label>
                        <input class="dash-input dash-input--center" type="number" id="jurnal-pertemuan" name="pertemuan" placeholder="1" min="1" required>
                    </div>

                    <!-- Keterangan / Status Mengajar -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-keterangan">Keterangan</label>
                        <input class="dash-input" type="text" id="jurnal-keterangan" name="keterangan" placeholder="berjalan normal / terlambat / daring" value="berjalan normal">
                    </div>

                    <!-- Sub-Kompetensi / Materi Pokok: text area -->
                    <div class="dash-field dash-field--full">
                        <label class="dash-label" for="jurnal-sub">Sub-Kompetensi / Materi Pokok</label>
                        <textarea class="dash-input" id="jurnal-sub" name="sub_kompetensi" rows="3" placeholder="Uraian ringkas materi yang diajarkan pada pertemuan ini..." required></textarea>
                    </div>
                </div>
            </div>
            <div class="dash-modal__foot">
                <button type="button" class="dash-btn dash-btn--ghost" data-modal-close>Batal</button>
                <button type="submit" class="dash-btn">Simpan</button>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const formJurnal = document.getElementById('form-jurnal');
            const modalTitle = document.getElementById('modal-jurnal-title');
            const inputId = document.getElementById('jurnal-id');
            const inputTanggal = document.getElementById('jurnal-tanggal');
            const inputJam = document.getElementById('jurnal-jam');
            const inputKelas = document.getElementById('jurnal-kelas');
            const inputMapel = document.getElementById('jurnal-mapel');
            const inputPertemuan = document.getElementById('jurnal-pertemuan');
            const inputKeterangan = document.getElementById('jurnal-keterangan');
            const inputSub = document.getElementById('jurnal-sub');
            const defaultMapel = @json($mapelDefault);

            // Handler tombol Tambah Jurnal (Reset Form)
            const btnTambah = document.getElementById('btn-tambah-jurnal');
            if (btnTambah) {
                btnTambah.addEventListener('click', () => {
                    modalTitle.textContent = 'Tambah Jurnal';
                    inputId.value = '';
                    inputTanggal.value = new Date().toISOString().split('T')[0];
                    inputJam.value = '';
                    inputKelas.value = '';
                    inputMapel.value = defaultMapel || '';
                    inputPertemuan.value = '1';
                    inputKeterangan.value = 'berjalan normal';
                    inputSub.value = '';
                });
            }

            // Handler tombol Edit Jurnal
            document.querySelectorAll('.btn-edit-jurnal').forEach(btn => {
                btn.addEventListener('click', () => {
                    modalTitle.textContent = 'Edit Jurnal';
                    inputId.value = btn.getAttribute('data-id');
                    inputTanggal.value = btn.getAttribute('data-tanggal');
                    inputJam.value = btn.getAttribute('data-jam');
                    inputKelas.value = btn.getAttribute('data-kelas');
                    inputMapel.value = btn.getAttribute('data-mapel');
                    inputPertemuan.value = btn.getAttribute('data-pertemuan');
                    inputKeterangan.value = btn.getAttribute('data-keterangan') || 'berjalan normal';
                    inputSub.value = btn.getAttribute('data-sub');

                    // Buka modal
                    const modal = document.getElementById('modal-jurnal');
                    if (modal) {
                        modal.classList.add('is-open');
                    }
                });
            });
        });
    </script>
</body>
</html>

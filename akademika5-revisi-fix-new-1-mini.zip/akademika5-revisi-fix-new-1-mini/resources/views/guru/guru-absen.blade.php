<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absen Siswa - Dashboard Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .absen-stats-tag {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            margin-right: 0.5rem;
            font-size: 0.75rem;
            font-weight: 600;
        }
        .absen-stats-tag--hadir { color: #15803d; }
        .absen-stats-tag--sakit { color: #1d4ed8; }
        .absen-stats-tag--izin { color: #b45309; }
        .absen-stats-tag--alpa { color: #b91c1c; }

        .alert-toast {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid #86efac;
            padding: 0.75rem 1.25rem;
            border-radius: var(--radius-md);
            margin-bottom: 1rem;
            font-size: 0.875rem;
            font-weight: 600;
        }
        .alert-toast--danger {
            background: #fee2e2;
            color: #b91c1c;
            border-color: #fca5a5;
        }
        .dash-action-group {
            display: flex;
            align-items: center;
            gap: 0.4rem;
        }
        .btn-delete-absen {
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 0.4rem;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0.7;
            transition: opacity 0.2s, background 0.2s;
        }
        .btn-delete-absen:hover {
            opacity: 1;
            background: rgba(239, 68, 68, 0.1);
        }
        .btn-delete-absen svg {
            width: 18px;
            height: 18px;
            fill: #ef4444;
        }
        .loading-spinner {
            text-align: center;
            padding: 2rem;
            color: var(--dash-muted);
            font-size: 0.9rem;
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru">
                <a class="dash-menu__item" href="{{ route('guru.jadwal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
                <a class="dash-menu__item" href="{{ route('guru.absen') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24">
                    Absen Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('guru.jurnal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Jurnal Kelas
                </a>
                <a class="dash-menu__item" href="{{ route('guru.rekap') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Absensi
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" title="{{ $namaGuru }}" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">{{ $namaGuru }}</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">{{ $mapelGuru }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-guru-absen').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-guru-absen" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @if(session('success'))
                    <div class="alert-toast">
                        {{ session('success') }}
                    </div>
                @endif
                @if(session('error'))
                    <div class="alert-toast alert-toast--danger">
                        {{ session('error') }}
                    </div>
                @endif

                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Log Absensi Siswa</h1>
                    </div>
                    <div class="dash-tools">
                        <form method="GET" action="{{ route('guru.absen') }}" class="dash-search" role="search">
                            <input type="search" name="q" value="{{ $search }}" placeholder="Cari log kelas/tanggal..." aria-label="Search log">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </form>
                        <button type="button" class="dash-btn" id="btn-open-absen-modal" data-modal-open="modal-absen">
                            Mulai Absensi
                            <img class="dash-icon" src="{{ asset('media/vector/add-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>

                <!-- Filter Log Absensi -->
                <form method="GET" action="{{ route('guru.absen') }}" class="log-filter-bar" aria-label="Filter log absensi">
                    @if ($search !== '')
                        <input type="hidden" name="q" value="{{ $search }}">
                    @endif
                    <div class="log-filter-bar__field">
                        <label for="f-tingkat">Tingkat</label>
                        <select id="f-tingkat" name="tingkat">
                            <option value="">Semua</option>
                            @foreach ($daftarTingkat as $t)
                                <option value="{{ $t }}" @selected($filterTingkat === $t)>Kelas {{ $t }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="log-filter-bar__field">
                        <label for="f-kelas">Kelas</label>
                        <select id="f-kelas" name="kelas">
                            <option value="">Semua</option>
                            @foreach ($daftarKelas as $k)
                                <option value="{{ $k }}" @selected($filterKelas === $k)>{{ $k }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="log-filter-bar__field">
                        <label for="f-status">Ada siswa</label>
                        <select id="f-status" name="status">
                            <option value="">Semua status</option>
                            <option value="H" @selected($filterStatus === 'H')>Hadir</option>
                            <option value="S" @selected($filterStatus === 'S')>Sakit</option>
                            <option value="I" @selected($filterStatus === 'I')>Izin</option>
                            <option value="A" @selected($filterStatus === 'A')>Alpa</option>
                        </select>
                    </div>
                    <div class="log-filter-bar__field">
                        <label for="f-dari">Dari tanggal</label>
                        <input type="date" id="f-dari" name="dari" value="{{ $filterDari }}">
                    </div>
                    <div class="log-filter-bar__field">
                        <label for="f-sampai">Sampai tanggal</label>
                        <input type="date" id="f-sampai" name="sampai" value="{{ $filterSampai }}">
                    </div>
                    <div class="log-filter-bar__actions">
                        <button type="submit" class="dash-btn">Terapkan</button>
                        @if ($adaFilter)
                            <a href="{{ route('guru.absen') }}" class="dash-btn dash-btn--ghost" style="text-decoration: none;">Reset</a>
                        @endif
                    </div>
                </form>

                <ul class="dash-list">
                    @forelse($allLogs as $log)
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">{{ $log->kelas }}</span>
                                <span class="dash-card__meta">{{ $log->tanggal_formatted }}</span>
                                <div style="margin-top: 0.35rem;">
                                    <span class="absen-stats-tag absen-stats-tag--hadir">Hadir: {{ $log->hadir }}</span>
                                    <span class="absen-stats-tag absen-stats-tag--sakit">Sakit: {{ $log->sakit }}</span>
                                    <span class="absen-stats-tag absen-stats-tag--izin">Izin: {{ $log->izin }}</span>
                                    <span class="absen-stats-tag absen-stats-tag--alpa">Alpa: {{ $log->alpa }}</span>
                                </div>
                            </div>
                            <div class="dash-action-group">
                                <button type="button" class="dash-action btn-edit-absen"
                                    data-kelas="{{ $log->kelas }}"
                                    data-tanggal="{{ $log->tanggal }}"
                                    aria-label="Edit absensi {{ $log->kelas }}, {{ $log->tanggal_formatted }}">
                                    <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                                </button>
                                <form action="{{ route('guru.absen.hapus') }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus log absensi kelas {{ $log->kelas }} pada tanggal {{ $log->tanggal }}?');">
                                    @csrf
                                    @method('DELETE')
                                    <input type="hidden" name="kelas" value="{{ $log->kelas }}">
                                    <input type="hidden" name="tanggal" value="{{ $log->tanggal }}">
                                    <button type="submit" class="btn-delete-absen" title="Hapus Log Absensi">
                                        <svg viewBox="0 0 24 24"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </form>
                            </div>
                        </li>
                    @empty
                        <li class="dash-item" style="padding: 2.5rem 1rem; text-align: center; color: var(--dash-muted); display: block;">
                            <p style="font-size: 0.95rem;">{{ $adaFilter ? 'Tidak ada log absensi yang cocok dengan filter.' : 'Belum ada riwayat absensi siswa.' }}</p>
                            <small>Klik tombol <strong>"Mulai Absensi"</strong> di atas untuk melakukan presensi siswa di kelas.</small>
                        </li>
                    @endforelse
                </ul>
            </div>
        </main>
    </div>

    <!-- Pop-up: Mulai / Edit Absensi -->
    <div class="dash-modal" id="modal-absen" role="dialog" aria-modal="true" aria-labelledby="modal-absen-title">
        <form class="dash-modal__box dash-modal__box--wide" id="form-absen-siswa" action="{{ route('guru.absen.simpan') }}" method="post" tabindex="-1">
            @csrf
            <div class="dash-modal__head">
                <div class="dash-modal__head-row">
                    <button type="button" class="dash-modal__back-btn" id="btn-modal-back" aria-label="Kembali ke langkah sebelumnya" style="display: none;">
                        <img class="dash-icon" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="20" height="20" style="transform: rotate(180deg);">
                    </button>
                    <h2 class="dash-modal__title" id="modal-absen-title">Pilih Kelas / Rombel</h2>
                </div>
            </div>

            <!-- Step 1: Pilih Kelas Dari Daftar Lengkap -->
            <div class="dash-modal__body absen-step is-active" id="step-kelas">
                <p class="absen-step__desc">Silakan pilih kelas dan tanggal presensi yang ingin diisi/diedit:</p>
                <div style="display: flex; gap: 1rem; margin-bottom: 1.25rem; flex-wrap: wrap;">
                    <div style="flex: 1; min-width: 200px;">
                        <label class="dash-label" for="absen-tanggal-input">Tanggal Absensi</label>
                        <input class="dash-input" type="date" id="absen-tanggal-input" name="tanggal" value="{{ date('Y-m-d') }}" required>
                    </div>
                </div>

                @if (empty($daftarKelas))
                    <p style="text-align: center; padding: 1.5rem 1rem; color: var(--dash-muted);">Anda belum memiliki jadwal mengajar di kelas mana pun, sehingga belum ada kelas yang dapat diabsen.</p>
                @endif
                <div class="absen-grid-select" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); gap: 0.75rem; max-height: 340px; overflow-y: auto;">
                    @foreach($daftarKelas as $k)
                        <button type="button" class="absen-choice-card btn-select-kelas-direct" data-kelas="{{ $k }}" style="padding: 0.85rem 0.5rem; text-align: center; border: 1px solid var(--dash-edge); border-radius: 12px; background: var(--dash-surface); cursor: pointer; transition: all 0.2s;">
                            <span style="font-weight: 700; font-size: 0.95rem; color: var(--dash-ink); display: block;">{{ $k }}</span>
                        </button>
                    @endforeach
                </div>
            </div>

            <!-- Step 2: Form Absensi Siswa -->
            <div class="absen-step" id="step-form" style="display: none;">
                <input type="hidden" name="kelas" id="input-final-kelas" value="">
                
                <div class="absen-nihil-bar" style="display: flex; align-items: center; justify-content: space-between; padding: 0.75rem 1.25rem; background: var(--dash-surface); border-bottom: 1px solid var(--dash-edge); border-radius: 12px 12px 0 0;">
                    <span class="absen-nihil-info" id="absen-target-class" style="font-weight: 700; color: var(--dash-ink);">Presensi Kelas</span>
                    <label class="absen-nihil-toggle" for="check-nihil" style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-size: 0.85rem; font-weight: 600; color: #15803d;">
                        <input class="dash-check dash-check--ok" type="checkbox" id="check-nihil">
                        <span>Nihil (Semua Hadir)</span>
                    </label>
                </div>

                <div class="dash-modal__body dash-modal__body--table" style="max-height: 420px; overflow-y: auto; padding: 0;">
                    <div id="table-loading" class="loading-spinner" style="display: none;">
                        Memuat data siswa...
                    </div>
                    <table class="dash-table" id="table-absen-siswa" style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr>
                                <th scope="col" style="width: 50px; text-align: center;">No.</th>
                                <th scope="col" class="dash-table__name">Nama Siswa</th>
                                <th scope="col" style="width: 65px; text-align: center;">Hadir</th>
                                <th scope="col" style="width: 65px; text-align: center;">Sakit</th>
                                <th scope="col" style="width: 65px; text-align: center;">Izin</th>
                                <th scope="col" style="width: 65px; text-align: center;">Alpa</th>
                            </tr>
                        </thead>
                        <tbody id="tbody-absen-siswa">
                            <!-- Populated dynamically via AJAX -->
                        </tbody>
                    </table>
                </div>

                <div class="dash-modal__foot">
                    <button type="button" class="dash-btn dash-btn--ghost" id="btn-back-to-step1">Ganti Kelas</button>
                    <button type="button" class="dash-btn dash-btn--ghost" data-modal-close>Batal</button>
                    <button type="submit" class="dash-btn">Simpan Presensi</button>
                </div>
            </div>

            <!-- Footer Step 1 -->
            <div class="dash-modal__foot" id="step-nav-footer">
                <button type="button" class="dash-btn dash-btn--ghost" data-modal-close>Tutup</button>
            </div>
        </form>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const modalAbsen = document.getElementById('modal-absen');
            const stepKelas = document.getElementById('step-kelas');
            const stepForm = document.getElementById('step-form');
            const stepNavFooter = document.getElementById('step-nav-footer');
            const modalTitle = document.getElementById('modal-absen-title');
            const btnModalBack = document.getElementById('btn-modal-back');
            const btnBackStep = document.getElementById('btn-back-to-step1');
            const inputFinalKelas = document.getElementById('input-final-kelas');
            const inputTanggal = document.getElementById('absen-tanggal-input');
            const targetClassLabel = document.getElementById('absen-target-class');
            const tbody = document.getElementById('tbody-absen-siswa');
            const loading = document.getElementById('table-loading');
            const table = document.getElementById('table-absen-siswa');
            const checkNihil = document.getElementById('check-nihil');

            function goToStep(step) {
                if (step === 1) {
                    stepKelas.style.display = 'block';
                    stepForm.style.display = 'none';
                    stepNavFooter.style.display = 'flex';
                    btnModalBack.style.display = 'none';
                    modalTitle.textContent = 'Pilih Kelas / Rombel';
                } else if (step === 2) {
                    stepKelas.style.display = 'none';
                    stepForm.style.display = 'block';
                    stepNavFooter.style.display = 'none';
                    btnModalBack.style.display = 'inline-flex';
                    modalTitle.textContent = 'Mulai Absensi - ' + inputFinalKelas.value;
                }
            }

            if (btnModalBack) {
                btnModalBack.addEventListener('click', () => goToStep(1));
            }
            if (btnBackStep) {
                btnBackStep.addEventListener('click', () => goToStep(1));
            }

            async function loadSiswaForAbsen(kelas, tanggal) {
                inputFinalKelas.value = kelas;
                targetClassLabel.textContent = `Absensi: ${kelas} (${tanggal})`;
                goToStep(2);

                loading.style.display = 'block';
                table.style.display = 'none';
                tbody.innerHTML = '';
                checkNihil.checked = false;

                try {
                    const response = await fetch(`{{ route('guru.absen.siswa') }}?kelas=${encodeURIComponent(kelas)}&tanggal=${encodeURIComponent(tanggal)}`);
                    const data = await response.json();

                    if (data.siswa && data.siswa.length > 0) {
                        let html = '';
                        let allHadir = true;

                        data.siswa.forEach((s, idx) => {
                            const nis = s.nis;
                            const status = s.status || 'H';
                            if (status !== 'H') allHadir = false;

                            html += `
                                <tr>
                                    <td style="text-align: center;">${s.absen || (idx + 1)}</td>
                                    <td class="dash-table__name">${s.nama}</td>
                                    <td style="text-align: center;">
                                        <input class="dash-check dash-check--ok check-status" type="radio" name="kehadiran[${nis}]" value="H" ${status === 'H' ? 'checked' : ''} aria-label="Hadir">
                                    </td>
                                    <td style="text-align: center;">
                                        <input class="dash-check dash-check--bad check-status" type="radio" name="kehadiran[${nis}]" value="S" ${status === 'S' ? 'checked' : ''} aria-label="Sakit">
                                    </td>
                                    <td style="text-align: center;">
                                        <input class="dash-check dash-check--bad check-status" type="radio" name="kehadiran[${nis}]" value="I" ${status === 'I' ? 'checked' : ''} aria-label="Izin">
                                    </td>
                                    <td style="text-align: center;">
                                        <input class="dash-check dash-check--bad check-status" type="radio" name="kehadiran[${nis}]" value="A" ${status === 'A' ? 'checked' : ''} aria-label="Alpa">
                                    </td>
                                </tr>
                            `;
                        });

                        tbody.innerHTML = html;
                        checkNihil.checked = allHadir;
                    } else {
                        tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 2rem; color: var(--dash-muted);">Tidak ada siswa terdaftar di kelas ${kelas}</td></tr>`;
                    }
                } catch (err) {
                    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; padding: 2rem; color: #ef4444;">Gagal memuat data siswa: ${err.message}</td></tr>`;
                } finally {
                    loading.style.display = 'none';
                    table.style.display = 'table';
                }
            }

            // Klik pilihan kelas di Step 1
            document.querySelectorAll('.btn-select-kelas-direct').forEach(btn => {
                btn.addEventListener('click', () => {
                    const kelas = btn.getAttribute('data-kelas');
                    const tanggal = inputTanggal.value || new Date().toISOString().split('T')[0];
                    loadSiswaForAbsen(kelas, tanggal);
                });
            });

            // Klik tombol Edit di list log
            document.querySelectorAll('.btn-edit-absen').forEach(btn => {
                btn.addEventListener('click', () => {
                    const kelas = btn.getAttribute('data-kelas');
                    const tanggal = btn.getAttribute('data-tanggal');
                    inputTanggal.value = tanggal;
                    loadSiswaForAbsen(kelas, tanggal);
                    modalAbsen.classList.add('is-open');
                });
            });

            // Klik tombol "Mulai Absensi" di header
            const btnOpenModal = document.getElementById('btn-open-absen-modal');
            if (btnOpenModal) {
                btnOpenModal.addEventListener('click', () => {
                    goToStep(1);
                });
            }

            // Nihil toggle
            if (checkNihil) {
                checkNihil.addEventListener('change', () => {
                    if (checkNihil.checked) {
                        tbody.querySelectorAll('input.check-status[value="H"]').forEach(radio => radio.checked = true);
                    }
                });

                tbody.addEventListener('change', (e) => {
                    if (e.target.classList.contains('check-status')) {
                        const allH = Array.from(tbody.querySelectorAll('input.check-status[value="H"]')).every(r => r.checked);
                        checkNihil.checked = allH;
                    }
                });
            }
        });
    </script>
</body>
</html>
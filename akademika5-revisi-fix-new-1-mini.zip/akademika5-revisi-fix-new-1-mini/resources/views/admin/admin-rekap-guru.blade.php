<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Absensi Guru - Dashboard Admin - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .filter-header-card {
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: 16px;
            padding: 1.25rem 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .stats-summary-row {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-top: 0.5rem;
            flex-wrap: wrap;
        }
        .stat-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.25rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.8rem;
            font-weight: 700;
        }
        .stat-pill--hadir { background: #dcfce7; color: #15803d; border: 1px solid rgba(21, 128, 61, 0.2); }
        .stat-pill--sakit { background: #ede9fe; color: #6d28d9; border: 1px solid rgba(109, 40, 217, 0.2); }
        .stat-pill--izin  { background: #fef9c3; color: #a16207; border: 1px solid rgba(161, 98, 7, 0.2); }
        .stat-pill--alpa  { background: #fee2e2; color: #b91c1c; border: 1px solid rgba(185, 28, 28, 0.2); }

        .table-container {
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--dash-shadow);
        }
        .detail-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }
        .detail-table th {
            background: var(--dash-hover);
            padding: 0.85rem 1rem;
            text-align: left;
            font-weight: 700;
            color: var(--dash-ink);
            border-bottom: 1px solid var(--dash-edge);
        }
        .detail-table td {
            padding: 0.8rem 1rem;
            border-bottom: 1px solid var(--dash-edge);
            color: var(--dash-ink);
        }
        .detail-table tr:last-child td {
            border-bottom: none;
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar Admin -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu admin">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman admin">
                <a class="dash-menu__item" href="{{ route('admin.status') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.piket') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/authority-icon.png') }}" alt="" width="24" height="24">
                    Pilih Guru Piket
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.siswa') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.guru') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.jurnal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Rekap Jurnal
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">Administrator</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">{{ session('email_akun') ?? 'admin@smkti.akademik.id' }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-admin-rekap-g').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-admin-rekap-g" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Rekapitulasi Absensi Guru</h1>
                    </div>
                </header>

                <!-- Filter Controls: Pilih Tanggal -->
                <div class="filter-header-card">
                    <div>
                        <div style="font-family: var(--font-heading); font-size: 1.25rem; text-transform: uppercase;">
                            Presensi Guru &bull; {{ $tanggalFormatted }}
                        </div>
                        <div class="stats-summary-row">
                            <span class="stat-pill stat-pill--hadir">Hadir: {{ $totalHadir }}</span>
                            <span class="stat-pill stat-pill--sakit">Sakit: {{ $totalSakit }}</span>
                            <span class="stat-pill stat-pill--izin">Izin: {{ $totalIzin }}</span>
                            <span class="stat-pill stat-pill--alpa">Tidak Hadir: {{ $totalAlpa }}</span>
                            <span style="font-size: 0.8rem; color: var(--dash-muted); margin-left: 0.25rem;">
                                Total Guru: <strong>{{ $daftarGuruAbsen->count() }}</strong>
                            </span>
                        </div>
                    </div>

                    <form method="GET" action="{{ route('admin.rekap.guru') }}" style="display: flex; align-items: center; gap: 0.75rem;">
                        <div>
                            <label for="pilih-tanggal-guru" style="display: block; font-size: 0.75rem; font-weight: 700; color: var(--dash-muted); margin-bottom: 0.2rem;">PILIH TANGGAL</label>
                            <input type="date" id="pilih-tanggal-guru" name="tanggal" value="{{ $tanggalPilihan }}" class="dash-input" onchange="this.form.submit()" style="padding: 0.35rem 0.75rem; font-size: 0.85rem;">
                        </div>

                        <a href="{{ route('admin.rekap.guru') }}" class="dash-btn dash-btn--ghost" style="padding: 0.45rem 0.85rem; font-size: 0.8rem; margin-top: 1.1rem; text-decoration: none;">Hari Ini</a>
                    </form>
                </div>


                <!-- Unduh rekap kehadiran guru per semester (Excel) -->
                <div class="export-card">
                    <div>
                        <div style="font-family: var(--font-heading); font-size: 1.05rem; text-transform: uppercase;">Rekap Kehadiran Guru (Excel)</div>
                        <div style="font-size: 0.82rem; color: var(--dash-muted); margin-top: 0.2rem;">Rekap 1 semester (6 bulan), dihitung per bulan untuk setiap guru.</div>
                    </div>
                    <form method="GET" action="{{ route('admin.rekap.guru.export') }}">
                        <div>
                            <label for="export-tahun">TAHUN AJARAN</label>
                            <select id="export-tahun" name="tahun" class="dash-input" style="padding: 0.4rem 0.75rem; font-size: 0.85rem;">
                                @foreach($opsiTahun as $th)
                                    <option value="{{ $th }}" {{ $th == $tahunDefault ? 'selected' : '' }}>{{ $th }}/{{ $th + 1 }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label for="export-semester">SEMESTER</label>
                            <select id="export-semester" name="semester" class="dash-input" style="padding: 0.4rem 0.75rem; font-size: 0.85rem;">
                                <option value="1" {{ $semesterDefault == 1 ? 'selected' : '' }}>Ganjil (Juli - Desember)</option>
                                <option value="2" {{ $semesterDefault == 2 ? 'selected' : '' }}>Genap (Januari - Juni)</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-excel" title="Unduh rekap kehadiran guru satu semester">
                            <svg viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                            <span>Unduh Excel Semester</span>
                        </button>
                    </form>
                </div>

                <!-- Detailed Teachers Attendance Table -->
                <div class="table-container">
                    <table class="detail-table">
                        <thead>
                            <tr>
                                <th style="width: 60px; text-align: center;">No.</th>
                                <th>Nama Lengkap Guru</th>
                                <th>Mata Pelajaran Utama</th>
                                <th style="width: 150px; text-align: center;">Status Presensi</th>
                                <th>Catatan / Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($daftarGuruAbsen as $g)
                                <tr>
                                    <td style="text-align: center;">{{ $g->no }}</td>
                                    <td><strong>{{ $g->nama }}</strong></td>
                                    <td>{{ $g->mapel }}</td>
                                    <td style="text-align: center;">
                                        @php
                                            $pillClass = match(strtolower($g->status)) {
                                                'hadir' => 'stat-pill--hadir',
                                                'sakit' => 'stat-pill--sakit',
                                                'izin'  => 'stat-pill--izin',
                                                default => 'stat-pill--alpa',
                                            };
                                        @endphp
                                        <span class="stat-pill {{ $pillClass }}">{{ $g->status }}</span>
                                    </td>
                                    <td>{{ $g->catatan }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="5" style="text-align: center; padding: 2.5rem; color: var(--dash-muted);">
                                        Tidak ada data guru.
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Jurnal Mengajar - Dashboard Admin - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .filter-header-card {
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: 16px;
            padding: 1.25rem 1.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .table-container {
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: 16px;
            overflow: hidden;
            box-shadow: var(--dash-shadow);
        }
        .detail-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.88rem;
        }
        .detail-table th {
            background: var(--dash-hover);
            padding: 0.85rem 1rem;
            text-align: left;
            font-weight: 700;
            color: var(--dash-ink);
            border-bottom: 1px solid var(--dash-edge);
            white-space: nowrap;
        }
        .detail-table td {
            padding: 0.8rem 1rem;
            border-bottom: 1px solid var(--dash-edge);
            color: var(--dash-ink);
        }
        .detail-table tr:last-child td {
            border-bottom: none;
        }
        .jurnal-tag {
            display: inline-flex;
            align-items: center;
            padding: 0.15rem 0.55rem;
            border-radius: var(--radius-pill);
            font-size: 0.72rem;
            font-weight: 700;
            background: #dbeafe;
            color: #1d4ed8;
            white-space: nowrap;
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar Admin -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu admin">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman admin">
                <a class="dash-menu__item" href="{{ route('admin.status') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.piket') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/authority-icon.png') }}" alt="" width="24" height="24">
                    Pilih Guru Piket
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.siswa') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.guru') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.jurnal') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Rekap Jurnal
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">Administrator</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">{{ session('email_akun') ?? 'admin@smkti.akademik.id' }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-admin-rekap-j').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-admin-rekap-j" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Rekap Jurnal Mengajar Guru</h1>
                    </div>
                </header>

                <!-- Filter Controls: Cari, Kelas, dan Tanggal -->
                <div class="filter-header-card">
                    <div>
                        <div style="font-family: var(--font-heading); font-size: 1.25rem; text-transform: uppercase;">
                            Log Jurnal Seluruh Guru
                        </div>
                        <div style="font-size: 0.85rem; color: var(--dash-muted); margin-top: 0.25rem;">
                            Menampilkan catatan riwayat mengajar dan sub-kompetensi materi dari database.
                        </div>
                    </div>

                    <form method="GET" action="{{ route('admin.rekap.jurnal') }}" style="display: flex; align-items: center; gap: 0.75rem; flex-wrap: wrap;">
                        <div>
                            <label for="search-input" style="display: block; font-size: 0.75rem; font-weight: 700; color: var(--dash-muted); margin-bottom: 0.2rem;">CARI GURU / MAPEL</label>
                            <input type="search" id="search-input" name="q" value="{{ $search }}" placeholder="Ketik kata kunci..." class="dash-input" style="padding: 0.4rem 0.75rem; font-size: 0.85rem; min-width: 170px;">
                        </div>

                        <div>
                            <label for="pilih-kelas" style="display: block; font-size: 0.75rem; font-weight: 700; color: var(--dash-muted); margin-bottom: 0.2rem;">KELAS</label>
                            <select id="pilih-kelas" name="kelas" class="dash-input" onchange="this.form.submit()" style="padding: 0.4rem 0.75rem; font-size: 0.85rem;">
                                <option value="">Semua Kelas</option>
                                @foreach($allKelas as $k)
                                    <option value="{{ $k }}" {{ $k === $kelasPilihan ? 'selected' : '' }}>{{ $k }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div>
                            <label for="pilih-tanggal" style="display: block; font-size: 0.75rem; font-weight: 700; color: var(--dash-muted); margin-bottom: 0.2rem;">TANGGAL</label>
                            <input type="date" id="pilih-tanggal" name="tanggal" value="{{ $tanggalPilihan }}" class="dash-input" onchange="this.form.submit()" style="padding: 0.35rem 0.75rem; font-size: 0.85rem;">
                        </div>

                        <a href="{{ route('admin.rekap.jurnal') }}" class="dash-btn dash-btn--ghost" style="padding: 0.45rem 0.85rem; font-size: 0.8rem; margin-top: 1.1rem; text-decoration: none;">Reset</a>
                    </form>
                </div>


                <!-- Unduh rekap jurnal per kelas / semua kelas (Excel) -->
                <div class="export-card">
                    <div>
                        <div style="font-family: var(--font-heading); font-size: 1.05rem; text-transform: uppercase;">Rekap Jurnal (Excel)</div>
                        <div style="font-size: 0.82rem; color: var(--dash-muted); margin-top: 0.2rem;">Pilih satu kelas, atau &ldquo;Semua Kelas&rdquo; untuk merekap seluruh jurnal.</div>
                    </div>
                    <form method="GET" action="{{ route('admin.rekap.jurnal.export') }}">
                        <div>
                            <label for="export-kelas">KELAS</label>
                            <select id="export-kelas" name="kelas" class="dash-input" style="padding: 0.4rem 0.75rem; font-size: 0.85rem;">
                                <option value="all">Semua Kelas</option>
                                @foreach($allKelas as $k)
                                    <option value="{{ $k }}" {{ $k === $kelasPilihan ? 'selected' : '' }}>{{ $k }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div>
                            <label for="export-tahun-jurnal">TAHUN AJARAN</label>
                            <select id="export-tahun-jurnal" name="tahun" class="dash-input" style="padding: 0.4rem 0.75rem; font-size: 0.85rem;">
                                @foreach($opsiTahun as $th)
                                    <option value="{{ $th }}" {{ $th == $tahunDefault ? 'selected' : '' }}>{{ $th }}/{{ $th + 1 }}</option>
                                @endforeach
                                <option value="semua">Semua Tahun Ajaran</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-excel" title="Unduh rekap jurnal">
                            <svg viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                            <span>Unduh Excel</span>
                        </button>
                    </form>
                </div>

                <!-- Detailed Journals Table -->
                <div class="table-container">
                    <table class="detail-table">
                        <thead>
                            <tr>
                                <th style="width: 130px;">Tanggal</th>
                                <th style="width: 100px; text-align: center;">Kelas</th>
                                <th style="width: 90px; text-align: center;">Jam ke-</th>
                                <th>Nama Guru &amp; Mapel</th>
                                <th style="width: 80px; text-align: center;">Pertemuan</th>
                                <th>Materi / Sub-Kompetensi</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($jurnals as $j)
                                <tr>
                                    <td>{{ $j->tanggal_formatted }}</td>
                                    <td style="text-align: center;"><span class="jurnal-tag">{{ $j->kelas }}</span></td>
                                    <td style="text-align: center;"><strong>{{ $j->jam_sekolah }}</strong></td>
                                    <td>
                                        <strong>{{ $j->nama_guru }}</strong>
                                        <div style="font-size: 0.78rem; color: var(--dash-muted);">{{ $j->nama_mapel }}</div>
                                    </td>
                                    <td style="text-align: center;">{{ $j->pertemuan }}</td>
                                    <td>{{ $j->sub_kompetensi }}</td>
                                    <td style="color: var(--dash-muted); font-size: 0.82rem;">{{ $j->keterangan ?: '-' }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" style="text-align: center; padding: 2.5rem; color: var(--dash-muted);">
                                        Belum ada rekapan jurnal mengajar yang sesuai filter.
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                <div style="margin-top: 1rem;">
                    {{ $jurnals->withQueryString()->links() }}
                </div>
            </div>
        </main>
    </div>
</body>
</html>

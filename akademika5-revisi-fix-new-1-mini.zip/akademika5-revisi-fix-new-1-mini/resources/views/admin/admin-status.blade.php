<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Guru - Dashboard Admin - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .date-filter-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: 16px;
            padding: 0.85rem 1.25rem;
            margin-bottom: 1.25rem;
            gap: 1rem;
            flex-wrap: wrap;
        }
        .date-filter-input {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .date-filter-input input[type="date"] {
            border: 1px solid var(--dash-edge);
            background: var(--dash-surface);
            color: var(--dash-ink);
            padding: 0.4rem 0.75rem;
            border-radius: var(--radius-sm);
            font-size: 0.85rem;
            font-family: inherit;
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu admin">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman admin">
                <a class="dash-menu__item" href="{{ route('admin.status') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.piket') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/authority-icon.png') }}" alt="" width="24" height="24">
                    Pilih Guru Piket
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.siswa') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.guru') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.jurnal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Rekap Jurnal
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">Administrator</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">{{ session('email_akun') ?? 'admin@smkti.akademik.id' }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-admin-status').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-admin-status" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Status Guru &amp; Jadwal Mengajar</h1>
                    </div>
                    <a href="{{ route('admin.rekap.guru.export') }}" class="btn-excel" title="Unduh rekap kehadiran guru semester berjalan (6 bulan)">
                        <svg viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                        <span>Rekap Kehadiran Guru</span>
                    </a>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search nama atau mapel..." aria-label="Cari guru" id="search-guru" oninput="filterGuruList()">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </div>
                    </div>
                </header>

                <!-- Date Filter Bar -->
                <div class="date-filter-bar">
                    <div>
                        <div style="font-family: var(--font-heading); font-size: 1.15rem; text-transform: uppercase;">
                            {{ $tanggalFormatted }}
                        </div>
                        <div style="font-size: 0.85rem; color: var(--dash-muted); margin-top: 0.2rem;">
                            Hadir: <strong>{{ $dataGuru->where('is_hadir', true)->count() }}</strong> &bull;
                            Tidak Hadir / Izin / Sakit: <strong>{{ $dataGuru->where('is_hadir', false)->count() }}</strong>
                        </div>
                    </div>
                    <form method="GET" action="{{ route('admin.status') }}" style="display: flex; align-items: center; gap: 0.5rem;">
                        <div class="date-filter-input">
                            <label for="filter-tanggal" style="font-size: 0.8rem; font-weight: 600; color: var(--dash-muted);">Tanggal:</label>
                            <input type="date" id="filter-tanggal" name="tanggal" value="{{ $tanggalPilihan }}" onchange="this.form.submit()">
                        </div>
                        <a href="{{ route('admin.status') }}" class="dash-btn dash-btn--ghost" style="padding: 0.4rem 0.8rem; font-size: 0.8rem; text-decoration: none;">Hari Ini</a>
                    </form>
                </div>

                <!-- Teacher Status Cards from Database (Mirip Siswa Status) -->
                <ul class="dash-list" id="guru-status-list">
                    @forelse ($dataGuru as $guru)
                        @php
                            $statusSlug = match(strtolower($guru->status)) {
                                'hadir' => 'hadir',
                                'izin' => 'izin',
                                'sakit' => 'sakit',
                                'tidak hadir', 'alpa' => 'alpa',
                                default => 'belum',
                            };
                            $badgeClass = 'badge-status--' . $statusSlug;
                        @endphp
                        <li class="guru-item-card" data-nama="{{ strtolower($guru->nama . ' ' . $guru->mapel) }}" style="list-style: none;">
                            <div class="dash-jadwal-card dash-jadwal-card--{{ $statusSlug }}">
                                <div class="dash-jadwal-card__info">
                                    <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                        <span class="dash-jadwal-card__subject">{{ $guru->nama }}</span>
                                        <span class="badge-status-pill {{ $badgeClass }}">
                                            {{ $guru->status }}
                                        </span>
                                    </div>
                                    <span class="dash-jadwal-card__teacher" style="margin-top: 0.2rem;">
                                        Mata Pelajaran: <strong>{{ $guru->mapel }}</strong>
                                    </span>
                                    <div style="font-size: 0.8rem; color: var(--dash-muted); margin-top: 0.25rem;">
                                        Status Mengajar: <span style="font-weight: 600; color: var(--dash-ink);">{{ $guru->sedang_ngajar }}</span>
                                    </div>
                                </div>
                                <span class="dash-jadwal-card__time">
                                    {{ $guru->tanggal_formatted }}
                                </span>
                            </div>
                        </li>
                    @empty
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Belum ada data guru pada tanggal ini.</span>
                            </div>
                        </li>
                    @endforelse
                </ul>
            </div>
        </main>
    </div>

    <script>
        function filterGuruList() {
            const query = (document.getElementById('search-guru')?.value || '').toLowerCase().trim();
            document.querySelectorAll('#guru-status-list .guru-item-card').forEach(item => {
                const text = item.getAttribute('data-nama') || '';
                item.style.display = text.includes(query) ? '' : 'none';
            });
        }
    </script>
</body>
</html>

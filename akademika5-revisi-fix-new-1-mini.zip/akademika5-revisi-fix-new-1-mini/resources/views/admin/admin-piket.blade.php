<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Guru Piket - Dashboard Admin - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .piket-hero {
            background: radial-gradient(circle at 92% 25%, rgba(59, 130, 246, 0.15) 0%, rgba(255, 255, 255, 0) 60%), var(--dash-surface);
            border: 1.5px solid #3b82f6;
            border-radius: 20px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1.5rem;
            flex-wrap: wrap;
            box-shadow: 0 10px 25px -5px rgba(59, 130, 246, 0.15);
        }
        .piket-hero__info {
            flex: 1;
            min-width: 250px;
        }
        .piket-hero__badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.2rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 700;
            background: #dbeafe;
            color: #1d4ed8;
            margin-bottom: 0.5rem;
        }
        .piket-hero__badge--pengganti {
            background: #fef3c7;
            color: #b45309;
        }
        .piket-hero__name {
            font-family: var(--font-heading);
            font-size: clamp(1.4rem, 3.5vw, 2rem);
            font-weight: 400;
            text-transform: uppercase;
            color: var(--dash-ink);
            margin: 0 0 0.35rem 0;
            line-height: 1.15;
        }
        .piket-hero__time {
            font-size: 0.875rem;
            color: var(--dash-muted);
            margin-bottom: 0.35rem;
        }
        .piket-hero__desc {
            font-size: 0.85rem;
            color: var(--dash-ink);
            font-weight: 500;
        }

        .alert-toast {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid #86efac;
            padding: 0.75rem 1.25rem;
            border-radius: var(--radius-md);
            margin-bottom: 1.25rem;
            font-size: 0.875rem;
            font-weight: 600;
        }
        .alert-toast--danger {
            background: #fee2e2;
            color: #b91c1c;
            border-color: #fca5a5;
        }

        .btn-cancel-piket {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.4rem 0.85rem;
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid rgba(185, 28, 28, 0.2);
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-cancel-piket:hover {
            background: #fca5a5;
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar Admin -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu admin">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman admin">
                <a class="dash-menu__item" href="{{ route('admin.status') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.piket') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/authority-icon.png') }}" alt="" width="24" height="24">
                    Pilih Guru Piket
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.siswa') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.guru') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Guru
                </a>
                <a class="dash-menu__item" href="{{ route('admin.rekap.jurnal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Rekap Jurnal
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">Administrator</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">{{ session('email_akun') ?? 'admin@smkti.akademik.id' }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-admin-piket').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-admin-piket" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @if(session('success'))
                    <div class="alert-toast">
                        {{ session('success') }}
                    </div>
                @endif
                @if(session('error'))
                    <div class="alert-toast alert-toast--danger">
                        {{ session('error') }}
                    </div>
                @endif

                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Jadwal &amp; Penugasan Guru Piket</h1>
                    </div>
                    
                </header>

                <!-- SECTION 1: Guru Piket Bertugas Saat Ini (Real-Time Database) -->
                <section class="dash-section" aria-labelledby="piket-aktif">
                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: 0.75rem;">
                        <h2 class="dash-subtitle" id="piket-aktif" style="margin: 0;">GURU PIKET BERTUGAS SAAT INI</h2>
                        <span style="font-size: 0.85rem; color: #2563eb; font-weight: 600;">{{ $tanggalFormatted }}</span>
                    </div>

                    @if ($piketAktif)
                        <div class="piket-hero">
                            <div class="piket-hero__info">
                                <span class="piket-hero__badge {{ $piketAktif->is_pengganti ? 'piket-hero__badge--pengganti' : '' }}">
                                    ● {{ $piketAktif->status_label }}
                                </span>
                                <h3 class="piket-hero__name">{{ $piketAktif->nama }}</h3>
                                <div class="piket-hero__time">Waktu Tugas: <strong>{{ $piketAktif->waktu_tugas }}</strong> &bull; Mapel: {{ $piketAktif->mapel }}</div>
                                <div class="piket-hero__desc">{{ $piketAktif->keterangan }}</div>
                            </div>
                            @if ($piketAktif->is_pengganti)
                                <div>
                                    <form action="{{ route('admin.piket.pengganti.batal', $piketAktif->pengganti_id) }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin membatalkan akses guru piket pengganti ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn-cancel-piket" title="Batalkan Akses Pengganti">
                                            ✕ Batalkan Akses Pengganti
                                        </button>
                                    </form>
                                </div>
                            @endif
                        </div>
                    @else
                        <div class="dash-card" style="padding: 1.5rem; text-align: center; color: var(--dash-muted);">
                            Tidak ada guru piket terjadwal untuk hari ini.
                        </div>
                    @endif
                </section>

                <!-- SECTION 2: Daftar Guru Piket Pengganti Hari Ini (Jika ada) -->
                @if ($penggantiHariIni->isNotEmpty())
                    <section class="dash-section" aria-labelledby="piket-pengganti-list" style="margin-top: 1.5rem;">
                        <h2 class="dash-subtitle" id="piket-pengganti-list">Guru Piket Pengganti Hari Ini</h2>
                        <ul class="dash-list">
                            @foreach ($penggantiHariIni as $pg)
                                <li class="dash-item">
                                    <div class="dash-card" style="border-left: 4px solid #f59e0b;">
                                        <div>
                                            <span class="dash-card__name">{{ $pg->nama_pengganti }}</span>
                                            <span style="font-size: 0.75rem; padding: 0.15rem 0.5rem; background: #fef3c7; color: #b45309; border-radius: var(--radius-pill); font-weight: 700; margin-left: 0.5rem;">
                                                Pengganti Shift: {{ ucfirst($pg->shift) }}
                                            </span>
                                            <div style="font-size: 0.8rem; color: var(--dash-muted); margin-top: 0.25rem;">
                                                {{ $pg->keterangan }} &bull; Menggantikan: <strong>{{ $pg->nama_asli ?? 'Guru Piket' }}</strong>
                                            </div>
                                        </div>
                                    </div>
                                    <form action="{{ route('admin.piket.pengganti.batal', $pg->id) }}" method="POST" onsubmit="return confirm('Batalkan akses untuk guru ini?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn-cancel-piket" title="Batalkan Akses">
                                            Batalkan
                                        </button>
                                    </form>
                                </li>
                            @endforeach
                        </ul>
                    </section>
                @endif

                <!-- SECTION 3: Seluruh Jadwal Tetap Guru Piket dari Database -->
                <section class="dash-section" aria-labelledby="piket-log" style="margin-top: 1.5rem;">
                    <h2 class="dash-subtitle" id="piket-log">Seluruh Jadwal guru piket</h2>
                    <ul class="dash-list">
                        @forelse ($semuaJadwalPiket as $jp)
                            <li class="dash-item">
                                <div class="dash-card" style="{{ $jp->hari === $hariIni ? 'border-left: 4px solid #2563eb;' : '' }}">
                                    <div>
                                        <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                            <span class="dash-card__name">{{ $jp->nama_guru }}</span>
                                            <span style="font-size: 0.72rem; padding: 0.15rem 0.55rem; background: var(--dash-hover); border-radius: var(--radius-pill); font-weight: 700; text-transform: uppercase; color: #2563eb;">
                                                {{ $jp->hari }}
                                            </span>
                                            @if ($jp->hari === $hariIni)
                                                <span style="font-size: 0.72rem; padding: 0.15rem 0.55rem; background: #dcfce7; color: #15803d; border-radius: var(--radius-pill); font-weight: 700;">
                                                    Hari Ini
                                                </span>
                                            @endif
                                        </div>
                                        <div style="font-size: 0.8rem; color: var(--dash-muted); margin-top: 0.25rem;">
                                            Mapel: {{ $jp->mapel_guru ?: '-' }} &bull; Sesi: <strong>{{ $jp->waktu }}</strong>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        @empty
                            <li class="dash-item">
                                <div class="dash-card">
                                    <span class="dash-card__name">Belum ada data jadwal guru piket di database.</span>
                                </div>
                            </li>
                        @endforelse
                    </ul>
                </section>
            </div>
        </main>
    </div>

    <!-- Modal Form: Tugaskan Guru Piket Pengganti -->
    <div class="dash-modal" id="modal-piket" role="dialog" aria-modal="true" aria-labelledby="modal-piket-title">
        <div class="dash-modal__box" tabindex="-1">
            <button type="button" class="dash-modal__close" data-modal-close aria-label="Tutup">&times;</button>
            <div class="dash-modal__head dash-modal__head--center">
                <h2 class="dash-modal__title" id="modal-piket-title">Pilih Guru Piket Pengganti</h2>
                <p style="font-size: 0.825rem; color: var(--dash-muted); margin: 0.25rem 0 0 0;">
                    Berikan hak akses sementara ke halaman Guru Piket jika guru piket utama berhalangan hadir.
                </p>
            </div>
            <div class="dash-modal__body dash-modal__body--last">
                <form class="dash-stack" action="{{ route('admin.piket.pengganti') }}" method="post">
                    @csrf
                    <!-- Tanggal Tugas -->
                    <div class="dash-field">
                        <label class="dash-label dash-label--left" for="piket-tanggal">Tanggal Berlaku</label>
                        <input class="dash-input" type="date" id="piket-tanggal" name="tanggal" value="{{ date('Y-m-d') }}" required>
                    </div>

                    <!-- Pilih Guru -->
                    <div class="dash-field">
                        <label class="dash-label dash-label--left" for="piket-guru">Pilih Guru Pengganti</label>
                        <div class="dash-select">
                            <select class="dash-input" id="piket-guru" name="kode_guru" required>
                                <option value="" selected disabled>Pilih nama guru...</option>
                                @foreach($daftarSemuaGuru as $g)
                                    <option value="{{ $g->kode_guru }}">{{ $g->nama }} ({{ $g->mapel ?: 'Umum' }})</option>
                                @endforeach
                            </select>
                            <img class="dash-icon" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </div>
                    </div>

                    <!-- Shift -->
                    <div class="dash-field">
                        <label class="dash-label dash-label--left" for="piket-shift">Shift Tugas</label>
                        <div class="dash-select">
                            <select class="dash-input" id="piket-shift" name="shift" required>
                                <option value="semua">Sepanjang Hari (Pagi &amp; Siang)</option>
                                <option value="pagi">Pagi (07.00 - 12.30)</option>
                                <option value="siang">Siang (12.30 - 17.15)</option>
                            </select>
                            <img class="dash-icon" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </div>
                    </div>

                    <!-- Keterangan / Alasan -->
                    <div class="dash-field">
                        <label class="dash-label dash-label--left" for="piket-keterangan">Keterangan / Alasan</label>
                        <input class="dash-input" type="text" id="piket-keterangan" name="keterangan" placeholder="Contoh: Menggantikan guru piket yang izin sakit" value="Menggantikan guru piket utama yang berhalangan">
                    </div>

                    <button type="submit" class="dash-btn" style="width: 100%; margin-top: 0.5rem;">Berikan Akses Piket</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>

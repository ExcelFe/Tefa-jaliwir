<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('partials.head-meta', ['title' => 'Halaman Tidak Ditemukan (404) - SMK TI Bali Global Badung', 'description' => 'Halaman yang Anda cari tidak ditemukan. Kembali ke beranda SMK TI Bali Global Badung.', 'robots' => 'noindex, nofollow'])

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script defer src="{{ asset('js/main.js') }}"></script>
</head>
<body>
    @include('partials.public-navbar', ['active' => null])

    <main>
        <!-- 404: hero gradient yang sama dengan Profil/Program. Tombol Kembali memakai riwayat browser (js/main.js) -->
        <section class="error-page">
            <span class="hero-pill hero-pill--blue" aria-hidden="true"></span>
            <span class="hero-pill hero-pill--gold" aria-hidden="true"></span>

            <div class="container error-page__inner">
                <p class="error-page__code" aria-hidden="true">404</p>
                <h1>Halaman <em>tidak ditemukan</em></h1>
                <p class="error-page__text">Maaf, alamat yang Anda buka tidak ada atau sudah dipindahkan. Periksa kembali alamatnya, atau pilih salah satu tautan di bawah ini.</p>
                <div class="hero-cta">
                    <a href="{{ route('welcome') }}" class="btn-hero btn-hero--primary">Ke Beranda</a>
                    <a href="{{ route('welcome') }}" class="btn-hero btn-hero--glass" data-history-back>Halaman Sebelumnya</a>
                </div>
                <nav class="error-page__links" aria-label="Tautan cepat">
                    <a href="{{ route('profil') }}">Profil Manajemen</a>
                    <a href="{{ route('program') }}">Program Sekolah</a>
                    <a href="{{ route('login') }}">Login</a>
                </nav>
            </div>
        </section>
    </main>

    @include('partials.site-footer')
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('partials.head-meta', ['title' => 'Syarat & Ketentuan - SMK TI Bali Global Badung', 'description' => 'Syarat dan ketentuan penggunaan portal akademik SMK TI Bali Global Badung bagi admin, guru, dan siswa.'])

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script defer src="{{ asset('js/main.js') }}"></script>
</head>
<body>
    @include('partials.public-navbar', ['active' => null])

    <main>
        <section class="page-hero">
            <div class="container">
                <h1>Syarat &amp; <em>Ketentuan</em></h1>
            </div>
        </section>

        <div class="container legal-wrap">
            <article class="card-soft legal">
                <p class="legal__meta">Terakhir diperbarui: {{ config('site.legal_update') }}</p>
                <p>Dengan masuk dan menggunakan portal akademik {{ config('site.nama') }}, Anda menyetujui syarat dan ketentuan berikut. Jika tidak setuju, mohon tidak menggunakan portal ini.</p>

                <h2>1. Pengguna dan akun</h2>
                <ul>
                    <li>Akun dibuat dan dikelola oleh Sekolah untuk admin, guru, dan siswa. Pendaftaran mandiri tidak tersedia.</li>
                    <li>Anda bertanggung jawab menjaga kerahasiaan email dan kata sandi. Segala aktivitas melalui akun Anda dianggap dilakukan oleh Anda.</li>
                    <li>Laporkan segera ke Sekolah bila akun Anda dicurigai dipakai orang lain.</li>
                </ul>

                <h2>2. Penggunaan yang diperbolehkan</h2>
                <ul>
                    <li>Gunakan portal hanya untuk keperluan akademik dan administrasi sekolah.</li>
                    <li>Isi data (absensi, jurnal, jadwal) dengan benar dan jujur.</li>
                    <li>Anda hanya boleh mengakses fitur dan data sesuai peran akun Anda.</li>
                </ul>

                <h2>3. Larangan</h2>
                <ul>
                    <li>Memakai akun orang lain atau membagikan akun Anda.</li>
                    <li>Memalsukan data kehadiran atau jurnal mengajar.</li>
                    <li>Mencoba menembus keamanan, mengganggu layanan, atau mengambil data secara tidak sah.</li>
                </ul>

                <h2>4. Hak kekayaan intelektual</h2>
                <p>Nama, logo, tampilan, dan konten portal adalah milik Sekolah atau pemegang haknya. Dilarang menyalin atau menggunakannya tanpa izin tertulis.</p>

                <h2>5. Ketersediaan layanan</h2>
                <p>Kami berupaya menjaga portal tetap tersedia, namun layanan dapat terhenti sementara untuk pemeliharaan atau karena gangguan di luar kendali kami.</p>

                <h2>6. Pembatasan tanggung jawab</h2>
                <p>Portal disediakan sebagaimana adanya. Sekolah tidak bertanggung jawab atas kerugian akibat kelalaian pengguna, seperti kata sandi yang bocor atau data yang diisi tidak benar.</p>

                <h2>7. Penangguhan akun</h2>
                <p>Sekolah dapat menangguhkan atau menonaktifkan akun yang melanggar ketentuan ini atau peraturan sekolah.</p>

                <h2>8. Privasi</h2>
                <p>Pengelolaan data pribadi diatur dalam <a class="legal__link" href="{{ route('privacy') }}">Kebijakan Privasi</a>.</p>

                <h2>9. Perubahan ketentuan</h2>
                <p>Ketentuan ini dapat diubah sewaktu-waktu. Pemakaian portal setelah perubahan berarti Anda menyetujui ketentuan terbaru.</p>

                <h2>10. Kontak</h2>
                <p>Pertanyaan tentang ketentuan ini dapat dikirim ke <a class="legal__link" href="mailto:{{ config('site.email') }}">{{ config('site.email') }}</a> atau telepon <a class="legal__link" href="tel:{{ config('site.telepon_tel') }}">{{ config('site.telepon') }}</a>.</p>
            </article>
        </div>
    </main>

    @include('partials.site-footer')
</body>
</html>

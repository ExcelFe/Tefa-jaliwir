<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @include('partials.head-meta', ['title' => 'Kebijakan Privasi - SMK TI Bali Global Badung', 'description' => 'Kebijakan privasi portal akademik SMK TI Bali Global Badung: data yang dikumpulkan, tujuan penggunaan, penyimpanan, dan hak pengguna.'])

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script defer src="{{ asset('js/main.js') }}"></script>
</head>
<body>
    @include('partials.public-navbar', ['active' => null])

    <main>
        <section class="page-hero">
            <div class="container">
                <h1>Kebijakan <em>Privasi</em></h1>
            </div>
        </section>

        <div class="container legal-wrap">
            <article class="card-soft legal">
                <p class="legal__meta">Terakhir diperbarui: {{ config('site.legal_update') }}</p>
                <p>Kebijakan ini menjelaskan bagaimana {{ config('site.nama') }} (&ldquo;Sekolah&rdquo;) mengumpulkan, menggunakan, dan melindungi data pribadi pengguna portal akademik ini, sesuai Undang-Undang Nomor 27 Tahun 2022 tentang Pelindungan Data Pribadi.</p>

                <h2>1. Data yang kami kumpulkan</h2>
                <ul>
                    <li><strong>Data akun:</strong> email dan kata sandi (disimpan dalam bentuk terenkripsi), jenis akun (admin, guru, atau siswa).</li>
                    <li><strong>Data identitas akademik:</strong> nama, kode guru, mata pelajaran, nama dan kelas siswa.</li>
                    <li><strong>Data aktivitas akademik:</strong> jadwal, absensi guru dan siswa, jurnal mengajar, serta data guru piket.</li>
                    <li><strong>Data teknis:</strong> cookie sesi untuk menjaga status login, dan preferensi tampilan (mode terang/gelap) yang disimpan di peramban Anda.</li>
                </ul>

                <h2>2. Tujuan penggunaan</h2>
                <ul>
                    <li>Mengautentikasi pengguna dan menampilkan halaman sesuai peran.</li>
                    <li>Mengelola jadwal, absensi, jurnal mengajar, dan rekap kehadiran.</li>
                    <li>Menjaga keamanan sistem dan mencegah penyalahgunaan akun.</li>
                    <li>Memenuhi kebutuhan pelaporan dan administrasi sekolah.</li>
                </ul>

                <h2>3. Cookie</h2>
                <p>Portal memakai cookie sesi yang diperlukan agar Anda tetap masuk selama menggunakan aplikasi. Cookie ini dihapus saat Anda keluar (logout) atau sesi berakhir. Kami tidak memakai cookie iklan.</p>

                <h2>4. Berbagi data</h2>
                <p>Kami tidak menjual data pribadi. Data hanya dapat dilihat oleh pengguna yang berwenang sesuai perannya (misalnya admin dan guru piket untuk rekap kehadiran guru), atau dibagikan bila diwajibkan oleh peraturan perundang-undangan.</p>

                <h2>5. Penyimpanan dan keamanan</h2>
                <p>Data disimpan pada server Sekolah dan hanya selama dibutuhkan untuk keperluan akademik dan administrasi. Kami menerapkan langkah wajar untuk melindungi data, tetapi tidak ada sistem yang sepenuhnya bebas risiko. Jaga kerahasiaan kata sandi Anda dan selalu keluar dari akun saat memakai perangkat bersama.</p>

                <h2>6. Hak pengguna</h2>
                <p>Anda berhak meminta akses, perbaikan, atau penghapusan data pribadi Anda sepanjang diizinkan peraturan dan kebutuhan administrasi sekolah. Untuk siswa di bawah umur, permintaan dapat diajukan oleh orang tua atau wali.</p>

                <h2>7. Perubahan kebijakan</h2>
                <p>Kebijakan ini dapat diperbarui sewaktu-waktu. Tanggal pembaruan terakhir tercantum di bagian atas halaman ini.</p>

                <h2>8. Hubungi kami</h2>
                <p>Pertanyaan atau permintaan terkait data pribadi dapat disampaikan ke <a class="legal__link" href="mailto:{{ config('site.email') }}">{{ config('site.email') }}</a> atau telepon <a class="legal__link" href="tel:{{ config('site.telepon_tel') }}">{{ config('site.telepon') }}</a>. Alamat: {{ config('site.alamat') }}.</p>
            </article>
        </div>
    </main>

    @include('partials.site-footer')
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Manajemen Sekolah - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/profil-manajemen.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
</head>
<body>
    <!-- NAVBAR: same block on every page (hamburger on tablet/phone, js/main.js) -->
    <header class="navbar">
        <div class="container navbar-inner">
            <a href="{{ route('welcome') }}" class="brand">
                <div class="img-slot logo-slot"><img src="{{ asset('media/logo.webp') }}" alt="Logo SMK TI Bali Global Badung"></div>
                <span>SMK TI<br><span class="brand-sub">Bali Global Badung</span></span>
            </a>
            <button type="button" class="nav-toggle" aria-label="Buka menu" aria-expanded="false" aria-controls="nav-panel">
                <span class="nav-toggle-bar"></span>
            </button>
            <div class="nav-panel" id="nav-panel">
                <div class="nav-panel-inner">
                    <nav class="nav-links" aria-label="Navigasi utama">
                    <a href="{{ route('welcome') }}">Beranda</a>
                    <a href="{{ route('profil') }}" class="is-active" aria-current="page">Profil Manajemen</a>
                    <a href="{{ route('program') }}">Program Sekolah</a>
                    </nav>
                    <a href="{{ route('login') }}" class="btn-login">Login <i class="fa-solid fa-arrow-right-to-bracket" aria-hidden="true"></i></a>
                </div>
            </div>
        </div>
    </header>

    <main>
        <section class="page-hero">
            <div class="container">
                <h1>PROFIL <em>MANAJEMEN</em> SEKOLAH</h1>
            </div>
        </section>
        <div class="container profil-wrap">

            <!-- ===== MANAJEMEN SEKOLAH ===== -->
            <section id="manajemen">
                <h2 class="group-title">Manajemen Sekolah</h2>
                <!-- The first 4 cards always show. Copy/remove <article> blocks as needed -->
                <div class="person-grid">
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/kepalasekolah.jpg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Made Indra Aribawa, SH</h3><p><i class="fa-solid fa-book-open"></i>Pendidikan Pancasila</p><p><i class="fa-solid fa-book-open"></i>Bimbingan Konseling</p><p><i class="fa-solid fa-people-group"></i>Kepala Sekolah</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakakurikulum.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Gede Putu Agustyawan, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Sejarah Indonesia</p><p><i class="fa-solid fa-people-group"></i>Koordinator P5</p><p><i class="fa-solid fa-people-group"></i>Waka Kurikulum</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakasarpras.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Made Dwi Adnyana, SH</h3><p><i class="fa-solid fa-book-open"></i>Pendidikan Pancasila</p><p><i class="fa-solid fa-people-group"></i>Waka Sarana Prasarana</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakakesiswaan.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ida Ayu Cempaka Putri, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Bimbingan Konseling</p><p><i class="fa-solid fa-people-group"></i>Waka Kesiswaan</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakahumas.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ida Ayu Made Ari Widyawati, S.Pd.H</h3><p><i class="fa-solid fa-book-open"></i>Agama Hindu & Budi Pekerti</p><p><i class="fa-solid fa-people-group"></i>Waka Humas</p></div>
                </article>
                </div>
            </section>

            <!-- ===== KEPALA PROGRAM KEAHLIAN ===== -->
            <section id="kaprog">
                <h2 class="group-title">Kepala Program Keahlian</h2>
                <div class="person-grid">
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogpplg.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Putu Ade Pranata, S.Kom</h3><p><i class="fa-solid fa-book-open"></i>KK PPLG</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan KKA</p><p><i class="fa-solid fa-people-group"></i>Kaprog PPLG</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogdkv.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Bagas Alif Rizkianto, S.Kom</h3><p><i class="fa-solid fa-book-open"></i>DPK PPLG & DPK BD</p><p><i class="fa-solid fa-book-open"></i>KK RPL</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan PPLG</p><p><i class="fa-solid fa-people-group"></i>Kaprog DKV</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogtjkt.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gede Bagus Ardiyana Irawan, S.Kom</h3><p><i class="fa-solid fa-book-open"></i>KK TKJ</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan TKJ</p><p><i class="fa-solid fa-people-group"></i>Kaprog TKJ</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogbd.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>A.A Ngurah Putra Agung Amurvabhumi Yoga Cara, S.M</h3><p><i class="fa-solid fa-book-open"></i>KK BD</p><p><i class="fa-solid fa-book-open"></i>KIK</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan BD</p><p><i class="fa-solid fa-people-group"></i>Kaprog BD</p></div>
                </article>
                </div>
            </section>

            <!-- ===== GURU PENGAJAR ===== -->
            <section id="guru">
                <h2 class="group-title">Guru Pengajar</h2>
                <!-- The first 4 cards always show. Copy/remove <article> blocks as needed -->
                <div class="person-grid">
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/kepalasekolah.jpg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Made Indra Aribawa, SH</h3><p><i class="fa-solid fa-book-open"></i>Pendidikan Pancasila</p><p><i class="fa-solid fa-book-open"></i>Bimbingan Konseling</p><p><i class="fa-solid fa-people-group"></i>Kepala Sekolah</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakakurikulum.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Gede Putu Agustyawan, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Sejarah Indonesia</p><p><i class="fa-solid fa-people-group"></i>Koordinator P5</p><p><i class="fa-solid fa-people-group"></i>Waka Kurikulum</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakasarpras.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Made Dwi Adnyana, SH</h3><p><i class="fa-solid fa-book-open"></i>Pendidikan Pancasila</p><p><i class="fa-solid fa-people-group"></i>Waka Sarana Prasarana</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakakesiswaan.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ida Ayu Cempaka Putri, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Bimbingan Konseling</p><p><i class="fa-solid fa-people-group"></i>Waka Kesiswaan</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/manajemen/wakahumas.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ida Ayu Made Ari Widyawati, S.Pd.H</h3><p><i class="fa-solid fa-book-open"></i>Agama Hindu & Budi Pekerti</p><p><i class="fa-solid fa-people-group"></i>Waka Humas</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogpplg.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Putu Ade Pranata, S.Kom</h3><p><i class="fa-solid fa-book-open"></i>KK PPLG</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan KKA</p><p><i class="fa-solid fa-people-group"></i>Kaprog PPLG</p></div>
                </article>
                </div>
                <!-- Extra cards: shown after "Selengkapnya" (js/profil-manajemen.js). Remove this block + its button if not needed -->
                <div id="extra-guru" class="person-grid extra" hidden>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogdkv.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Bagas Alif Rizkianto, S.Kom</h3><p><i class="fa-solid fa-book-open"></i>DPK PPLG & DPK BD</p><p><i class="fa-solid fa-book-open"></i>KK RPL</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan PPLG</p><p><i class="fa-solid fa-people-group"></i>Kaprog DKV</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogtjkt.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gede Bagus Ardiyana Irawan, S.Kom</h3><p><i class="fa-solid fa-book-open"></i>KK TKJ</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan TKJ</p><p><i class="fa-solid fa-people-group"></i>Kaprog TKJ</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogbd.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>A.A Ngurah Putra Agung Amurvabhumi Yoga Cara, S.M</h3><p><i class="fa-solid fa-book-open"></i>KK BD</p><p><i class="fa-solid fa-book-open"></i>KIK</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan BD</p><p><i class="fa-solid fa-people-group"></i>Kaprog BD</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/murniproduktif.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Nyoman Murni, S.Kom, M.Kom</h3><p><i class="fa-solid fa-book-open"></i>Informatika</p><p><i class="fa-solid fa-book-open"></i>DPK TKJ</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/wahyuproduktif.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gusti Putu Wahyu Armandha Kumara, S.Kom</h3><p><i class="fa-solid fa-book-open"></i>KK DKV & KK BD</p><p><i class="fa-solid fa-book-open"></i>DPK DKV</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan DKV</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/thessaproduktif.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Thessa Sahara Umami, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>KK DKV & KK TKj</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan DKV</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/assmarkom.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Dapa Putra</h3><p><i class="fa-solid fa-book-open"></i>DPK BD</p><p><i class="fa-solid fa-book-open"></i>KK BD</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan DKV</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/asslab.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Putu Raditya Wijaya</h3><p><i class="fa-solid fa-book-open"></i>Informatika</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/lalaipas.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Kadek Lala Mistariadi, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>IPAS</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan IPAS</p><p><i class="fa-solid fa-people-group"></i>Bimbingan Konseling</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/ditaipas.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Nyoman Dita Tri Pramida, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>IPAS</p><p><i class="fa-solid fa-book-open"></i>Matematika</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan IPAS</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/meirahindu.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Putu Meira Yanti, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Agama Hindu & Budi Pekerti</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/samsulislam.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Samsul Arifin, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Agama Islam & Budi Pekerti</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/yanpancasila.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Yan Anugrah Wisesa, S.Sos.H., M.Pd</h3><p><i class="fa-solid fa-book-open"></i>Pendidikan Pancasila</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/candrabindo.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Luh Candra Dewi, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Bahasa Indonesia</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/bintabindo.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Binta Lestari Putry, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Bahasa Indonesia</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/sinthyabing.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Kadek Dwi Sintya Dewi, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Bahasa Inggris</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/oktiabing.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Gusti Ayu Oktianingsih, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Bahasa Inggris</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/imeldajapan.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Putu Ayu Imelda Sasiandari, S.S</h3><p><i class="fa-solid fa-book-open"></i>Bahasa Jepang</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/kantianimatik.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Wayan Kantiani, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Matematika</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/darmamatik.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gede Made Darma Wiguna, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Matematika</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/urusankesiswaan.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gede Bayu Mahendra Wijaya, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Matematika</p><p><i class="fa-solid fa-people-group"></i>Bimbingan Konseling</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/ratihpkwu.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gusti Ayu Ary Ratih, S.E, M.M</h3><p><i class="fa-solid fa-book-open"></i>KIK</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/ratnasenibudaya.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Putu Juli Ratna Dewi, S.Sn</h3><p><i class="fa-solid fa-book-open"></i>Seni Budaya</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/muliawanpenjas.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Wayan Muliawan, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Penjasorkes</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/produktif/masrikristen.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Sahat Parulian Verri Tampubolon, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Agama Kristen</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/kaprog/kaprogdkv.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Muchamad Bagaskara</h3><p><i class="fa-solid fa-book-open"></i>KK DKV</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan DKV</p></div>
                </article>
                </div>
                <div class="more-row">
                    <button type="button" class="btn-more" data-toggle="extra-guru" aria-expanded="false"><span>Selengkapnya</span> <i class="fa-solid fa-chevron-down"></i></button>
                </div>
            </section>

            <!-- ===== STAF PEGAWAI ===== -->
            <section id="staff">
                <h2 class="group-title">Staff Pegawai</h2>
                <!-- The first 4 cards always show. Copy/remove <article> blocks as needed -->
                <div class="person-grid">
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/kepalatatausaha.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Putu Agus Purnama Adi Putra, SE., MM</h3><p><i class="fa-solid fa-people-group"></i>Kepala Tata Usaha</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/kmarkom.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gusti Ngurah Artha WIjaya</h3><p><i class="fa-solid fa-people-group"></i>Staff Digital Marketing</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/assmarkom.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Dapa Putra</h3><p><i class="fa-solid fa-book-open"></i>DPK BD</p><p><i class="fa-solid fa-book-open"></i>KK BD</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-book-open"></i>Mapel Pilihan DKV</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/kepegawaian.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ida Ayu Ketut Diah Kartini, S.Bns</h3><p><i class="fa-solid fa-people-group"></i>Staff Kepegawaian</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/asslab.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Putu Raditya Wijaya</h3><p><i class="fa-solid fa-book-open"></i>Informatika</p><p><i class="fa-solid fa-book-open"></i>KKA</p><p><i class="fa-solid fa-people-group"></i>Koordinator KO</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/keuangan1.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Nadia Wanda Oktavia, S.M</h3><p><i class="fa-solid fa-people-group"></i>Staff Keuangan</p></div>
                </article>
                </div>
                <!-- Extra cards: shown after "Selengkapnya" (js/profil-manajemen.js). Remove this block + its button if not needed -->
                <div id="extra-staff" class="person-grid extra" hidden>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/keuangan2.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ayu Astari, S.I.Kom</h3><p><i class="fa-solid fa-people-group"></i>Staff Keuangan</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/urusankesiswaan.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gede Bayu Mahendra Wijaya, S.Pd</h3><p><i class="fa-solid fa-book-open"></i>Matematika</p><p><i class="fa-solid fa-people-group"></i>Bimbingan Konseling</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/cs1.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Gusti Made Sunarta</h3><p><i class="fa-solid fa-people-group"></i>Staff Kebersihan</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/cs2.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Ketut Andayani</h3><p><i class="fa-solid fa-people-group"></i>Staff Kebersihan</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/cs3.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Ni Nyoman Mas Utami</h3><p><i class="fa-solid fa-people-group"></i>Staff Kebersihan</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/kkeamanan.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>I Nyoman Budiasa</h3><p><i class="fa-solid fa-people-group"></i>Staff Keamanan</p></div>
                </article>
                <article class="person">
                    <div class="img-slot ratio-34" data-label="Foto"><img src="{{ asset('media/profil/staff/kkeamanan.jpeg') }}" alt="Foto"></div>
                    <div class="person-info"><h3>Putu Suardita</h3><p><i class="fa-solid fa-people-group"></i>Staff Keamanan</p></div>
                </article>
                </div>
                <div class="more-row">
                    <button type="button" class="btn-more" data-toggle="extra-staff" aria-expanded="false"><span>Selengkapnya</span> <i class="fa-solid fa-chevron-down"></i></button>
                </div>
            </section>
        </div>
    </main>

    <!-- FOOTER: same block on every page -->
    <footer class="footer">
        <div class="container footer-grid">
            <div>
                <div class="brand">
                    <div class="img-slot logo-slot lg"><img src="{{ asset('media/logo.webp') }}" alt="Logo SMK TI Bali Global Badung"></div>
                    <span>SMK TI<br><span class="brand-sub">Bali Global Badung</span></span>
                </div>
                <p class="footer-desc">Sekolah kejuruan berbasis teknologi informasi yang mencetak lulusan kompeten, berkarakter, dan siap bersaing di era digital.</p>
                <!-- Social links: change href and the Font Awesome icon class -->
                <div class="sosmed">
                    <a href="https://www.instagram.com/globalitibadung_" target="_blank" rel="noopener noreferrer" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://www.facebook.com/globalitibadung" target="_blank" rel="noopener noreferrer" aria-label="Facebook"><i class="fa-brands fa-facebook"></i></a>
                    <a href="https://www.tiktok.com/@globalitibadung_" target="_blank" rel="noopener noreferrer" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                    <a href="https://youtube.com/@smktibaliglobalbadung" target="_blank" rel="noopener noreferrer" aria-label="YouTube"><i class="fa-brands fa-youtube"></i></a>
                </div>
            </div>
            <div>
                <h3>Navigasi</h3>
                <ul>
                    <li><a href="{{ route('welcome') }}">Beranda</a></li>
                    <li><a href="{{ route('profil') }}">Profil Manajemen</a></li>
                    <li><a href="{{ route('program') }}">Program Sekolah</a></li>
                    <li><a href="{{ route('welcome') }}#fasilitas">Fasilitas</a></li>
                </ul>
            </div>
            <div>
                <h3>Program Studi</h3>
                <ul>
                    <li><a href="{{ route('program') }}#tjkt">TJKT</a></li>
                    <li><a href="{{ route('program') }}#pplg">PPLG</a></li>
                    <li><a href="{{ route('program') }}#dkv">DKV</a></li>
                    <li><a href="{{ route('program') }}#bd">BD</a></li>
                </ul>
            </div>
            <div>
                <h3>Kontak</h3>
                <ul class="footer-contact">
                    <li><i class="fa-solid fa-location-dot"></i><span>Jl. Tibungsari No. 1, Desa Dalung, Kuta Utara, Badung, Bali</span></li>
                    <li><i class="fa-solid fa-phone"></i><span>+62 361-419097</span></li>
                    <li><i class="fa-brands fa-whatsapp"></i><span>+62 822-61-9000-70</span></li>
                    <li><i class="fa-solid fa-envelope"></i><span>info@smktibaliglobalbadung.sch.id</span></li>
                </ul>
            </div>
        </div>
        <div class="footer-bottom">
            <div class="container">
                <p>&copy; 2026 SMK TI Bali Global Badung. All rights reserved.</p>
                <nav><a href="#">Kebijakan privasi</a><a href="#">Syarat &amp; Ketentuan</a></nav>
            </div>
        </div>
    </footer>
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jurnal Kelas - Dashboard Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru">
                <a class="dash-menu__item" href="{{ route('guru.jadwal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
                <a class="dash-menu__item" href="{{ route('guru.absen') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24">
                    Absen Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('guru.jurnal') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Jurnal Kelas
                </a>
                <a class="dash-menu__item" href="{{ route('guru.rekap') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Absensi
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <span class="dash-account__name">{{ isset($guru) ? $guru->nama_guru : 'Nama Guru Mapel' }}</span>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-jurnal').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-jurnal" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <span class="dash-brand">Globaliti Badung</span>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Log Jurnal Kelas</h1>
                    </div>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search log" aria-label="Search log">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </div>
                        <button type="button" class="dash-icon-btn" aria-label="Filter">
                            <img class="dash-icon" src="{{ asset('media/vector/filter-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <button type="button" class="dash-btn" data-modal-open="modal-jurnal">
                            Tambah Jurnal
                            <img class="dash-icon" src="{{ asset('media/vector/add-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>
                <ul class="dash-list">
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">XI PPLG 1</span>
                            <span class="dash-card__meta">Rabu, 14 Oktober 2026</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Edit jurnal XI PPLG 1, Rabu, 14 Oktober 2026">
                            <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">XI PPLG 2</span>
                            <span class="dash-card__meta">Rabu, 14 Oktober 2026</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Edit jurnal XI PPLG 2, Rabu, 14 Oktober 2026">
                            <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">XI DKV 1</span>
                            <span class="dash-card__meta">Selasa, 13 Oktober 2026</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Edit jurnal XI DKV 1, Selasa, 13 Oktober 2026">
                            <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">XI DKV 2</span>
                            <span class="dash-card__meta">Selasa, 13 Oktober 2026</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Edit jurnal XI DKV 2, Selasa, 13 Oktober 2026">
                            <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">XI TJKT</span>
                            <span class="dash-card__meta">Senin, 12 Oktober 2026</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Edit jurnal XI TJKT, Senin, 12 Oktober 2026">
                            <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">XI PPLG 1</span>
                            <span class="dash-card__meta">Jumat, 9 Oktober 2026</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Edit jurnal XI PPLG 1, Jumat, 9 Oktober 2026">
                            <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">XI PPLG 2</span>
                            <span class="dash-card__meta">Kamis, 8 Oktober 2026</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Edit jurnal XI PPLG 2, Kamis, 8 Oktober 2026">
                            <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                </ul>
            </div>
        </main>
    </div>

    <!-- Pop-up: Tambah Jurnal (form) -->
    <div class="dash-modal" id="modal-jurnal" role="dialog" aria-modal="true" aria-labelledby="modal-jurnal-title">
        <form class="dash-modal__box" action="#" method="post" tabindex="-1">
            <div class="dash-modal__head">
                <h2 class="dash-modal__title" id="modal-jurnal-title">Tambah Jurnal</h2>
            </div>
            <div class="dash-modal__body">
                <div class="dash-form-grid">
                    <!-- Hari / Tanggal: calendar input (empty; the browser shows its date format) -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-tanggal">Hari / Tanggal</label>
                        <input class="dash-input dash-input--center" type="date" id="jurnal-tanggal" name="tanggal" required>
                    </div>

                    <!-- Jam ke-: 2 x 1 number input, line in the middle -->
                    <div class="dash-field">
                        <span class="dash-label" id="jurnal-jam-label">Jam ke-</span>
                        <div class="dash-range" role="group" aria-labelledby="jurnal-jam-label">
                            <input type="number" name="jam_ke_mulai" placeholder="1" min="1" aria-label="Jam ke awal" required>
                            <span class="dash-range__line" aria-hidden="true"></span>
                            <input type="number" name="jam_ke_selesai" placeholder="2" min="1" aria-label="Jam ke akhir" required>
                        </div>
                    </div>

                    <!-- Mata Pelajaran: option select dropdown -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-mapel">Mata Pelajaran</label>
                        <div class="dash-select">
                            <select class="dash-input" id="jurnal-mapel" name="mata_pelajaran" required>
                                <option value="" selected disabled></option>
                                <option value="Bahasa Indonesia">Bahasa Indonesia</option>
                                <option value="Bahasa Inggris">Bahasa Inggris</option>
                                <option value="Desain Grafis">Desain Grafis</option>
                                <option value="Matematika">Matematika</option>
                                <option value="Pemrograman Dasar">Pemrograman Dasar</option>
                                <option value="Pendidikan Pancasila">Pendidikan Pancasila</option>
                                <option value="Sejarah">Sejarah</option>
                            </select>
                            <img class="dash-icon" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </div>
                    </div>

                    <!-- Pertemuan ke-: 1 x 1 number input -->
                    <div class="dash-field">
                        <label class="dash-label" for="jurnal-pertemuan">Pertemuan ke-</label>
                        <input class="dash-input dash-input--center" type="number" id="jurnal-pertemuan" name="pertemuan_ke" placeholder="1" min="1" required>
                    </div>

                    <!-- Sub-Kompetensi: text area, resizes downward only -->
                    <div class="dash-field dash-field--full">
                        <label class="dash-label" for="jurnal-sub">Sub-Kompetensi</label>
                        <textarea class="dash-input" id="jurnal-sub" name="sub_kompetensi" required></textarea>
                    </div>
                </div>
            </div>
            <div class="dash-modal__foot">
                <button type="button" class="dash-btn dash-btn--ghost" data-modal-close>Batal</button>
                <button type="submit" class="dash-btn">Simpan</button>
            </div>
        </form>
    </div>
</body>
</html>

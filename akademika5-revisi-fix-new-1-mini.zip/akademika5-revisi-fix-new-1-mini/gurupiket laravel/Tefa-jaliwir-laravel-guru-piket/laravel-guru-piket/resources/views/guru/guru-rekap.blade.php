<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Absensi - Dashboard Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru">
                <a class="dash-menu__item" href="{{ route('guru.jadwal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
                <a class="dash-menu__item" href="{{ route('guru.absen') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24">
                    Absen Siswa
                </a>
                <a class="dash-menu__item" href="{{ route('guru.jurnal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jurnal-icon.png') }}" alt="" width="24" height="24">
                    Jurnal Kelas
                </a>
                <a class="dash-menu__item" href="{{ route('guru.rekap') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/clipboard-icon.png') }}" alt="" width="24" height="24">
                    Rekap Absensi
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <span class="dash-account__name">{{ isset($guru) ? $guru->nama_guru : 'Nama Guru Mapel' }}</span>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-rekap').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-rekap" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <span class="dash-brand">Globaliti Badung</span>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Rekap Absensi Siswa</h1>
                    </div>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search class" aria-label="Search class">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </div>
                        <button type="button" class="dash-icon-btn" aria-label="Filter">
                            <img class="dash-icon" src="{{ asset('media/vector/filter-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>
                <ul class="dash-list">
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">Rekap Absensi XI PPLG 1</span>
                            <span class="dash-card__meta">Semester 1 &mdash; 2026/2027</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Unduh rekap absensi XI PPLG 1">
                            <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">Rekap Absensi XI PPLG 2</span>
                            <span class="dash-card__meta">Semester 1 &mdash; 2026/2027</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Unduh rekap absensi XI PPLG 2">
                            <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">Rekap Absensi XI DKV 1</span>
                            <span class="dash-card__meta">Semester 1 &mdash; 2026/2027</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Unduh rekap absensi XI DKV 1">
                            <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">Rekap Absensi XI DKV 2</span>
                            <span class="dash-card__meta">Semester 1 &mdash; 2026/2027</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Unduh rekap absensi XI DKV 2">
                            <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">Rekap Absensi XI TJKT</span>
                            <span class="dash-card__meta">Semester 1 &mdash; 2026/2027</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Unduh rekap absensi XI TJKT">
                            <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">Rekap Absensi X PPLG 1</span>
                            <span class="dash-card__meta">Semester 1 &mdash; 2026/2027</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Unduh rekap absensi X PPLG 1">
                            <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                    <li class="dash-item">
                        <div class="dash-card">
                            <span class="dash-card__name">Rekap Absensi X PPLG 2</span>
                            <span class="dash-card__meta">Semester 1 &mdash; 2026/2027</span>
                        </div>
                        <button type="button" class="dash-action" aria-label="Unduh rekap absensi X PPLG 2">
                            <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </li>
                </ul>
            </div>
        </main>
    </div>
</body>
</html>

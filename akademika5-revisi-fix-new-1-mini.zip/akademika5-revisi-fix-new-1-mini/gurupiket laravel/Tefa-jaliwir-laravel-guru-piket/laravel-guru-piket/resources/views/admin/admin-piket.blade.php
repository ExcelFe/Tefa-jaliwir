<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pilih Guru Piket - Dashboard Admin - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/admin-piket.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu admin">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="../../../media/vector/minimize-icon.png" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman admin">
                <a class="dash-menu__item" href="admin-status.html">
                    <img class="dash-icon" src="../../../media/vector/status-icon.png" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="admin-piket.html" aria-current="page">
                    <img class="dash-icon" src="../../../media/vector/authority-icon.png" alt="" width="24" height="24">
                    Pilih Guru Piket
                </a>
                <a class="dash-menu__item" href="admin-rekap-siswa.html">
                    <img class="dash-icon" src="../../../media/vector/clipboard-icon.png" alt="" width="24" height="24">
                    Rekap Siswa
                </a>
                <a class="dash-menu__item" href="admin-rekap-guru.html">
                    <img class="dash-icon" src="../../../media/vector/clipboard-icon.png" alt="" width="24" height="24">
                    Rekap Guru
                </a>
                <a class="dash-menu__item" href="admin-edit.html">
                    <img class="dash-icon" src="../../../media/vector/edit-icon.png" alt="" width="24" height="24">
                    Edit App
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="../../../media/vector/absensi-icon.png" alt="" width="24" height="24"></span>
                    <span class="dash-account__name">Nama Admin</span>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="../../../media/vector/setting-icon.png" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="../../../media/vector/lightmode-icon.png" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="../../../media/vector/darkmode-icon.png" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="../../../media/vector/info-icon.png" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="../../../media/vector/right-arrow-icon.png" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out: back to the login page until the backend handles sessions -->
                    <a class="dash-settings__item" href="../../login.html">
                        <img class="dash-icon" src="../../../media/vector/log-out-icon.png" alt="" width="24" height="24">
                        Log Out
                    </a>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="../../../media/vector/maximize-icon.png" alt="" width="24" height="24">
            </button>
            <span class="dash-brand">Globaliti Badung</span>
        </div>


        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Log Guru Piket</h1>
                    </div>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search log" aria-label="Search log">
                            <img class="dash-icon" src="../../../media/vector/search-icon.png" alt="" width="24" height="24">
                        </div>
                        <button type="button" class="dash-icon-btn" aria-label="Filter">
                            <img class="dash-icon" src="../../../media/vector/filter-icon.png" alt="" width="24" height="24">
                        </button>
                        <button type="button" class="dash-btn" data-modal-open="modal-piket">
                            Pilih Guru Piket
                            <img class="dash-icon" src="../../../media/vector/add-icon.png" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>

                <section class="dash-section" aria-labelledby="piket-hari-ini">
                    <h2 class="dash-subtitle" id="piket-hari-ini">Guru Piket Hari Ini</h2>
                    <!-- Placeholder: photo, name, date -->
                    <div class="dash-feature">
                        <div class="dash-photo" role="img" aria-label="Foto guru piket">Foto Guru</div>
                        <span class="dash-card__title">Nama Guru Piket</span>
                        <span class="dash-card__meta">Senin, 19 Oktober 2026</span>
                    </div>
                </section>

                <section class="dash-section" aria-labelledby="piket-log">
                    <h2 class="dash-subtitle" id="piket-log">Log Guru Piket</h2>
                    <ul class="dash-list">
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Nama Guru 1</span>
                                <span class="dash-card__meta">Jumat, 16 Oktober 2026</span>
                            </div>
                            <button type="button" class="dash-action" aria-label="Edit guru piket 1, Jumat, 16 Oktober 2026">
                                <img class="dash-icon" src="../../../media/vector/edit-icon.png" alt="" width="24" height="24">
                            </button>
                        </li>
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Nama Guru 2</span>
                                <span class="dash-card__meta">Kamis, 15 Oktober 2026</span>
                            </div>
                            <button type="button" class="dash-action" aria-label="Edit guru piket 2, Kamis, 15 Oktober 2026">
                                <img class="dash-icon" src="../../../media/vector/edit-icon.png" alt="" width="24" height="24">
                            </button>
                        </li>
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Nama Guru 3</span>
                                <span class="dash-card__meta">Rabu, 14 Oktober 2026</span>
                            </div>
                            <button type="button" class="dash-action" aria-label="Edit guru piket 3, Rabu, 14 Oktober 2026">
                                <img class="dash-icon" src="../../../media/vector/edit-icon.png" alt="" width="24" height="24">
                            </button>
                        </li>
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Nama Guru 4</span>
                                <span class="dash-card__meta">Selasa, 13 Oktober 2026</span>
                            </div>
                            <button type="button" class="dash-action" aria-label="Edit guru piket 4, Selasa, 13 Oktober 2026">
                                <img class="dash-icon" src="../../../media/vector/edit-icon.png" alt="" width="24" height="24">
                            </button>
                        </li>
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Nama Guru 5</span>
                                <span class="dash-card__meta">Senin, 12 Oktober 2026</span>
                            </div>
                            <button type="button" class="dash-action" aria-label="Edit guru piket 5, Senin, 12 Oktober 2026">
                                <img class="dash-icon" src="../../../media/vector/edit-icon.png" alt="" width="24" height="24">
                            </button>
                        </li>
                    </ul>
                </section>
            </div>
        </main>
    </div>

    <!-- Pop-up: Pilih Guru Piket untuk hari ini (form). The backend fills the teacher list. -->
    <div class="dash-modal" id="modal-piket" role="dialog" aria-modal="true" aria-labelledby="modal-piket-title">
        <div class="dash-modal__box" tabindex="-1">
            <button type="button" class="dash-modal__close" data-modal-close aria-label="Tutup">&times;</button>
            <div class="dash-modal__head dash-modal__head--center">
                <h2 class="dash-modal__title" id="modal-piket-title">Pilih Guru Piket<br>Untuk Hari Ini</h2>
            </div>
            <div class="dash-modal__body dash-modal__body--last">
                <form class="dash-stack" action="#" method="post">
                    <!-- Hari / Tanggal: calendar input (today by default, admin-piket.js) -->
                    <div class="dash-field">
                        <label class="dash-label dash-label--left" for="piket-tanggal">Hari / Tanggal</label>
                        <input class="dash-input" type="date" id="piket-tanggal" name="tanggal" required>
                    </div>

                    <!-- Pilih Guru Piket: type or choose -->
                    <div class="dash-field">
                        <label class="dash-label dash-label--left" for="piket-guru">Pilih Guru Piket</label>
                        <input class="dash-input" list="daftar-guru" id="piket-guru" name="guru_piket" placeholder="Ketik atau pilih guru..." autocomplete="off" required>
                        <datalist id="daftar-guru">
                            <option value="Nama Guru 1"></option>
                            <option value="Nama Guru 2"></option>
                            <option value="Nama Guru 3"></option>
                            <option value="Nama Guru 4"></option>
                            <option value="Nama Guru 5"></option>
                            <option value="Nama Guru 6"></option>
                            <option value="Nama Guru 7"></option>
                            <option value="Nama Guru 8"></option>
                        </datalist>
                    </div>

                    <button type="submit" class="dash-btn">Berikan Akses</button>
                </form>

                <div class="dash-or">Atau</div>

                <!-- Placeholder code: the real code is created by the backend -->
                <div class="dash-field">
                    <label class="dash-label dash-label--left" for="kode-unik">Buat Kode Unik</label>
                    <div class="dash-copy-field">
                        <input class="dash-input" id="kode-unik" type="text" readonly placeholder="Klik &quot;Buat kode&quot;">
                        <button type="button" class="dash-copy-btn" data-copy aria-label="Salin kode">
                            <img class="dash-icon" src="../../../media/vector/clipboard-icon.png" alt="" width="24" height="24">
                        </button>
                    </div>
                    <button type="button" class="dash-link-btn" data-gen-code>
                        <img class="dash-icon" src="../../../media/vector/add-icon.png" alt="" width="24" height="24">
                        Buat kode
                    </button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

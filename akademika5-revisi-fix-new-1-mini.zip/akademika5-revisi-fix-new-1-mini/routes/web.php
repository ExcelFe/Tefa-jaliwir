<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\JadwalController;
use App\Http\Controllers\GuruDashboardController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\PiketAbsenController;
use App\Http\Controllers\SiswaController;

// Halaman umum
Route::get('/', function () {
    return view('welcome');
})->name('welcome');

Route::get('/program', function () {
    return view('program');
})->name('program');

Route::get('/profil', function () {
    return view('profil-guru');
})->name('profil');

// Halaman login: cukup satu route
Route::get('/login', function () {
    return view('login');
})->middleware('belum.login')->name('login');

// Proses login dan logout
// Akun yang sudah login tidak bisa login ke akun lain sebelum logout.
Route::post('/login', [AuthController::class, 'login'])
    ->middleware('belum.login')
    ->name('login.process');

Route::post('/logout', [AuthController::class, 'logout'])
    ->name('logout');


// ==========================================
// ROUTE ADMIN
// ==========================================
Route::get('/admin/dashboard', [App\Http\Controllers\AdminController::class, 'status'])->name('admin.dashboard');
Route::get('/admin/status', [App\Http\Controllers\AdminController::class, 'status'])->name('admin.status');
Route::get('/admin/piket', [App\Http\Controllers\AdminController::class, 'piket'])->name('admin.piket');
Route::post('/admin/piket/pengganti', [App\Http\Controllers\AdminController::class, 'simpanPiketPengganti'])->name('admin.piket.pengganti');
Route::delete('/admin/piket/pengganti/{id}', [App\Http\Controllers\AdminController::class, 'batalPiketPengganti'])->name('admin.piket.pengganti.batal');
Route::get('/admin/rekap-siswa', [App\Http\Controllers\AdminController::class, 'rekapSiswa'])->name('admin.rekap.siswa');
Route::get('/admin/rekap-guru', [App\Http\Controllers\AdminController::class, 'rekapGuru'])->name('admin.rekap.guru');
Route::get('/admin/rekap-jurnal', [App\Http\Controllers\AdminController::class, 'rekapJurnal'])->name('admin.rekap.jurnal');
// Export Excel: rekap kehadiran guru per semester (6 bulan) dan rekap jurnal per kelas / semua kelas
Route::get('/admin/rekap-guru/export', [App\Http\Controllers\AdminController::class, 'exportRekapGuru'])->name('admin.rekap.guru.export');
Route::get('/admin/rekap-jurnal/export', [App\Http\Controllers\AdminController::class, 'exportRekapJurnal'])->name('admin.rekap.jurnal.export');




// ==========================================
// ROUTE GURU PIKET
// ==========================================
Route::get('/piket/dashboard', function () {
    return redirect()->route('piket.status');
})->name('piket.dashboard');

Route::get('/piket/status', function () {
    if (!session('sudah_login')) {
        return redirect()->route('login');
    }

    $jenis = session('jenis_akun');
    if ($jenis !== 'admin') {
        $kodeGuru = session('kode_guru');
        $now = now('Asia/Makassar');
        $daftarHari = [
            1 => 'senin', 2 => 'selasa', 3 => 'rabu', 4 => 'kamis', 5 => 'jumat',
        ];
        $hariDb = $daftarHari[$now->dayOfWeekIso] ?? 'senin';

        // Cek apakah guru ini terjadwal piket hari ini
        $isPiketTetap = \Illuminate\Support\Facades\DB::table('tb_guru_piket')
            ->where('kode_guru', $kodeGuru)
            ->where('hari', $hariDb)
            ->exists();

        // Cek apakah guru ini ditugaskan sebagai pengganti untuk hari ini
        $isPiketPengganti = \Illuminate\Support\Facades\DB::table('tb_piket_pengganti')
            ->where('kode_guru', $kodeGuru)
            ->whereDate('tanggal', $now->toDateString())
            ->exists();

        if (!$isPiketTetap && !$isPiketPengganti) {
            return redirect()->route('guru.jadwal')->with('error', 'Halaman Guru Piket hanya dapat diakses saat Anda mendapatkan jadwal tugas piket atau ditugaskan sebagai guru piket pengganti.');
        }
    }

    // Tentukan hari ini dalam bahasa Indonesia
    $daftarHari = [
        'Sunday'    => 'Minggu',
        'Monday'    => 'Senin',
        'Tuesday'   => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday'  => 'Kamis',
        'Friday'    => 'Jumat',
        'Saturday'  => 'Sabtu',
    ];

    $daftarBulan = [
        1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
        'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
    ];

    $now = now('Asia/Makassar');
    $namaHariEng = $now->format('l');
    $hariIndo    = $daftarHari[$namaHariEng] ?? 'Senin';
    $hariDb      = strtolower($hariIndo);

    // Jika hari libur sabtu/minggu, jadikan default ke senin agar jadwal mengajar tetap bisa dipratinjau
    if (!in_array($hariDb, ['senin', 'selasa', 'rabu', 'kamis', 'jumat'])) {
        $hariDb = 'senin';
    }

    $tanggalHariIni = $hariIndo . ', ' . $now->format('j')
        . ' ' . ($daftarBulan[(int) $now->format('n')] ?? '')
        . ' ' . $now->format('Y');

    // Ambil data guru
    $guruList = \Illuminate\Support\Facades\DB::table('tb_guru')
        ->select('kode_guru', 'nama', 'mapel')
        ->orderBy('kode_guru')
        ->get();

    // Ambil data absensi hari ini (format DATE YYYY-MM-DD)
    $absenDb = \Illuminate\Support\Facades\DB::table('tb_absen_guru')
        ->whereDate('tanggal', $now->toDateString())
        ->get()
        ->keyBy('kode_guru');

    // Ambil semua jadwal mengajar hari ini
    $jadwalHariIni = \Illuminate\Support\Facades\DB::table('tb_mapel_guru')
        ->where('hari', $hariDb)
        ->orderBy('jam_mulai')
        ->get()
        ->groupBy('kode_guru');

    // Jam saat ini dalam format desimal
    $jamMenitSekarang = (float) $now->format('H.i');

    $dataGuruStatus = $guruList->map(function ($guru) use ($absenDb, $jadwalHariIni, $jamMenitSekarang) {
        $absen = $absenDb[$guru->kode_guru] ?? null;
        $statusRaw = $absen ? strtoupper($absen->status) : null;

        $statusAbsen = match ($statusRaw) {
            'H'      => 'Hadir',
            'I'      => 'Izin',
            'S'      => 'Sakit',
            'A', 'T' => 'Alpa',
            default  => 'Belum Diabsen',
        };
        $isHadir = ($statusAbsen === 'Hadir');

        // Jadwal guru hari ini
        $jadwalGuru = $jadwalHariIni->get($guru->kode_guru, collect());

        // Cari apa yang sedang diajar pada jam sekarang
        $sedangNgajar = null;
        foreach ($jadwalGuru as $j) {
            $mulai   = (float) str_replace(':', '.', $j->jam_mulai);
            $selesai = (float) str_replace(':', '.', $j->jam_selesai);
            if ($jamMenitSekarang >= $mulai && $jamMenitSekarang <= $selesai) {
                $sedangNgajar = $j->nama_mapel . ' di ' . $j->kelas . ' (' . $j->waktu_pelajaran . ')';
                break;
            }
        }

        if (!$sedangNgajar) {
            $sedangNgajar = $jadwalGuru->isNotEmpty()
                ? 'Tidak sedang mengajar (Jadwal: ' . $jadwalGuru->count() . ' jam hari ini)'
                : 'Tidak ada jadwal mengajar hari ini';
        }

        return (object) [
            'kode_guru'     => $guru->kode_guru,
            'nama'          => $guru->nama,
            'mapel_utama'   => $guru->mapel,
            'status_absen'  => $statusAbsen,
            'is_hadir'      => $isHadir,
            'sedang_ngajar' => $sedangNgajar,
            'jadwal_hari_ini' => $jadwalGuru,
        ];
    });

    return view('guru-piket.piket-status', [
        'tanggalHariIni' => $tanggalHariIni,
        'hariDb'         => $hariDb,
        'dataGuruStatus' => $dataGuruStatus,
        'guruList'       => $guruList,
        'absenDb'        => $absenDb,
    ]);
})->name('piket.status');

// Absen Guru — list log + form absensi (CRUD)
Route::get('/piket/absen', [PiketAbsenController::class, 'index'])->name('piket.absen');
Route::get('/piket/absen/data', [PiketAbsenController::class, 'getAbsenByTanggal'])->name('piket.absen.data');
Route::post('/piket/absen/simpan', [PiketAbsenController::class, 'simpan'])->name('piket.absen.simpan');
Route::match(['POST', 'DELETE'], '/piket/absen/hapus', [PiketAbsenController::class, 'hapus'])->name('piket.absen.hapus');
Route::get('/piket/absen/detail', [PiketAbsenController::class, 'detail'])->name('piket.absen.detail');

// Rekap kehadiran guru & rekap jurnal (read-only)
Route::get('/piket/rekap-guru', [\App\Http\Controllers\PiketRekapController::class, 'rekapGuru'])->name('piket.rekap.guru');
Route::get('/piket/rekap-jurnal', [\App\Http\Controllers\PiketRekapController::class, 'rekapJurnal'])->name('piket.rekap.jurnal');
// Export Excel untuk guru piket
Route::get('/piket/rekap-guru/export', [\App\Http\Controllers\PiketRekapController::class, 'exportRekapGuru'])->name('piket.rekap.guru.export');
Route::get('/piket/rekap-jurnal/export', [\App\Http\Controllers\PiketRekapController::class, 'exportRekapJurnal'])->name('piket.rekap.jurnal.export');

Route::get('/piket/jadwal', function (\Illuminate\Http\Request $request) {
    if (!session('sudah_login') || !in_array(session('jenis_akun'), ['guru_piket', 'admin', 'guru'])) {
        return redirect()->route('login');
    }

    $daftarHari = [
        'Sunday'    => 'Minggu',
        'Monday'    => 'Senin',
        'Tuesday'   => 'Selasa',
        'Wednesday' => 'Rabu',
        'Thursday'  => 'Kamis',
        'Friday'    => 'Jumat',
        'Saturday'  => 'Sabtu',
    ];

    $now = now('Asia/Makassar');
    $namaHariEng = $now->format('l');
    $hariIndo    = $daftarHari[$namaHariEng] ?? 'Senin';
    $hariDefault = strtolower($hariIndo);
    if (!in_array($hariDefault, ['senin', 'selasa', 'rabu', 'kamis', 'jumat'])) {
        $hariDefault = 'senin';
    }

    $hariPilihan = strtolower($request->query('hari', $hariDefault));
    if (!in_array($hariPilihan, ['senin', 'selasa', 'rabu', 'kamis', 'jumat'])) {
        $hariPilihan = 'senin';
    }

    // Ambil daftar kelas yang ada
    $daftarKelas = \Illuminate\Support\Facades\DB::table('tb_mapel_murid')
        ->select('kelas')
        ->distinct()
        ->orderBy('kelas')
        ->pluck('kelas');

    $kelasPilihan = $request->query('kelas', $daftarKelas->first() ?? 'X PPLG 1');

    // Ambil jadwal untuk kelas dan hari tersebut
    $query = \Illuminate\Support\Facades\DB::table('tb_mapel_murid')
        ->leftJoin('tb_guru', 'tb_mapel_murid.kode_guru', '=', 'tb_guru.kode_guru')
        ->where('tb_mapel_murid.hari', $hariPilihan)
        ->where('tb_mapel_murid.kelas', $kelasPilihan)
        ->select('tb_mapel_murid.*', 'tb_guru.nama as nama_guru')
        ->orderBy('tb_mapel_murid.jam_sekolah');

    $jadwalRows = $query->get();

    $menitSekarang = $now->hour * 60 + $now->minute;
    $isHariIni = ($hariPilihan === $hariDefault);

    $jadwalList = $jadwalRows->map(function ($j) use ($menitSekarang, $isHariIni) {
        $mulai = null;
        $selesai = null;
        if (preg_match('/^(\d{1,2})[.:](\d{2})$/', trim($j->jam_mulai ?? ''), $m)) {
            $mulai = (int) $m[1] * 60 + (int) $m[2];
        }
        if (preg_match('/^(\d{1,2})[.:](\d{2})$/', trim($j->jam_selesai ?? ''), $m)) {
            $selesai = (int) $m[1] * 60 + (int) $m[2];
        }

        $isOngoing = false;
        $isFinished = false;
        if ($isHariIni && $mulai !== null && $selesai !== null) {
            if ($menitSekarang >= $mulai && $menitSekarang < $selesai) {
                $isOngoing = true;
            } elseif ($menitSekarang >= $selesai) {
                $isFinished = true;
            }
        }

        return (object) [
            'jam_sekolah'     => $j->jam_sekolah,
            'waktu_pelajaran' => $j->waktu_pelajaran ?? ($j->jam_mulai . ' - ' . $j->jam_selesai),
            'nama_mapel'      => $j->nama_mapel,
            'nama_guru'       => $j->nama_guru ?: 'Guru Pengajar',
            'kelas'           => $j->kelas,
            'is_ongoing'      => $isOngoing,
            'is_finished'     => $isFinished,
        ];
    });

    return view('guru-piket.piket-jadwal', compact(
        'daftarKelas',
        'kelasPilihan',
        'hariPilihan',
        'jadwalList'
    ));
})->name('piket.jadwal');


// ==========================================
// ROUTE SISWA
// ==========================================
Route::get('/siswa/dashboard', [SiswaController::class, 'dashboard'])->name('siswa.dashboard');
Route::get('/siswa/jadwal', [SiswaController::class, 'jadwal'])->name('siswa.jadwal');
Route::get('/siswa/status', [SiswaController::class, 'status'])->name('siswa.status');

// API Siswa
Route::get('/jadwal-siswa', [SiswaController::class, 'getJadwalSiswa'])->name('api.jadwal.siswa');
Route::get('/status-guru', [SiswaController::class, 'getStatusGuru'])->name('api.guru.status');


// ==========================================
// ROUTE GURU
// ==========================================
Route::get('/guru/dashboard', [GuruController::class, 'dashboard'])->name('guru.dashboard');
Route::get('/guru/jadwal', [GuruController::class, 'jadwal'])->name('guru.jadwal');

// Absensi Siswa (CRUD)
Route::get('/guru/absen', [GuruController::class, 'absen'])->name('guru.absen');
Route::get('/guru/absen/siswa', [GuruController::class, 'getSiswaByKelas'])->name('guru.absen.siswa');
Route::post('/guru/absen/simpan', [GuruController::class, 'simpanAbsen'])->name('guru.absen.simpan');
Route::match(['POST', 'DELETE'], '/guru/absen/hapus', [GuruController::class, 'hapusAbsen'])->name('guru.absen.hapus');

// Jurnal Kelas (CRUD)
Route::get('/guru/jurnal', [GuruController::class, 'jurnal'])->name('guru.jurnal');
Route::post('/guru/jurnal/simpan', [GuruController::class, 'simpanJurnal'])->name('guru.jurnal.simpan');
Route::match(['POST', 'DELETE'], '/guru/jurnal/hapus/{id}', [GuruController::class, 'hapusJurnal'])->name('guru.jurnal.hapus');

// Rekap Absensi Siswa & Export Excel
Route::get('/guru/rekap', [GuruController::class, 'rekap'])->name('guru.rekap');
Route::get('/guru/rekap/export/{kelas?}', [GuruController::class, 'exportRekap'])->name('guru.rekap.export');
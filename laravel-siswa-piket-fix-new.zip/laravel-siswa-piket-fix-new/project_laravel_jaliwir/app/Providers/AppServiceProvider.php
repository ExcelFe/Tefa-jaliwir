<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Seluruh sekolah memakai WITA: hari, tanggal & jam absen harus sama di semua halaman.
        config(['app.timezone' => 'Asia/Makassar']);
        date_default_timezone_set('Asia/Makassar');

        /*
         * Dua "guard" login terpisah, didaftarkan di sini supaya tidak perlu
         * mengubah config/auth.php:
         *   murid -> tabel tb_akun_murid  (dashboard siswa)
         *   guru  -> tabel tb_akun_piket  (dashboard guru piket)
         * Password dibandingkan apa adanya (tanpa hash) di AuthController.
         */
        config([
            'auth.guards.murid' => ['driver' => 'session', 'provider' => 'akun_murid'],
            'auth.guards.guru'  => ['driver' => 'session', 'provider' => 'akun_piket'],
            'auth.providers.akun_murid' => ['driver' => 'eloquent', 'model' => \App\Models\AkunMurid::class],
            'auth.providers.akun_piket' => ['driver' => 'eloquent', 'model' => \App\Models\AkunPiket::class],
        ]);
    }

    public function boot(): void
    {
        //
    }
}

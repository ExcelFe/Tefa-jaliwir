<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

/**
 * Akun login dashboard guru piket (tabel tb_akun_piket).
 * Password disimpan polos (tanpa hash) dan dibandingkan apa adanya di AuthController.
 */
class AkunPiket extends Authenticatable
{
    protected $table = 'tb_akun_piket';

    public $timestamps = false;

    protected $fillable = ['kode_guru', 'email', 'password'];

    protected $hidden = ['password'];

    /** Data guru (tb_guru) lewat kode_guru. */
    public function guru()
    {
        return $this->belongsTo(Guru::class, 'kode_guru', 'kode_guru');
    }

    /** Nama guru; kalau data guru tidak ada, ambil dari email. */
    public function getNamaAttribute(): string
    {
        $nama = trim((string) $this->guru?->nama);
        if ($nama !== '') {
            return $nama;
        }

        $depan = explode('@', (string) $this->email)[0];

        return ucwords(preg_replace('/\d+$/', '', $depan));
    }
}

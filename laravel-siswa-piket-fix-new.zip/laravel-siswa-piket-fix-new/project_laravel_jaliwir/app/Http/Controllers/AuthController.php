<?php

namespace App\Http\Controllers;

use App\Models\AkunMurid;
use App\Models\AkunPiket;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/**
 * Satu halaman login untuk dua peran:
 *   - guru piket (tb_akun_piket) -> /piket/status
 *   - murid      (tb_akun_murid) -> /siswa/jadwal
 * Password TIDAK di-hash: dibandingkan langsung dengan isi kolom password.
 */
class AuthController extends Controller
{
    public function showLoginForm(): Response
    {
        if (Auth::guard('murid')->check()) {
            return redirect()->route('siswa.jadwal');
        }

        if (Auth::guard('guru')->check()) {
            return redirect()->route('piket.status');
        }

        return response()->view('login')->header('Cache-Control', 'no-store');
    }

    public function login(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'email'    => ['required', 'string'],
            'password' => ['required', 'string'],
        ], [
            'email.required'    => 'Email wajib diisi.',
            'password.required' => 'Password wajib diisi.',
        ]);

        $email    = trim($data['email']);
        $password = $data['password'];

        // 1) Guru piket: hanya akun yang ada di tb_akun_piket
        if ($akun = $this->cariAkun(AkunPiket::class, $email, $password)) {
            $this->keluarSemua();
            Auth::guard('guru')->login($akun);
            $request->session()->regenerate();

            return redirect()->route('piket.status');
        }

        // 2) Murid: tb_akun_murid
        if ($akun = $this->cariAkun(AkunMurid::class, $email, $password)) {
            $this->keluarSemua();
            Auth::guard('murid')->login($akun);
            $request->session()->regenerate();

            return redirect()->route('siswa.jadwal');
        }

        return back()->withErrors(['email' => 'Email atau password salah.'])->onlyInput('email');
    }

    public function logout(Request $request): RedirectResponse
    {
        $this->keluarSemua();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }

    /** Cari akun dengan email + password polos yang cocok (null kalau tidak ada). */
    private function cariAkun(string $model, string $email, string $password)
    {
        foreach ($model::where('email', $email)->get() as $akun) {
            $tersimpan = (string) $akun->password;

            if ($tersimpan !== '' && hash_equals($tersimpan, $password)) {
                return $akun;
            }
        }

        return null;
    }

    private function keluarSemua(): void
    {
        Auth::guard('murid')->logout();
        Auth::guard('guru')->logout();
    }
}

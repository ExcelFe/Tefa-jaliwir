<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Dashboard guru piket (guard: guru).
 *
 *   /piket/status        Status Guru hari ini + tombol "Input Absensi"
 *   /piket/absen         Log absensi (daftar tanggal yang sudah tersimpan) + tombol Detail / Edit
 *   /piket/absen/simpan  Simpan absen guru HARI INI saja -> tb_absen_guru  (dibaca dashboard siswa)
 *   /piket/absen/detail  Detail absen satu tanggal (hanya lihat)
 *   /piket/absen/edit    Edit absen sesuai log yang sudah tersimpan (H / T)
 *   /piket/absen/update  Simpan hasil edit (hanya mengubah baris log yang sudah ada)
 *
 * tb_absen_guru.status (ENUM):  H = Hadir, T = Tidak Hadir.
 */
class PiketController extends Controller
{
    private const TZ = 'Asia/Makassar';

    private const HARI = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu', 7 => 'Minggu'];

    private const BULAN = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April', 5 => 'Mei', 6 => 'Juni',
        7 => 'Juli', 8 => 'Agustus', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
    ];

    private const LABEL_STATUS = ['H' => 'Hadir', 'T' => 'Tidak Hadir', 'A' => 'Tidak Hadir', 'I' => 'Izin', 'S' => 'Sakit'];

    /* ================================================================== */
    /*  STATUS GURU (hari ini)                                            */
    /* ================================================================== */

    public function status()
    {
        $now      = Carbon::now(self::TZ);
        $isLibur  = $now->isWeekend();
        $hariDb   = $isLibur ? 'senin' : strtolower(self::HARI[$now->dayOfWeekIso]);   // akhir pekan: pratinjau jadwal Senin
        $menitNow = $now->hour * 60 + $now->minute;

        $guruList = DB::table('tb_guru')
            ->select('kode_guru', 'nama', 'mapel')
            ->orderBy('kode_guru')
            ->get();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $now->toDateString())
            ->orderBy('id')
            ->get()
            ->keyBy('kode_guru');

        $jadwalHariIni = DB::table('tb_mapel_guru')
            ->where('hari', $hariDb)
            ->whereNotNull('kode_guru')
            ->select('kode_guru', 'nama_mapel', 'jam_sekolah', 'kelas', 'jam_mulai', 'jam_selesai')
            ->get()
            ->sortBy(fn ($r) => [$this->menit($r->jam_mulai) ?? 9999, (int) $r->jam_sekolah])
            ->map(fn ($r) => (object) [
                'kode_guru'   => $r->kode_guru,
                'jam_sekolah' => $r->jam_sekolah,
                'waktu'       => $this->jam($r->jam_mulai) . ' - ' . $this->jam($r->jam_selesai),
                'nama_mapel'  => $r->nama_mapel,
                'kelas'       => trim((string) $r->kelas),
                'mulai'       => $this->menit($r->jam_mulai),
                'selesai'     => $this->menit($r->jam_selesai),
            ])
            ->groupBy('kode_guru');

        $dataGuruStatus = $guruList->map(function ($guru) use ($absenDb, $jadwalHariIni, $menitNow, $isLibur) {
            $kode       = trim((string) ($absenDb->get($guru->kode_guru)->status ?? 'H'));   // belum diabsen = hadir
            $jadwalGuru = $jadwalHariIni->get($guru->kode_guru, collect());

            $sedang = null;
            if (!$isLibur) {
                foreach ($jadwalGuru as $j) {
                    if ($j->mulai !== null && $j->selesai !== null && $menitNow >= $j->mulai && $menitNow < $j->selesai) {
                        $sedang = $j->nama_mapel . ' di ' . $j->kelas . ' (' . $j->waktu . ')';
                        break;
                    }
                }
            }
            if (!$sedang) {
                $sedang = $isLibur
                    ? 'Hari libur (tidak ada KBM)'
                    : ($jadwalGuru->isNotEmpty()
                        ? 'Tidak sedang mengajar (Jadwal: ' . $jadwalGuru->count() . ' jam hari ini)'
                        : 'Tidak ada jadwal mengajar hari ini');
            }

            return (object) [
                'kode_guru'       => $guru->kode_guru,
                'nama'            => trim((string) $guru->nama),
                'mapel_utama'     => $guru->mapel,
                'status_absen'    => self::LABEL_STATUS[$kode] ?? 'Tidak Hadir',
                'is_hadir'        => $kode === 'H',
                'status_db'       => $kode,
                'sedang_ngajar'   => $sedang,
                'jadwal_hari_ini' => $jadwalGuru,
            ];
        });

        return view('guru-piket.piket-status', [
            'tanggalHariIni' => $this->label($now),
            'hariDb'         => $hariDb,
            'dataGuruStatus' => $dataGuruStatus,
            'guruList'       => $guruList,
            'absenDb'        => $absenDb,
        ]);
    }

    /* ================================================================== */
    /*  ABSEN GURU                                                        */
    /* ================================================================== */

    /** Log absensi: daftar tanggal yang sudah tersimpan (histori), masing-masing bisa dilihat / diedit */
    public function absen()
    {
        $logAbsensi = DB::table('tb_absen_guru')
            ->select('tanggal')
            ->distinct()
            ->orderByDesc('tanggal')
            ->limit(120)
            ->pluck('tanggal')
            ->map(fn ($t) => substr((string) $t, 0, 10))
            ->unique()
            ->values()
            ->map(fn ($t) => (object) [
                'tanggal'           => $t,
                'tanggal_formatted' => $this->label(Carbon::parse($t, self::TZ)),
            ]);

        return view('guru-piket.piket-absen', [
            'logAbsensi' => $logAbsensi,
        ]);
    }

    /**
     * Simpan absen guru HARI INI saja -> tb_absen_guru.
     * Tanggal SELALU diambil dari server (zona Asia/Makassar); input tanggal dari browser diabaikan,
     * jadi tidak mungkin absen untuk tanggal / hari lain.
     */
    public function simpan(Request $request): RedirectResponse
    {
        $request->validate([
            'kehadiran'   => ['required', 'array'],
            'kehadiran.*' => ['in:H,T'],
        ], [
            'kehadiran.required' => 'Data kehadiran guru kosong.',
            'kehadiran.*.in'     => 'Status kehadiran hanya boleh Hadir (H) atau Tidak Hadir (T).',
        ]);

        $hariIni   = Carbon::now(self::TZ);
        $tanggal   = $hariIni->toDateString();
        $sekarang  = $hariIni->toDateTimeString();
        $kodeValid = DB::table('tb_guru')->pluck('kode_guru')->map(fn ($k) => (string) $k)->all();

        DB::transaction(function () use ($request, $tanggal, $sekarang, $kodeValid) {
            foreach ($request->input('kehadiran') as $kodeGuru => $nilai) {
                if (!in_array((string) $kodeGuru, $kodeValid, true)) {
                    continue;
                }

                $ada = DB::table('tb_absen_guru')
                    ->where('kode_guru', $kodeGuru)
                    ->whereDate('tanggal', $tanggal)
                    ->orderByDesc('id')
                    ->first();

                if ($ada) {
                    DB::table('tb_absen_guru')->where('id', $ada->id)
                        ->update(['status' => $nilai, 'updated_at' => $sekarang]);
                } else {
                    DB::table('tb_absen_guru')->insert([
                        'kode_guru'  => $kodeGuru,
                        'tanggal'    => $tanggal,
                        'status'     => $nilai,
                        'created_at' => $sekarang,
                        'updated_at' => $sekarang,
                    ]);
                }
            }
        });

        return redirect()->route('piket.status')
            ->with('sukses', 'Absensi guru ' . $this->label($hariIni) . ' berhasil disimpan. Dashboard siswa sudah ikut diperbarui.');
    }

    /** Form edit absen: hanya untuk tanggal yang sudah ada di log, hanya guru yang sudah tercatat. */
    public function edit(Request $request)
    {
        $tgl = $this->tanggalLog((string) $request->query('tanggal', ''));
        if (!$tgl) {
            return redirect()->route('piket.absen')
                ->withErrors(['tanggal' => 'Tanggal tidak ditemukan di log absensi. Hanya absensi yang sudah tersimpan yang bisa diedit.']);
        }

        return view('guru-piket.piket-absen-edit', [
            'tanggal'          => $tgl->toDateString(),
            'tanggalFormatted' => $this->label($tgl),
            'absensi'          => $this->absenLog($tgl->toDateString()),
        ]);
    }

    /** Simpan hasil edit: hanya UPDATE baris log yang sudah ada (tidak menambah baris baru). */
    public function update(Request $request): RedirectResponse
    {
        $request->validate([
            'tanggal'     => ['required', 'date_format:Y-m-d'],
            'kehadiran'   => ['required', 'array'],
            'kehadiran.*' => ['in:H,T'],
        ], [
            'tanggal.required'   => 'Tanggal absensi tidak ditemukan.',
            'tanggal.date_format' => 'Format tanggal tidak valid.',
            'kehadiran.required' => 'Data kehadiran guru kosong.',
            'kehadiran.*.in'     => 'Status kehadiran hanya boleh Hadir (H) atau Tidak Hadir (T).',
        ]);

        $tgl = $this->tanggalLog((string) $request->input('tanggal'));
        if (!$tgl) {
            return redirect()->route('piket.absen')
                ->withErrors(['tanggal' => 'Tanggal tidak ditemukan di log absensi. Hanya absensi yang sudah tersimpan yang bisa diedit.']);
        }

        $iso      = $tgl->toDateString();
        $sekarang = Carbon::now(self::TZ)->toDateTimeString();
        $diubah   = 0;

        DB::transaction(function () use ($request, $iso, $sekarang, &$diubah) {
            foreach ($request->input('kehadiran') as $kodeGuru => $nilai) {
                $baris = DB::table('tb_absen_guru')
                    ->where('kode_guru', $kodeGuru)
                    ->whereDate('tanggal', $iso)
                    ->get();

                if ($baris->isEmpty()) {
                    continue;                           // tidak ada di log -> tidak boleh dibuat lewat edit
                }

                $diubah += DB::table('tb_absen_guru')
                    ->whereIn('id', $baris->pluck('id')->all())
                    ->where('status', '!=', $nilai)
                    ->update(['status' => $nilai, 'updated_at' => $sekarang]);
            }
        });

        return redirect()->route('piket.absen')
            ->with('sukses', 'Absensi guru ' . $this->label($tgl) . ' berhasil diperbarui'
                . ($diubah > 0 ? " ({$diubah} perubahan)." : ' (tidak ada perubahan).')
                . ' Status guru di dashboard guru piket & murid ikut diperbarui.');
    }

    /** Detail absen satu tanggal */
    public function detail(Request $request)
    {
        $q = (string) $request->query('tanggal', '');

        try {
            $tgl = preg_match('/^\d{4}-\d{2}-\d{2}$/', $q)
                ? Carbon::createFromFormat('!Y-m-d', $q, self::TZ)
                : Carbon::now(self::TZ);
        } catch (\Throwable $e) {
            $tgl = Carbon::now(self::TZ);
        }
        $iso = $tgl->toDateString();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $iso)
            ->orderBy('id')
            ->get()
            ->keyBy('kode_guru');

        $absensi = DB::table('tb_guru')
            ->select('kode_guru', 'nama')
            ->orderBy('kode_guru')
            ->get()
            ->map(function ($g) use ($absenDb) {
                $kode = $absenDb->has($g->kode_guru) ? trim((string) $absenDb->get($g->kode_guru)->status) : null;

                return (object) [
                    'nama'   => trim((string) $g->nama),
                    'status' => $kode === null ? 'Belum Diabsen' : (self::LABEL_STATUS[$kode] ?? 'Tidak Hadir'),
                ];
            });

        return view('guru-piket.piket-absen-detail', [
            'tanggal'          => $iso,
            'tanggalFormatted' => $this->label($tgl),
            'absensi'          => $absensi,
        ]);
    }

    /* ================================================================== */

    /** Carbon untuk tanggal yang BENAR-BENAR ada di log tb_absen_guru, atau null. */
    private function tanggalLog(string $q): ?Carbon
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $q)) {
            return null;
        }

        try {
            $tgl = Carbon::createFromFormat('!Y-m-d', $q, self::TZ);
        } catch (\Throwable $e) {
            return null;
        }

        if (!$tgl || $tgl->toDateString() !== $q) {
            return null;
        }

        return DB::table('tb_absen_guru')->whereDate('tanggal', $q)->exists() ? $tgl : null;
    }

    /** Baris log satu tanggal (hanya guru yang tercatat) beserta nama guru. */
    private function absenLog(string $iso)
    {
        $namaGuru = DB::table('tb_guru')->pluck('nama', 'kode_guru');

        return DB::table('tb_absen_guru')
            ->whereDate('tanggal', $iso)
            ->orderBy('kode_guru')
            ->orderBy('id')
            ->get()
            ->unique('kode_guru')
            ->values()
            ->map(fn ($r) => (object) [
                'kode_guru' => $r->kode_guru,
                'nama'      => trim((string) ($namaGuru[$r->kode_guru] ?? ('Guru #' . $r->kode_guru))),
                'status'    => trim((string) $r->status) === 'H' ? 'H' : 'T',
            ]);
    }

    private function label(Carbon $d): string
    {
        return self::HARI[$d->dayOfWeekIso] . ', ' . $d->day . ' ' . self::BULAN[$d->month] . ' ' . $d->year;
    }

    /** '07.05' / '07:05' -> menit sejak 00:00 (null kalau format tidak dikenali) */
    private function menit(?string $jam): ?int
    {
        if ($jam !== null && preg_match('/^(\d{1,2})[.:](\d{2})/', trim($jam), $m)) {
            return (int) $m[1] * 60 + (int) $m[2];
        }

        return null;
    }

    /** '07.05' -> '07:05' */
    private function jam(?string $jam): string
    {
        return $jam === null ? '' : str_replace('.', ':', trim($jam));
    }
}

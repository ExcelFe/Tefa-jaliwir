<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

/**
 * Jadwal siswa dinonaktifkan sementara (masih memakai data dummy data-mock.js).
 * Status guru membaca tabel tb_absen_guru (join tb_guru).
 */
class DashboardController extends Controller
{
    /**
     * GET /status-guru?tanggal=YYYY-MM-DD
     * Mengembalikan guru yang punya data absen pada tanggal tsb.
     * Status hanya 2: Hadir (H) dan Tidak Hadir (selain H).
     */
    public function getStatusGuru(Request $request)
    {
        $tanggal = $request->query('tanggal');

        // Validasi format tanggal; kalau kosong/salah, pakai hari ini (WITA)
        if (!is_string($tanggal) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal) || !$this->tanggalValid($tanggal)) {
            $tanggal = Carbon::now('Asia/Makassar')->format('Y-m-d');
        }

        $guru = DB::table('tb_absen_guru')
            ->join('tb_guru', 'tb_absen_guru.kode_guru', '=', 'tb_guru.kode_guru')
            ->whereDate('tb_absen_guru.tanggal', $tanggal)
            ->select(
                'tb_absen_guru.id',
                'tb_guru.kode_guru',
                'tb_guru.nama',
                'tb_guru.mapel',
                'tb_absen_guru.status as status_db'
            )
            ->orderByDesc('tb_absen_guru.id')   // data absen terbaru dulu
            ->get()
            ->unique('kode_guru')               // 1 guru = 1 baris (ambil yang terbaru)
            ->sortBy('nama', SORT_NATURAL | SORT_FLAG_CASE)
            ->values()
            ->map(function ($item) {
                $hadir = $item->status_db === 'H';

                return [
                    'nama'        => $item->nama ?: 'Guru',
                    'mapel'       => !empty($item->mapel) ? $item->mapel : '-',
                    'status'      => $hadir ? 'hadir' : 'tidak',
                    'statusClass' => $hadir ? 'ok' : 'bad',
                    'statusLabel' => $hadir ? 'Hadir' : 'Tidak Hadir',
                ];
            });

        return response()->json($guru);
    }

    private function tanggalValid(string $tanggal): bool
    {
        [$y, $m, $d] = array_map('intval', explode('-', $tanggal));
        return checkdate($m, $d, $y);
    }
}
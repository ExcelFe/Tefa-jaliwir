<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/** Hanya murid yang sudah login yang boleh membuka dashboard siswa. */
class EnsureMurid
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::guard('murid')->check()) {
            return redirect()->route('login');
        }

        $response = $next($request);

        // Setelah logout, tombol "back" tidak boleh menampilkan halaman dashboard lama.
        $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');

        return $response;
    }
}

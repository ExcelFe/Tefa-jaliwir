<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

/** Hanya akun dari tb_akun_piket yang sudah login yang boleh membuka dashboard guru piket. */
class EnsureGuruPiket
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::guard('guru')->check()) {
            return redirect()->route('login');
        }

        $response = $next($request);
        $response->headers->set('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0');

        return $response;
    }
}

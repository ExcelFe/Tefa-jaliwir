<?php

use App\Models\AkunMurid;
return [
'guards' => [
    'web' => [
        'driver' => 'session',
        'provider' => 'users',
    ],

    'murid' => [
        'driver' => 'session',
        'provider' => 'murids',
    ],
],

'providers' => [
    'users' => [
        'driver' => 'eloquent',
        'model' => App\Models\User::class,
    ],

    'murids' => [
        'driver' => 'eloquent',
        'model' => App\Models\AkunMurid::class,
    ],
],
];
<?php $__env->startSection('title', 'Jadwal'); ?>

<?php $__env->startSection('content'); ?>
    <header class="dash-head">
        <div class="dash-head__title">
            <h1 class="dash-title">Jadwal Pelajaran (Per Kelas)</h1>
        </div>
    </header>

    <!-- Hijau = sedang berlangsung, merah = belum / sudah selesai -->
    <section class="dash-section" aria-labelledby="jadwal-hari-ini">
        <h2 class="dash-subtitle" id="jadwal-hari-ini">
            <?php echo e($hari === $hariIni ? 'Jadwal Hari Ini' : 'Jadwal Hari ' . $hariList[$hari]); ?><?php echo e($kelas ? ' - ' . $kelas : ''); ?>

        </h2>

        <?php if($akhirPekan): ?>
            <p class="dash-note">Hari ini akhir pekan (tidak ada pelajaran). Pilih hari di bawah untuk melihat jadwal.</p>
        <?php endif; ?>

        <!-- Tab hari: link ke ?hari=... (server-side) -->
        <nav class="dash-daytabs" aria-label="Pilih hari">
            <?php $__currentLoopData = $hariList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dash-daytab <?php echo e($key === $hari ? 'is-active' : ''); ?>"
                   href="<?php echo e(route('siswa.jadwal', ['hari' => $key])); ?>"
                   <?php if($key === $hari): ?> aria-current="page" <?php endif; ?>><?php echo e($label); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        <ul class="dash-list">
            <?php $__empty_1 = true; $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <div class="dash-jadwal-card <?php echo e($j['status'] === 'Sedang Berlangsung' ? 'dash-jadwal-card--on' : 'dash-jadwal-card--off'); ?>" title="<?php echo e($j['status']); ?>">
                        <div class="dash-jadwal-card__info">
                            <span class="dash-jadwal-card__subject"><?php echo e($j['mapel']); ?></span><br>
                            <span class="dash-jadwal-card__teacher"><?php echo e($j['pengajar']); ?></span>
                        </div>
                        <span class="dash-jadwal-card__time"><?php echo e($j['waktu']); ?></span>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="dash-item">
                    <div class="dash-card">
                        <span class="dash-card__name">
                            <?php if(!$kelas): ?>
                                Kelas belum terdata pada akun ini.
                            <?php else: ?>
                                Belum ada jadwal untuk kelas <?php echo e($kelas); ?> pada hari <?php echo e($hariList[$hari]); ?>.
                            <?php endif; ?>
                        </span>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\project_laravel_jaliwir\resources\views/siswa/jadwal.blade.php ENDPATH**/ ?>
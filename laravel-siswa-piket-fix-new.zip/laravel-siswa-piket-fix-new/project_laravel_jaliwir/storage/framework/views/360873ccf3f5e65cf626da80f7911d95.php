<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animation.css')); ?>">
    <script defer src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/login.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/animation.js')); ?>"></script>
</head>
<body class="page-login theme-warm">
    <main class="login-main">
        <div class="login-card">
            <section class="login-brand">
                <div class="login-logo">
                    <img src="<?php echo e(asset('media/logo.webp')); ?>" alt="Logo SMK TI Bali Global Badung" width="136" height="136">
                </div>
                <p class="login-school">SMK TI BALI <span>GLOBAL BADUNG</span></p>
            </section>

            <section class="login-panel">
                <a class="back-btn" href="<?php echo e(url('/beranda')); ?>" data-back aria-label="Kembali ke halaman sebelumnya"></a>

                <div class="login-head">
                    <h1>Sign In</h1>
                    <p>Masukkan email dan password akun Anda (murid atau guru piket)</p>
                </div>

                <?php if($errors->any()): ?>
                    <div role="alert" style="background-color: #fee2e2; color: #b91c1c; padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; font-size: 14px;">
                        <?php echo e($errors->first()); ?>

                    </div>
                <?php endif; ?>

                <form class="login-form" method="POST" action="<?php echo e(route('login.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="login-fields">
                        <label class="login-field login-field--email">
                            <img src="<?php echo e(asset('media/email.png')); ?>" alt="" width="16" height="16">
                            <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="Email" aria-label="Email" autocomplete="email" required>
                        </label>
                        <label class="login-field login-field--password">
                            <img src="<?php echo e(asset('media/lock.png')); ?>" alt="" width="10" height="10">
                            <input type="password" name="password" id="password" placeholder="Password" aria-label="Password" autocomplete="current-password" required>
                            <button type="button" class="password-toggle" id="password-toggle" aria-label="Tampilkan password" aria-pressed="false"
                                    data-icon-show="<?php echo e(asset('media/vector/eye-icon.png')); ?>"
                                    data-icon-hide="<?php echo e(asset('media/vector/eye-off.png')); ?>">
                                <img src="<?php echo e(asset('media/vector/eye-off.png')); ?>" alt="" class="password-toggle__icon" width="20" height="20">
                            </button>
                        </label>
                    </div>
                    <div class="login-actions">
                        <button type="submit" class="btn-signin">Sign In</button>
                    </div>
                </form>
            </section>
        </div>
    </main>
</body>
</html><?php /**PATH C:\laragon\www\project_laravel_jaliwir\resources\views/login.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Guru - Dashboard Guru Piket - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animation.css')); ?>">
    <script defer src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/guru-absen-siswa.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/animation.js')); ?>"></script>
    <style>
        .dash-card--status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: var(--space-3);
            width: 100%;
            padding: var(--space-3) var(--space-4);
        }
        .dash-card__content {
            flex: 1;
            min-width: 0;
        }
        .dash-card__teaching {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 0.35rem;
            font-size: 0.875rem;
            color: var(--dash-muted);
        }
        .dash-card__teaching-badge {
            display: inline-block;
            padding: 0.15rem 0.6rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 600;
            background: color-mix(in srgb, var(--dash-accent) 18%, transparent);
            color: var(--dash-accent);
            border: 1px solid color-mix(in srgb, var(--dash-accent) 30%, transparent);
            white-space: nowrap;
        }
        .dash-card__right-actions {
            display: flex;
            align-items: center;
            gap: var(--space-3);
            flex-shrink: 0;
        }
        .btn-detail-jadwal {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.45rem 0.9rem;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: var(--radius-pill);
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            color: var(--dash-ink);
            cursor: pointer;
            transition: all 0.15s ease;
            white-space: nowrap;
        }
        .btn-detail-jadwal:hover {
            background: var(--dash-hover);
            border-color: var(--dash-accent);
            color: var(--dash-accent);
        }
        .date-banner-info {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: var(--space-2);
            padding: var(--space-3) var(--space-4);
            margin-bottom: var(--space-4);
            border: 1px solid var(--dash-edge);
            border-radius: var(--radius-md);
            background: var(--dash-surface);
            box-shadow: var(--dash-shadow);
        }
        .date-banner-info__day {
            font-family: var(--font-heading);
            font-size: 1.25rem;
            text-transform: uppercase;
            letter-spacing: 0.02em;
        }
        .date-banner-info__meta {
            font-size: 0.85rem;
            color: var(--dash-muted);
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru piket">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/minimize-icon.png')); ?>" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru piket">
                <a class="dash-menu__item" href="<?php echo e(route('piket.status')); ?>" aria-current="page">
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/status-icon.png')); ?>" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="<?php echo e(route('piket.absen')); ?>">
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/absensi-icon.png')); ?>" alt="" width="24" height="24">
                    Absen Guru
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="<?php echo e(asset('media/vector/absensi-icon.png')); ?>" alt="" width="24" height="24"></span>
                    <span class="dash-account__name"><?php echo e(Auth::guard('guru')->user()?->nama ?? 'Guru Piket'); ?></span>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/setting-icon.png')); ?>" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="<?php echo e(asset('media/vector/lightmode-icon.png')); ?>" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="<?php echo e(asset('media/vector/darkmode-icon.png')); ?>" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="<?php echo e(asset('media/vector/info-icon.png')); ?>" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="<?php echo e(asset('media/vector/right-arrow-icon.png')); ?>" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form-piket-status').submit();">
                        <img class="dash-icon" src="<?php echo e(asset('media/vector/log-out-icon.png')); ?>" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-piket-status" action="<?php echo e(route('logout')); ?>" method="POST" style="display:none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="<?php echo e(asset('media/vector/maximize-icon.png')); ?>" alt="" width="24" height="24">
            </button>
            <span class="dash-brand">Globaliti Badung</span>
        </div>


        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Status Guru</h1>
                    </div>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search name" aria-label="Search name" id="search-guru" oninput="filterGuruList()">
                            <img class="dash-icon" src="<?php echo e(asset('media/vector/search-icon.png')); ?>" alt="" width="24" height="24">
                        </div>
                        <!-- <button type="button" class="dash-icon-btn" aria-label="Filter" onclick="toggleFilterStatus()">
                            <img class="dash-icon" src="<?php echo e(asset('media/vector/filter-icon.png')); ?>" alt="" width="24" height="24">
                        </button> -->
                        <button type="button" class="dash-btn" data-modal-open="modal-absen">
                            Input Absensi
                            <img class="dash-icon" src="<?php echo e(asset('media/vector/add-icon.png')); ?>" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>

                <?php if(session('sukses')): ?>
                    <div style="background-color: #dcfce7; color: #15803d; border: 1px solid #86efac; padding: 0.75rem 1rem; border-radius: var(--radius-md); margin-bottom: var(--space-4); font-weight: 600; display: flex; align-items: center; justify-content: space-between;">
                        <span><?php echo e(session('sukses')); ?></span>
                        <button type="button" onclick="this.parentElement.remove()" style="background:none; border:none; color:inherit; cursor:pointer; font-weight:bold; font-size:1.2rem;">&times;</button>
                    </div>
                <?php endif; ?>

                <!-- Tanggal Hari Ini Banner -->
                <div class="date-banner-info">
                    <div>
                        <div class="date-banner-info__day"><?php echo e($tanggalHariIni); ?></div>
                        <div class="date-banner-info__meta">Jadwal Aktif Hari: <strong style="text-transform: capitalize;"><?php echo e($hariDb); ?></strong> &bull; Total Guru Terdaftar: <strong><?php echo e(count($dataGuruStatus)); ?></strong></div>
                    </div>
                    <div>
                        <span style="display: inline-flex; align-items: center; gap: 0.4rem; font-size: 0.85rem; font-weight: 600; margin-right: 1rem;">
                            <span class="dash-status dash-status--on" style="width: 1rem; height: 1rem; border-radius: 50%;"></span>
                            Hadir: <?php echo e($dataGuruStatus->where('is_hadir', true)->count()); ?>

                        </span>
                        <span style="display: inline-flex; align-items: center; gap: 0.4rem; font-size: 0.85rem; font-weight: 600;">
                            <span class="dash-status dash-status--off" style="width: 1rem; height: 1rem; border-radius: 50%;"></span>
                            Tidak Hadir / Lainnya: <?php echo e($dataGuruStatus->where('is_hadir', false)->count()); ?>

                        </span>
                    </div>
                </div>

                <!-- Daftar Status Semua Guru -->
                <ul class="dash-list" id="guru-status-list">
                    <?php $__empty_1 = true; $__currentLoopData = $dataGuruStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="dash-item guru-item-card" data-nama="<?php echo e(strtolower($item->nama)); ?>" data-status="<?php echo e($item->is_hadir ? 'hadir' : 'tidak-hadir'); ?>">
                            <div class="dash-card dash-card--status">
                                <div class="dash-card__content">
                                    <div style="display: flex; align-items: baseline; gap: 0.75rem; flex-wrap: wrap;">
                                        <span class="dash-card__name"><?php echo e($item->nama); ?></span>
                                        <span class="dash-card__meta" style="margin-left: 0;"><?php echo e($tanggalHariIni); ?></span>
                                    </div>
                                    <div class="dash-card__teaching">
                                        <span class="dash-card__teaching-badge">Sedang Mengajar:</span>
                                        <span><?php echo e($item->sedang_ngajar); ?></span>
                                    </div>
                                </div>

                                <div class="dash-card__right-actions">
                                    <button type="button" class="btn-detail-jadwal" data-modal-open="modal-jadwal-<?php echo e($item->kode_guru); ?>" aria-label="Lihat jadwal mengajar <?php echo e($item->nama); ?> hari ini">
                                        <img class="dash-icon" src="<?php echo e(asset('media/vector/jadwal-icon.png')); ?>" alt="" width="16" height="16" style="width: 1rem; height: 1rem;">
                                        Lihat Detail Jadwal
                                    </button>
                                    <?php if($item->is_hadir): ?>
                                        <span class="dash-status dash-status--on" role="img" aria-label="Hadir: <?php echo e($item->nama); ?>" title="Status: Hadir"></span>
                                    <?php else: ?>
                                        <span class="dash-status dash-status--off" role="img" aria-label="<?php echo e($item->status_absen); ?>: <?php echo e($item->nama); ?>" title="Status: <?php echo e($item->status_absen); ?>"></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </li>

                        <!-- Modal Detail Jadwal Guru Hari Ini (tanpa pindah halaman) -->
                        <div class="dash-modal" id="modal-jadwal-<?php echo e($item->kode_guru); ?>" role="dialog" aria-modal="true" aria-labelledby="modal-jadwal-title-<?php echo e($item->kode_guru); ?>">
                            <div class="dash-modal__box dash-modal__box--wide" tabindex="-1">
                                <div class="dash-modal__head" style="border-bottom: 1px solid var(--dash-edge);">
                                    <h2 class="dash-modal__title" id="modal-jadwal-title-<?php echo e($item->kode_guru); ?>">Jadwal Mengajar Hari Ini</h2>
                                    <p style="margin: 0.25rem 0 0; color: var(--dash-muted); font-size: 0.9rem;">
                                        <strong><?php echo e($item->nama); ?></strong> &bull; <?php echo e($tanggalHariIni); ?>

                                    </p>
                                </div>
                                <div class="dash-modal__body dash-modal__body--table" style="padding-top: 1rem;">
                                    <table class="dash-table">
                                        <caption class="dash-sr">Jadwal Mengajar <?php echo e($item->nama); ?> Hari Ini</caption>
                                        <thead>
                                            <tr>
                                                <th scope="col" style="width: 4rem;">Jam Ke</th>
                                                <th scope="col" style="width: 8rem;">Waktu</th>
                                                <th scope="col">Mata Pelajaran</th>
                                                <th scope="col" style="width: 8rem;">Kelas</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_2 = true; $__currentLoopData = $item->jadwal_hari_ini; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <tr>
                                                    <td><?php echo e($jadwal->jam_sekolah ?? '-'); ?></td>
                                                    <td style="font-weight: 600;"><?php echo e($jadwal->waktu); ?></td>
                                                    <td class="dash-table__name" style="font-weight: 600;"><?php echo e($jadwal->nama_mapel); ?></td>
                                                    <td>
                                                        <span style="display: inline-block; padding: 0.2rem 0.6rem; border-radius: var(--radius-pill); font-weight: 600; font-size: 0.8rem; background: var(--dash-hover);">
                                                            <?php echo e($jadwal->kelas); ?>

                                                        </span>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <tr>
                                                    <td colspan="4" style="padding: 2.5rem 1rem; color: var(--dash-muted); text-align: center;">
                                                        Tidak ada jadwal mengajar pada hari <?php echo e(ucfirst($hariDb)); ?>.
                                                    </td>
                                                </tr>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="dash-modal__foot" style="border-top: 1px solid var(--dash-edge);">
                                    <button type="button" class="dash-btn" data-modal-close>Tutup</button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Belum ada data guru terdaftar.</span>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </main>
    </div>

    <!-- Pop-up: Form Absensi Guru dari Dashboard -->
    <div class="dash-modal" id="modal-absen" role="dialog" aria-modal="true" aria-labelledby="modal-absen-title">
        <form class="dash-modal__box dash-modal__box--wide" action="<?php echo e(route('piket.absen.simpan')); ?>" method="POST" tabindex="-1" style="max-height: 85vh; display: flex; flex-direction: column;">
            <?php echo csrf_field(); ?>
            <div class="dash-modal__head" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem; border-bottom: 1px solid var(--dash-edge);">
                <div>
                    <h2 class="dash-modal__title" id="modal-absen-title">Input Absensi Guru Hari Ini</h2>
                    <p style="margin: 0.2rem 0 0; color: var(--dash-muted); font-size: 0.85rem;">
                        Hanya untuk hari ini &bull; Total Guru: <?php echo e(count($guruList)); ?>

                    </p>
                </div>
                <div style="display: inline-flex; align-items: center; gap: 0.5rem; background: var(--dash-hover); padding: 0.35rem 0.75rem; border-radius: var(--radius-pill); border: 1px solid var(--dash-edge);">
                    <span style="font-size: 0.8rem; font-weight: 600; color: var(--dash-muted);">Tanggal:</span>
                    <span id="tanggal_input_status" style="font-size: 0.875rem; color: var(--dash-ink); font-weight: 600;"><?php echo e($tanggalHariIni); ?></span>
                </div>
            </div>

            <div class="dash-modal__body dash-modal__body--table" style="max-height: 60vh; overflow-y: auto; flex: 1;">
                <table class="dash-table">
                    <caption class="dash-sr">Daftar kehadiran guru</caption>
                    <thead>
                        <tr>
                            <th scope="col" rowspan="2" style="width: 3.5rem;">No.</th>
                            <th scope="col" rowspan="2" class="dash-table__name">Nama Guru</th>
                            <th scope="colgroup" colspan="2" style="text-align: center;">Kehadiran</th>
                        </tr>
                        <tr>
                            <th scope="col" style="width: 5.5rem; text-align: center;">Hadir</th>
                            <th scope="col" style="width: 5.5rem; text-align: center;">Tidak Hadir</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $guruList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $absenRecord = $absenDb[$guru->kode_guru] ?? null;
                                $currentStatus = $absenRecord ? trim((string) $absenRecord->status) : 'H';
                            ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td class="dash-table__name" style="font-weight: 600;"><?php echo e($guru->nama); ?></td>
                                <td style="text-align: center;">
                                    <input class="dash-check dash-check--ok" type="radio" name="kehadiran[<?php echo e($guru->kode_guru); ?>]" value="H" <?php echo e($currentStatus === 'H' ? 'checked' : ''); ?> aria-label="Hadir: <?php echo e($guru->nama); ?>" required>
                                </td>
                                <td style="text-align: center;">
                                    <input class="dash-check dash-check--bad" type="radio" name="kehadiran[<?php echo e($guru->kode_guru); ?>]" value="T" <?php echo e($currentStatus !== 'H' ? 'checked' : ''); ?> aria-label="Tidak hadir: <?php echo e($guru->nama); ?>">
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="dash-modal__foot" style="border-top: 1px solid var(--dash-edge);">
                <button type="button" class="dash-btn dash-btn--ghost" data-modal-close>Batal</button>
                <button type="submit" class="dash-btn">Simpan Absensi</button>
            </div>
        </form>
    </div>

    <script>
        function filterGuruList() {
            const input = document.getElementById('search-guru');
            const filter = input.value.toLowerCase().trim();
            const items = document.querySelectorAll('.guru-item-card');

            items.forEach(item => {
                const nama = item.getAttribute('data-nama') || '';
                if (nama.indexOf(filter) > -1) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        let filterHadirState = 'all'; // all, hadir, tidak-hadir
        function toggleFilterStatus() {
            const items = document.querySelectorAll('.guru-item-card');
            if (filterHadirState === 'all') {
                filterHadirState = 'hadir';
            } else if (filterHadirState === 'hadir') {
                filterHadirState = 'tidak-hadir';
            } else {
                filterHadirState = 'all';
            }

            items.forEach(item => {
                const status = item.getAttribute('data-status');
                if (filterHadirState === 'all') {
                    item.style.display = '';
                } else if (filterHadirState === status) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>
<?php /**PATH C:\laragon\www\project_laravel_jaliwir\resources\views/guru-piket/piket-status.blade.php ENDPATH**/ ?>
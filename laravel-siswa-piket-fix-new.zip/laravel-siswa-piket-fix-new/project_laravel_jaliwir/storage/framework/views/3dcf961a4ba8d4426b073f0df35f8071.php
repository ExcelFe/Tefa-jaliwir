<?php $__env->startSection('title', 'Status Guru'); ?>

<?php $__env->startSection('content'); ?>
    <header class="dash-head">
        <div class="dash-head__title">
            <h1 class="dash-title">Status Guru</h1>
            <p class="dash-sub"><?php echo e($tanggalLabel); ?></p>
        </div>
        <div class="dash-tools">
            <div class="dash-search" role="search">
                <input type="search" id="cari-guru" placeholder="Search name" aria-label="Search name" autocomplete="off">
                <img class="dash-icon" src="<?php echo e(asset('media/vector/search-icon.png')); ?>" alt="" width="24" height="24">
            </div>
        </div>
    </header>

    <!-- Hijau = hadir, merah = tidak hadir -->
    <ul class="dash-list" id="daftar-guru">
        <?php $__empty_1 = true; $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li class="dash-item" data-cari data-nama="<?php echo e($g['nama']); ?>">
                <div class="dash-jadwal-card <?php echo e($g['status'] === 'hadir' ? 'dash-jadwal-card--on' : 'dash-jadwal-card--off'); ?>" style="flex: 1;">
                    <div class="dash-jadwal-card__info">
                        <span class="dash-card__name"><?php echo e($g['nama']); ?></span>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <li class="dash-item">
                <div class="dash-card">
                    <span class="dash-card__name">Belum ada data absen guru pada <?php echo e($tanggalLabel); ?>.</span>
                </div>
            </li>
        <?php endif; ?>

        
        <li class="dash-item" id="cari-kosong" style="display:none">
            <div class="dash-card">
                <span class="dash-card__name">Guru tidak ditemukan.</span>
            </div>
        </li>
    </ul>

    
    <script>
    (function () {
        var q = document.getElementById('cari-guru');
        var list = document.getElementById('daftar-guru');
        var kosong = document.getElementById('cari-kosong');
        if (!q || !list) return;

        // huruf kecil, buang aksen, titik/koma/spasi ganda -> satu spasi
        function norm(s) {
            s = String(s == null ? '' : s).toLowerCase();
            if (s.normalize) s = s.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
            return s.replace(/[^a-z0-9]+/g, ' ').trim();
        }

        var items = Array.prototype.slice.call(list.querySelectorAll('.dash-item[data-cari]'));
        var index = items.map(function (li) {
            return { el: li, teks: ' ' + norm(li.getAttribute('data-nama') || li.textContent) + ' ' };
        });

        function filter() {
            var kata = norm(q.value).split(' ').filter(Boolean);
            var tampil = 0;

            index.forEach(function (it) {
                // semua kata yang diketik harus ada di nama guru
                var cocok = kata.every(function (k) { return it.teks.indexOf(k) !== -1; });
                it.el.style.display = cocok ? '' : 'none';
                if (cocok) tampil++;
            });

            if (kosong) kosong.style.display = (kata.length && index.length && !tampil) ? '' : 'none';
        }

        q.addEventListener('keydown', function (e) { if (e.key === 'Enter') e.preventDefault(); });
        ['input', 'keyup', 'search', 'change'].forEach(function (ev) { q.addEventListener(ev, filter); });

        filter(); // kalau browser mengisi ulang kolom cari saat reload
    })();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.siswa', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\project_laravel_jaliwir\resources\views/siswa/status.blade.php ENDPATH**/ ?>
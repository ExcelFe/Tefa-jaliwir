<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?> - Dashboard Siswa - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animation.css')); ?>">
    <script defer src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script defer src="<?php echo e(asset('js/animation.js')); ?>"></script>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu siswa">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/minimize-icon.png')); ?>" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman siswa">
                <a class="dash-menu__item" href="<?php echo e(route('siswa.jadwal')); ?>" <?php if(request()->routeIs('siswa.jadwal')): ?> aria-current="page" <?php endif; ?>>
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/jadwal-icon.png')); ?>" alt="" width="24" height="24">
                    Jadwal
                </a>
                <a class="dash-menu__item" href="<?php echo e(route('siswa.status')); ?>" <?php if(request()->routeIs('siswa.status')): ?> aria-current="page" <?php endif; ?>>
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/status-icon.png')); ?>" alt="" width="24" height="24">
                    Status Guru
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="<?php echo e(asset('media/vector/absensi-icon.png')); ?>" alt="" width="24" height="24"></span>
                    <span class="dash-account__name"><?php echo e(Auth::guard('murid')->user()->nama); ?></span>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="<?php echo e(asset('media/vector/setting-icon.png')); ?>" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="<?php echo e(asset('media/vector/lightmode-icon.png')); ?>" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="<?php echo e(asset('media/vector/darkmode-icon.png')); ?>" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="<?php echo e(asset('media/vector/info-icon.png')); ?>" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="<?php echo e(asset('media/vector/right-arrow-icon.png')); ?>" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out: POST ke Laravel (hapus sesi + token CSRF baru) -->
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="dash-settings__item">
                            <img class="dash-icon" src="<?php echo e(asset('media/vector/log-out-icon.png')); ?>" alt="" width="24" height="24">
                            Log Out
                        </button>
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="<?php echo e(asset('media/vector/maximize-icon.png')); ?>" alt="" width="24" height="24">
            </button>
            <span class="dash-brand">Globaliti Badung</span>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH C:\laragon\www\project_laravel_jaliwir\resources\views/layouts/siswa.blade.php ENDPATH**/ ?>
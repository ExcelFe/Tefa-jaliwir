<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\PiketController;
use App\Http\Controllers\SiswaController;
use App\Http\Middleware\EnsureGuruPiket;
use App\Http\Middleware\EnsureMurid;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Halaman publik (landing sebelum login) - dari folder siswa
|--------------------------------------------------------------------------
*/
Route::get('/', fn () => view('beranda'))->name('home');
Route::get('/beranda', fn () => view('beranda'))->name('beranda');
Route::get('/profil-manajemen', fn () => view('profil-manajemen'))->name('profil');
Route::get('/program-sekolah', fn () => view('program-sekolah'))->name('program');

/*
|--------------------------------------------------------------------------
| Login / logout (satu halaman untuk murid & guru piket)
|--------------------------------------------------------------------------
*/
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

/*
|--------------------------------------------------------------------------
| Dashboard siswa (guard: murid)
|--------------------------------------------------------------------------
*/
Route::middleware(EnsureMurid::class)->group(function () {
    Route::get('/dashboard', fn () => redirect()->route('siswa.jadwal'))->name('dashboard');

    Route::get('/siswa/jadwal', [SiswaController::class, 'jadwal'])->name('siswa.jadwal');
    Route::get('/siswa/status', [SiswaController::class, 'status'])->name('siswa.status');
});

/*
|--------------------------------------------------------------------------
| Dashboard guru piket (guard: guru, harus terdaftar di tb_guru_piket)
|--------------------------------------------------------------------------
*/
Route::middleware(EnsureGuruPiket::class)->prefix('piket')->group(function () {
    Route::get('/dashboard', fn () => redirect()->route('piket.status'))->name('piket.dashboard');

    Route::get('/status', [PiketController::class, 'status'])->name('piket.status');
    Route::get('/absen', [PiketController::class, 'absen'])->name('piket.absen');
    Route::post('/absen/simpan', [PiketController::class, 'simpan'])->name('piket.absen.simpan');
    Route::get('/absen/detail', [PiketController::class, 'detail'])->name('piket.absen.detail');
});

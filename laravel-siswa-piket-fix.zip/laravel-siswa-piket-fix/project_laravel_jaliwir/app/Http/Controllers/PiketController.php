<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Dashboard guru piket (guard: guru).
 *
 *   /piket/status        Status Guru hari ini + tombol "Input Absensi"
 *   /piket/absen         Log absensi (daftar tanggal) + form "Mulai Absensi"
 *   /piket/absen/simpan  Simpan absen guru ke tb_absen_guru  (dibaca dashboard siswa)
 *   /piket/absen/detail  Detail absen satu tanggal
 *
 * tb_absen_guru.status:  H = Hadir, selain itu (T / A / I / S) = tidak hadir.
 */
class PiketController extends Controller
{
    private const TZ = 'Asia/Makassar';

    private const HARI = [1 => 'Senin', 2 => 'Selasa', 3 => 'Rabu', 4 => 'Kamis', 5 => 'Jumat', 6 => 'Sabtu', 7 => 'Minggu'];

    private const BULAN = [
        1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April', 5 => 'Mei', 6 => 'Juni',
        7 => 'Juli', 8 => 'Agustus', 9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
    ];

    private const LABEL_STATUS = ['H' => 'Hadir', 'T' => 'Tidak Hadir', 'A' => 'Tidak Hadir', 'I' => 'Izin', 'S' => 'Sakit'];

    /* ================================================================== */
    /*  STATUS GURU (hari ini)                                            */
    /* ================================================================== */

    public function status()
    {
        $now      = Carbon::now(self::TZ);
        $isLibur  = $now->isWeekend();
        $hariDb   = $isLibur ? 'senin' : strtolower(self::HARI[$now->dayOfWeekIso]);   // akhir pekan: pratinjau jadwal Senin
        $menitNow = $now->hour * 60 + $now->minute;

        $guruList = DB::table('tb_guru')
            ->select('kode_guru', 'nama', 'mapel')
            ->orderBy('kode_guru')
            ->get();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $now->toDateString())
            ->orderBy('id')
            ->get()
            ->keyBy('kode_guru');

        $jadwalHariIni = DB::table('tb_mapel_guru')
            ->where('hari', $hariDb)
            ->whereNotNull('kode_guru')
            ->select('kode_guru', 'nama_mapel', 'jam_sekolah', 'kelas', 'jam_mulai', 'jam_selesai')
            ->get()
            ->sortBy(fn ($r) => [$this->menit($r->jam_mulai) ?? 9999, (int) $r->jam_sekolah])
            ->map(fn ($r) => (object) [
                'kode_guru'   => $r->kode_guru,
                'jam_sekolah' => $r->jam_sekolah,
                'waktu'       => $this->jam($r->jam_mulai) . ' - ' . $this->jam($r->jam_selesai),
                'nama_mapel'  => $r->nama_mapel,
                'kelas'       => trim((string) $r->kelas),
                'mulai'       => $this->menit($r->jam_mulai),
                'selesai'     => $this->menit($r->jam_selesai),
            ])
            ->groupBy('kode_guru');

        $dataGuruStatus = $guruList->map(function ($guru) use ($absenDb, $jadwalHariIni, $menitNow, $isLibur) {
            $kode       = trim((string) ($absenDb->get($guru->kode_guru)->status ?? 'H'));   // belum diabsen = hadir
            $jadwalGuru = $jadwalHariIni->get($guru->kode_guru, collect());

            $sedang = null;
            if (!$isLibur) {
                foreach ($jadwalGuru as $j) {
                    if ($j->mulai !== null && $j->selesai !== null && $menitNow >= $j->mulai && $menitNow < $j->selesai) {
                        $sedang = $j->nama_mapel . ' di ' . $j->kelas . ' (' . $j->waktu . ')';
                        break;
                    }
                }
            }
            if (!$sedang) {
                $sedang = $isLibur
                    ? 'Hari libur (tidak ada KBM)'
                    : ($jadwalGuru->isNotEmpty()
                        ? 'Tidak sedang mengajar (Jadwal: ' . $jadwalGuru->count() . ' jam hari ini)'
                        : 'Tidak ada jadwal mengajar hari ini');
            }

            return (object) [
                'kode_guru'       => $guru->kode_guru,
                'nama'            => trim((string) $guru->nama),
                'mapel_utama'     => $guru->mapel,
                'status_absen'    => self::LABEL_STATUS[$kode] ?? 'Tidak Hadir',
                'is_hadir'        => $kode === 'H',
                'status_db'       => $kode,
                'sedang_ngajar'   => $sedang,
                'jadwal_hari_ini' => $jadwalGuru,
            ];
        });

        return view('guru-piket.piket-status', [
            'tanggalHariIni' => $this->label($now),
            'hariDb'         => $hariDb,
            'dataGuruStatus' => $dataGuruStatus,
            'guruList'       => $guruList,
            'absenDb'        => $absenDb,
        ]);
    }

    /* ================================================================== */
    /*  ABSEN GURU                                                        */
    /* ================================================================== */

    /** Log absensi + pop-up form absen */
    public function absen()
    {
        $today = Carbon::now(self::TZ)->toDateString();

        $guruList = DB::table('tb_guru')
            ->select('kode_guru', 'nama')
            ->orderBy('kode_guru')
            ->get();

        $absenHariIni = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $today)
            ->orderBy('id')
            ->get()
            ->keyBy('kode_guru');

        $logAbsensi = DB::table('tb_absen_guru')
            ->select('tanggal')
            ->distinct()
            ->orderByDesc('tanggal')
            ->limit(120)
            ->pluck('tanggal')
            ->map(fn ($t) => substr((string) $t, 0, 10))
            ->unique()
            ->values()
            ->map(fn ($t) => (object) [
                'tanggal'           => $t,
                'tanggal_formatted' => $this->label(Carbon::parse($t, self::TZ)),
            ]);

        return view('guru-piket.piket-absen', [
            'tanggalHariIni' => $this->label(Carbon::now(self::TZ)),
            'guruList'       => $guruList,
            'sudahAbsen'     => $absenHariIni->isNotEmpty(),
            'absenHariIni'   => $absenHariIni,
            'logAbsensi'     => $logAbsensi,
        ]);
    }

    /** Simpan / perbarui absen guru -> tb_absen_guru */
    public function simpan(Request $request): RedirectResponse
    {
        $request->validate([
            'tanggal'     => ['required', 'date_format:Y-m-d'],
            'kehadiran'   => ['required', 'array'],
            'kehadiran.*' => ['in:H,T'],
        ], [
            'tanggal.required'      => 'Tanggal absensi wajib diisi.',
            'tanggal.date_format'   => 'Format tanggal tidak valid.',
            'kehadiran.required'    => 'Data kehadiran guru kosong.',
        ]);

        $tanggal      = $request->input('tanggal');
        $kodeTidak    = $this->kodeTidakHadir();
        $adaUpdatedAt = Schema::hasColumn('tb_absen_guru', 'updated_at');
        $adaCreatedAt = Schema::hasColumn('tb_absen_guru', 'created_at');
        $sekarang     = Carbon::now(self::TZ)->toDateTimeString();

        $kodeValid = DB::table('tb_guru')->pluck('kode_guru')->map(fn ($k) => (string) $k)->all();

        DB::transaction(function () use ($request, $tanggal, $kodeTidak, $adaUpdatedAt, $adaCreatedAt, $sekarang, $kodeValid) {
            foreach ($request->input('kehadiran') as $kodeGuru => $nilai) {
                if (!in_array((string) $kodeGuru, $kodeValid, true)) {
                    continue;
                }

                $ada = DB::table('tb_absen_guru')
                    ->where('kode_guru', $kodeGuru)
                    ->whereDate('tanggal', $tanggal)
                    ->orderByDesc('id')
                    ->first();

                if ($nilai === 'H') {
                    $status = 'H';
                } elseif ($ada && trim((string) $ada->status) !== '' && trim((string) $ada->status) !== 'H') {
                    $status = $ada->status;         // Izin / Sakit / Alpa yang sudah tercatat tidak ditimpa
                } else {
                    $status = $kodeTidak;
                }

                if ($ada) {
                    $ubah = ['status' => $status];
                    if ($adaUpdatedAt) {
                        $ubah['updated_at'] = $sekarang;
                    }
                    DB::table('tb_absen_guru')->where('id', $ada->id)->update($ubah);
                } else {
                    $baru = ['kode_guru' => $kodeGuru, 'tanggal' => $tanggal, 'status' => $status];
                    if ($adaCreatedAt) {
                        $baru['created_at'] = $sekarang;
                    }
                    if ($adaUpdatedAt) {
                        $baru['updated_at'] = $sekarang;
                    }
                    DB::table('tb_absen_guru')->insert($baru);
                }
            }
        });

        return redirect()->route('piket.status')
            ->with('sukses', 'Absensi guru ' . $this->label(Carbon::parse($tanggal, self::TZ)) . ' berhasil disimpan. Dashboard siswa sudah ikut diperbarui.');
    }

    /** Detail absen satu tanggal */
    public function detail(Request $request)
    {
        $q = (string) $request->query('tanggal', '');

        try {
            $tgl = preg_match('/^\d{4}-\d{2}-\d{2}$/', $q)
                ? Carbon::createFromFormat('!Y-m-d', $q, self::TZ)
                : Carbon::now(self::TZ);
        } catch (\Throwable $e) {
            $tgl = Carbon::now(self::TZ);
        }
        $iso = $tgl->toDateString();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $iso)
            ->orderBy('id')
            ->get()
            ->keyBy('kode_guru');

        $absensi = DB::table('tb_guru')
            ->select('kode_guru', 'nama')
            ->orderBy('kode_guru')
            ->get()
            ->map(function ($g) use ($absenDb) {
                $kode = $absenDb->has($g->kode_guru) ? trim((string) $absenDb->get($g->kode_guru)->status) : null;

                return (object) [
                    'nama'   => trim((string) $g->nama),
                    'status' => $kode === null ? 'Belum Diabsen' : (self::LABEL_STATUS[$kode] ?? 'Tidak Hadir'),
                ];
            });

        return view('guru-piket.piket-absen-detail', [
            'tanggal'          => $iso,
            'tanggalFormatted' => $this->label($tgl),
            'absensi'          => $absensi,
        ]);
    }

    /* ================================================================== */

    /**
     * Kode "tidak hadir" yang dipakai kolom status.
     * Dibaca dari definisi ENUM di MySQL supaya aman: 'T' kalau ada, kalau tidak 'A'.
     */
    private function kodeTidakHadir(): string
    {
        try {
            if (DB::getDriverName() === 'mysql') {
                $kolom = DB::selectOne("SHOW COLUMNS FROM `tb_absen_guru` LIKE 'status'");
                $tipe  = (string) ($kolom->Type ?? $kolom->type ?? '');

                if (stripos($tipe, 'enum') === 0 && preg_match_all("/'([^']+)'/", $tipe, $m)) {
                    foreach (['T', 'A'] as $kode) {
                        if (in_array($kode, $m[1], true)) {
                            return $kode;
                        }
                    }
                    foreach ($m[1] as $nilai) {
                        if ($nilai !== 'H') {
                            return $nilai;
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // abaikan, pakai default
        }

        return 'T';
    }

    private function label(Carbon $d): string
    {
        return self::HARI[$d->dayOfWeekIso] . ', ' . $d->day . ' ' . self::BULAN[$d->month] . ' ' . $d->year;
    }

    /** '07.05' / '07:05' -> menit sejak 00:00 (null kalau format tidak dikenali) */
    private function menit(?string $jam): ?int
    {
        if ($jam !== null && preg_match('/^(\d{1,2})[.:](\d{2})/', trim($jam), $m)) {
            return (int) $m[1] * 60 + (int) $m[2];
        }

        return null;
    }

    /** '07.05' -> '07:05' */
    private function jam(?string $jam): string
    {
        return $jam === null ? '' : str_replace('.', ':', trim($jam));
    }
}

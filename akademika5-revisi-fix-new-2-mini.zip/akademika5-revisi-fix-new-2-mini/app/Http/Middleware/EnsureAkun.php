<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Proteksi halaman per jenis akun: akun:admin | akun:guru | akun:murid | akun:admin,guru
 *
 * - Belum login            -> kembali ke halaman login.
 * - Login tetapi beda role -> dikembalikan ke dashboard akunnya sendiri.
 * - Header no-store dipasang supaya tombol Back setelah logout tidak menampilkan halaman lama.
 */
class EnsureAkun
{
    public static function dashboardRoute(?string $jenis): string
    {
        return match ($jenis) {
            'admin' => 'admin.dashboard',
            'guru'  => 'guru.dashboard',
            'murid' => 'siswa.dashboard',
            default => 'login',
        };
    }

    public function handle(Request $request, Closure $next, string ...$roles): Response
    {
        if (!session('sudah_login')) {
            return $this->tanpaCache(redirect()->route('login'));
        }

        $jenis = session('jenis_akun');

        if (!in_array($jenis, $roles, true)) {
            if (!array_key_exists($jenis ?? '', ['admin' => 1, 'guru' => 1, 'murid' => 1])) {
                // Sesi rusak / tidak dikenal: paksa login ulang.
                $request->session()->invalidate();
                $request->session()->regenerateToken();

                return $this->tanpaCache(redirect()->route('login'));
            }

            return $this->tanpaCache(
                redirect()->route(self::dashboardRoute($jenis))
                    ->with('error', 'Anda tidak memiliki akses ke halaman tersebut.')
            );
        }

        return $this->tanpaCache($next($request));
    }

    private function tanpaCache(Response $response): Response
    {
        $response->headers->set('Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate');
        $response->headers->set('Pragma', 'no-cache');
        $response->headers->set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');

        return $response;
    }
}

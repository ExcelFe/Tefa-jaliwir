<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Dipasang pada GET/POST /login. Akun yang sudah login tidak bisa membuka form login
 * atau berganti akun lewat POST /login; harus logout lebih dulu.
 */
class RedirectJikaSudahLogin
{
    public function handle(Request $request, Closure $next): Response
    {
        if (session('sudah_login') && in_array(session('jenis_akun'), ['admin', 'guru', 'murid'], true)) {
            $response = redirect()->route(EnsureAkun::dashboardRoute(session('jenis_akun')))
                ->with('info', 'Anda masih login. Silakan Log Out terlebih dahulu untuk masuk dengan akun lain.');
        } else {
            $response = $next($request);
        }

        $response->headers->set('Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate');
        $response->headers->set('Pragma', 'no-cache');
        $response->headers->set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');

        return $response;
    }
}

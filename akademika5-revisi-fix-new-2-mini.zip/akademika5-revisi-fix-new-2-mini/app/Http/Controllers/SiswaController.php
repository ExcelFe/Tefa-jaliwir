<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\AkunMurid;
use App\Support\GuruFoto;

class SiswaController extends Controller
{
    /** Map nama hari Indonesia */
    private $daftarHari = [
        1 => 'senin',
        2 => 'selasa',
        3 => 'rabu',
        4 => 'kamis',
        5 => 'jumat',
    ];

    /** Ambil model AkunMurid yang sedang login */
    private function getMuridModel(): ?AkunMurid
    {
        // 1. Dari Auth guard murid
        if ($akun = Auth::guard('murid')->user()) {
            return $akun;
        }

        // 2. Dari session email_akun
        if ($email = session('email_akun')) {
            $akun = AkunMurid::where('email', $email)->first();
            if ($akun) {
                Auth::guard('murid')->login($akun);
                session(['nama_murid' => $akun->nama, 'kelas_murid' => $akun->kelas]);
                return $akun;
            }
        }

        // 3. Dari session akun_id
        if ($id = session('akun_id')) {
            $akun = AkunMurid::find($id);
            if ($akun) {
                Auth::guard('murid')->login($akun);
                session(['nama_murid' => $akun->nama, 'kelas_murid' => $akun->kelas]);
                return $akun;
            }
        }

        return null;
    }

    /** Ambil nama murid yang sedang login (Nama Asli dari database, bukan email) */
    private function getNamaMurid(): string
    {
        $murid = $this->getMuridModel();
        if ($murid && !empty($murid->nama)) {
            return strtoupper(trim($murid->nama));
        }

        return strtoupper(session('nama_murid') ?? 'SISWA');
    }

    /** Ambil kelas murid yang sedang login (hanya kelas miliknya) */
    private function getKelasMurid(): string
    {
        $murid = $this->getMuridModel();
        if ($murid && !empty($murid->kelas)) {
            return trim($murid->kelas);
        }

        return session('kelas_murid') ?? 'XI PPLG 1';
    }

    /** Helper jam: '07.05' / '07:05' -> menit sejak 00:00 */
    private function jamKeMenit(?string $jam): ?int
    {
        if ($jam !== null && preg_match('/^(\d{1,2})[.:](\d{2})$/', trim($jam), $m)) {
            return (int) $m[1] * 60 + (int) $m[2];
        }
        return null;
    }

    /** Helper: format DATE ke bahasa Indonesia */
    private function formatTanggalIndo(string $dateStr): string
    {
        return PiketAbsenController::formatTanggalIndo($dateStr);
    }

    /** Helper: gabungkan baris mapel berturut-turut untuk guru & mapel yang sama */
    private function groupJadwal($rows): array
    {
        $grup = [];
        foreach ($rows as $r) {
            $i = count($grup) - 1;
            if ($i >= 0 && $grup[$i]['kode_guru'] === $r->kode_guru && $grup[$i]['mapel'] === $r->nama_mapel) {
                $grup[$i]['jam_akhir'] = $r->jam_sekolah;
                $grup[$i]['selesai']   = $r->jam_selesai;
                continue;
            }
            $grup[] = [
                'kode_guru'       => $r->kode_guru,
                'mapel'           => $r->nama_mapel,
                'guru'            => $r->nama_guru,
                'foto'            => GuruFoto::url($r->kode_guru),
                'jam_awal'        => $r->jam_sekolah,
                'jam_akhir'       => $r->jam_sekolah,
                'jam_ke'          => $r->jam_sekolah,
                'mulai'           => $r->jam_mulai,
                'selesai'         => $r->jam_selesai,
                'waktu'           => trim(($r->jam_mulai ?? '') . ' - ' . ($r->jam_selesai ?? ''), ' -'),
                'waktu_pelajaran' => $r->waktu_pelajaran,
            ];
        }

        // Format label jam_ke & waktu gabungan
        foreach ($grup as $k => $g) {
            $grup[$k]['jam_ke'] = ($g['jam_awal'] === $g['jam_akhir'])
                ? (string) $g['jam_awal']
                : $g['jam_awal'] . ' - ' . $g['jam_akhir'];
            $grup[$k]['waktu'] = trim(($g['mulai'] ?? '') . ' - ' . ($g['selesai'] ?? ''), ' -');
        }

        return $grup;
    }

    /** Halaman Dashboard Siswa (redirect ke jadwal) */
    public function dashboard(Request $request)
    {
        if (!session('sudah_login') || session('jenis_akun') !== 'murid') {
            return redirect()->route('login');
        }

        return redirect()->route('siswa.jadwal');
    }

    /** Halaman Jadwal Siswa */
    public function jadwal(Request $request)
    {
        if (!session('sudah_login') || session('jenis_akun') !== 'murid') {
            return redirect()->route('login');
        }

        $now = Carbon::now('Asia/Makassar');
        $namaHariDefault = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';

        // Siswa hanya melihat jadwal miliknya (kelas milik akunnya sendiri)
        $kelas = $this->getKelasMurid();
        $namaMurid = $this->getNamaMurid();

        // Hari pilihan untuk tab jadwal lengkap
        $hariPilihan = strtolower($request->query('hari', $namaHariDefault));
        if (!in_array($hariPilihan, ['senin', 'selasa', 'rabu', 'kamis', 'jumat'])) {
            $hariPilihan = 'senin';
        }

        // Tanggal dan hari ini
        $hariIni = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';
        $tanggalHariIni = $this->formatTanggalIndo($now->toDateString());
        $todayDate = $now->toDateString();

        // Ambil data absensi guru hari ini dari tb_absen_guru
        $absenGuruDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $todayDate)
            ->get()
            ->keyBy('kode_guru');

        // =========================================================================
        // 1. DATA JADWAL HARI INI (REAL-TIME: UNTUK HERO CARD JADWAL HARI INI)
        // =========================================================================
        $jadwalHariIniRows = DB::table('tb_mapel_murid')
            ->leftJoin('tb_guru', 'tb_mapel_murid.kode_guru', '=', 'tb_guru.kode_guru')
            ->where('tb_mapel_murid.hari', $hariIni)
            ->where('tb_mapel_murid.kelas', $kelas)
            ->select('tb_mapel_murid.*', 'tb_guru.nama as nama_guru')
            ->orderBy('tb_mapel_murid.jam_sekolah')
            ->get();

        $grupHariIni = $this->groupJadwal($jadwalHariIniRows);
        $menitSekarang = $now->hour * 60 + $now->minute;

        $heroJadwal = null;
        $sedangBerlangsungItem = null;
        $berikutnyaItem = null;
        $selesaiTerakhirItem = null;

        foreach ($grupHariIni as $item) {
            $mulai = $this->jamKeMenit($item['mulai']);
            $selesai = $this->jamKeMenit($item['selesai']);

            // Cek kehadiran guru dari tb_absen_guru
            $absen = $absenGuruDb[$item['kode_guru']] ?? null;
            $statusRaw = $absen ? strtoupper($absen->status) : null;
            $statusGuru = match ($statusRaw) {
                'H'      => 'Hadir',
                'I'      => 'Izin',
                'S'      => 'Sakit',
                'A', 'T' => 'Tidak Hadir',
                default  => 'Hadir',
            };

            if ($mulai !== null && $selesai !== null) {
                if ($menitSekarang >= $mulai && $menitSekarang < $selesai) {
                    $sedangBerlangsungItem = (object) array_merge($item, [
                        'status_slug' => 'ongoing',
                        'status_text' => 'Sedang berlangsung',
                        'kicker'      => 'Sedang Berlangsung',
                        'status_guru' => $statusGuru,
                        'is_ongoing'  => true,
                    ]);
                } elseif ($menitSekarang < $mulai) {
                    if ($berikutnyaItem === null) {
                        $berikutnyaItem = (object) array_merge($item, [
                            'status_slug' => 'upcoming',
                            'status_text' => 'Akan datang',
                            'kicker'      => 'Jadwal berikutnya',
                            'status_guru' => $statusGuru,
                            'is_ongoing'  => false,
                        ]);
                    }
                } else {
                    $selesaiTerakhirItem = (object) array_merge($item, [
                        'status_slug' => 'finished',
                        'status_text' => 'Selesai',
                        'kicker'      => 'Pelajaran Selesai',
                        'status_guru' => $statusGuru,
                        'is_ongoing'  => false,
                    ]);
                }
            }
        }

        if ($sedangBerlangsungItem) {
            $heroJadwal = $sedangBerlangsungItem;
        } elseif ($berikutnyaItem) {
            $heroJadwal = $berikutnyaItem;
        } elseif ($selesaiTerakhirItem) {
            $heroJadwal = $selesaiTerakhirItem;
        } elseif (!empty($grupHariIni[0])) {
            $first = $grupHariIni[0];
            $absen = $absenGuruDb[$first['kode_guru']] ?? null;
            $heroJadwal = (object) array_merge($first, [
                'status_slug' => 'upcoming',
                'status_text' => 'Akan datang',
                'kicker'      => 'Jadwal Hari Ini',
                'status_guru' => ($absen && $absen->status === 'A') ? 'Tidak Hadir' : 'Hadir',
                'is_ongoing'  => false,
            ]);
        }

        // =========================================================================
        // 2. DATA JADWAL PER HARI PILIHAN (TABEL / LIST LENGKAP KELAS SISWA)
        // =========================================================================
        $queryPilihan = DB::table('tb_mapel_murid')
            ->leftJoin('tb_guru', 'tb_mapel_murid.kode_guru', '=', 'tb_guru.kode_guru')
            ->where('tb_mapel_murid.hari', $hariPilihan)
            ->where('tb_mapel_murid.kelas', $kelas)
            ->select('tb_mapel_murid.*', 'tb_guru.nama as nama_guru')
            ->orderBy('tb_mapel_murid.jam_sekolah')
            ->get();

        $grupPilihan = $this->groupJadwal($queryPilihan);
        $isHariIni = ($hariIni === $hariPilihan);

        $jadwalList = collect($grupPilihan)->map(function ($g) use ($menitSekarang, $isHariIni) {
            $mulai = $this->jamKeMenit($g['mulai']);
            $selesai = $this->jamKeMenit($g['selesai']);

            $isOngoing = false;
            $statusText = 'Akan Datang';

            if ($isHariIni && $mulai !== null && $selesai !== null) {
                if ($menitSekarang >= $mulai && $menitSekarang < $selesai) {
                    $isOngoing = true;
                    $statusText = 'Sedang Berlangsung';
                } elseif ($menitSekarang >= $selesai) {
                    $statusText = 'Selesai';
                }
            }

            return (object) [
                'kode_guru'   => $g['kode_guru'],
                'mapel'       => $g['mapel'],
                'guru'        => $g['guru'] ?: 'Guru Pengajar',
                'foto'        => $g['foto'] ?? null,
                'waktu'       => $g['waktu'],
                'jam_ke'      => 'Jam ke ' . $g['jam_ke'],
                'is_ongoing'  => $isOngoing,
                'is_finished' => ($statusText === 'Selesai'),
                'status_text' => $statusText,
            ];
        });

        return view('siswa.siswa-jadwal', compact(
            'kelas',
            'namaMurid',
            'hariPilihan',
            'hariIni',
            'tanggalHariIni',
            'heroJadwal',
            'jadwalList'
        ));
    }

    /** API: Get Jadwal Siswa (JSON) */
    public function getJadwalSiswa(Request $request)
    {
        $now = Carbon::now('Asia/Makassar');
        $hariMap = $this->daftarHari;
        $hari = $hariMap[$now->dayOfWeekIso] ?? 'senin';

        if (in_array(strtolower($request->query('hari')), $hariMap, true)) {
            $hari = strtolower($request->query('hari'));
        }

        $kelas = $this->getKelasMurid();
        if (!$hari || !$kelas) {
            return response()->json([]);
        }

        $query = DB::table('tb_mapel_murid')
            ->leftJoin('tb_guru', 'tb_mapel_murid.kode_guru', '=', 'tb_guru.kode_guru')
            ->where('tb_mapel_murid.hari', $hari)
            ->where('tb_mapel_murid.kelas', $kelas)
            ->select('tb_mapel_murid.*', 'tb_guru.nama as nama_guru')
            ->orderBy('tb_mapel_murid.jam_sekolah');

        $rows = $query->get();
        $grup = $this->groupJadwal($rows);

        $menitSekarang = $now->hour * 60 + $now->minute;
        $aktifSet = false;

        $jadwal = [];
        foreach ($grup as $g) {
            $mulai   = $this->jamKeMenit($g['mulai']);
            $selesai = $this->jamKeMenit($g['selesai']);

            if ($mulai !== null && $selesai !== null && $menitSekarang >= $mulai && $menitSekarang < $selesai) {
                $status = 'Sedang Berlangsung';
            } elseif ($selesai !== null && $menitSekarang >= $selesai) {
                $status = 'Selesai';
            } else {
                $status = 'Akan Datang';
            }

            $jadwal[] = [
                'waktu'    => $g['waktu'],
                'jam_ke'   => $g['jam_ke'],
                'mapel'    => $g['mapel'],
                'status'   => $status,
                'pengajar' => $g['guru'] ?: 'Guru Pengajar',
                'foto'     => $g['foto'] ?? '',
                'aktif'    => 0,
            ];
        }

        foreach (['Sedang Berlangsung', 'Akan Datang'] as $cari) {
            foreach ($jadwal as $k => $j) {
                if ($j['status'] === $cari) { $jadwal[$k]['aktif'] = 1; $aktifSet = true; break; }
            }
            if ($aktifSet) break;
        }

        return response()->json($jadwal);
    }

    /** Halaman Status Guru (Siswa view) */
    public function status(Request $request)
    {
        if (!session('sudah_login') || session('jenis_akun') !== 'murid') {
            return redirect()->route('login');
        }

        $today = now('Asia/Makassar')->format('Y-m-d');
        $tanggalPilihan = $request->query('tanggal', $today);

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggalPilihan)) {
            $tanggalPilihan = $today;
        }

        $tanggalFormatted = $this->formatTanggalIndo($tanggalPilihan);
        $namaMurid = $this->getNamaMurid();
        $kelas = $this->getKelasMurid();

        // Ambil semua guru dari database
        $guruList = DB::table('tb_guru')
            ->orderBy('nama')
            ->get();

        // Ambil absensi guru pada tanggal tersebut
        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggalPilihan)
            ->get()
            ->keyBy('kode_guru');

        $isToday = ($tanggalPilihan === Carbon::now('Asia/Makassar')->toDateString());
        if ($absenDb->isEmpty() && !$isToday) {
            $dataGuru = collect();
        } else {
            $dataGuru = $guruList->map(function ($g) use ($absenDb, $tanggalFormatted) {
                $absen = $absenDb[$g->kode_guru] ?? null;
                $statusRaw = $absen ? strtoupper($absen->status) : null;

                $statusText = match ($statusRaw) {
                    'H'      => 'Hadir',
                    'I'      => 'Izin',
                    'S'      => 'Sakit',
                    'A', 'T' => 'Alpa',
                    default  => 'Belum Diabsen',
                };

                $isHadir = ($statusText === 'Hadir');

                return (object) [
                    'kode_guru'        => $g->kode_guru,
                    'nama'             => $g->nama,
                    'mapel'            => $g->mapel ?: '-',
                    'foto'             => GuruFoto::url($g->kode_guru),
                    'status'           => $statusText,
                    'is_hadir'         => $isHadir,
                    'tanggal_formatted'=> $tanggalFormatted,
                ];
            });
        }

        return view('siswa.siswa-status', compact(
            'namaMurid',
            'kelas',
            'tanggalPilihan',
            'tanggalFormatted',
            'dataGuru'
        ));
    }

    /** API: Get Status Guru (JSON) */
    public function getStatusGuru(Request $request)
    {
        $tanggal = $request->query('tanggal');
        if (!is_string($tanggal) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) {
            $tanggal = Carbon::now('Asia/Makassar')->format('Y-m-d');
        }

        $guru = DB::table('tb_absen_guru')
            ->join('tb_guru', 'tb_absen_guru.kode_guru', '=', 'tb_guru.kode_guru')
            ->whereDate('tb_absen_guru.tanggal', $tanggal)
            ->select(
                'tb_absen_guru.id',
                'tb_guru.kode_guru',
                'tb_guru.nama',
                'tb_guru.mapel',
                'tb_absen_guru.status as status_db'
            )
            ->orderByDesc('tb_absen_guru.id')
            ->get()
            ->unique('kode_guru')
            ->sortBy('nama', SORT_NATURAL | SORT_FLAG_CASE)
            ->values()
            ->map(function ($item) {
                $statusUpper = strtoupper($item->status_db);
                $hadir = ($statusUpper === 'H');

                $statusLabel = match ($statusUpper) {
                    'H'      => 'Hadir',
                    'I'      => 'Izin',
                    'S'      => 'Sakit',
                    'A', 'T' => 'Tidak Hadir',
                    default  => 'Hadir',
                };

                return [
                    'nama'        => $item->nama ?: 'Guru',
                    'foto'        => GuruFoto::url($item->kode_guru) ?? '',
                    'mapel'       => !empty($item->mapel) ? $item->mapel : '-',
                    'status'      => $hadir ? 'hadir' : 'tidak',
                    'statusClass' => $hadir ? 'ok' : 'bad',
                    'statusLabel' => $statusLabel,
                ];
            });

        return response()->json($guru);
    }
}

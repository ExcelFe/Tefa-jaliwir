<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class PiketAbsenController extends Controller
{
    /** Helper: cek autentikasi guru piket atau admin */
    private function cekAuth()
    {
        return session('sudah_login') && in_array(session('jenis_akun'), ['guru_piket', 'admin', 'guru']);
    }

    /** Helper: format DATE string (YYYY-MM-DD) ke format Indonesia */
    public static function formatTanggalIndo(string $dateStr): string
    {
        $daftarHari = [
            'Sunday'    => 'Minggu',
            'Monday'    => 'Senin',
            'Tuesday'   => 'Selasa',
            'Wednesday' => 'Rabu',
            'Thursday'  => 'Kamis',
            'Friday'    => 'Jumat',
            'Saturday'  => 'Sabtu',
        ];

        $daftarBulan = [
            1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
        ];

        try {
            $dt = Carbon::parse($dateStr);
            return ($daftarHari[$dt->format('l')] ?? 'Senin')
                . ', ' . $dt->format('j')
                . ' ' . ($daftarBulan[(int) $dt->format('n')] ?? '')
                . ' ' . $dt->format('Y');
        } catch (\Exception $e) {
            return $dateStr;
        }
    }

    /** Helper: terima 'YYYY-MM-DD' yang valid, selain itu null */
    private function tanggalValid($nilai): ?string
    {
        if (!is_string($nilai) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $nilai)) {
            return null;
        }
        try {
            $dt = Carbon::createFromFormat('Y-m-d', $nilai);
            return ($dt && $dt->format('Y-m-d') === $nilai) ? $nilai : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /** Halaman log absensi guru */
    public function index(Request $request)
    {
        if (!$this->cekAuth()) {
            return redirect()->route('login');
        }

        $today = now('Asia/Makassar')->toDateString();

        // Tanggal hari ini format Indonesia
        $tanggalHariIni = self::formatTanggalIndo($today);

        // Daftar semua guru untuk modal absensi
        $guruList = DB::table('tb_guru')
            ->orderBy('nama')
            ->get(['kode_guru', 'nama', 'mapel']);

        // Cek apakah hari ini sudah ada absensi
        $sudahAbsen = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $today)
            ->exists();

        // Absensi hari ini untuk pre-fill modal
        $absenHariIni = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $today)
            ->get()
            ->keyBy('kode_guru');

        // Filter log: rentang tanggal & status (hanya tanggal yang memuat status tsb)
        $filterDari   = $this->tanggalValid($request->query('dari'));
        $filterSampai = $this->tanggalValid($request->query('sampai'));
        if ($filterDari && $filterSampai && $filterDari > $filterSampai) {
            [$filterDari, $filterSampai] = [$filterSampai, $filterDari];
        }
        $filterStatus = strtoupper(trim((string) $request->query('status', '')));
        if (!in_array($filterStatus, ['H', 'I', 'S', 'A'], true)) {
            $filterStatus = '';
        }

        // Log absensi: riwayat absensi guru per tanggal beserta statistik
        $logQuery = DB::table('tb_absen_guru')
            ->select(
                'tanggal',
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->groupBy('tanggal');

        if ($filterDari) {
            $logQuery->where('tanggal', '>=', $filterDari);
        }
        if ($filterSampai) {
            $logQuery->where('tanggal', '<=', $filterSampai);
        }
        if ($filterStatus !== '') {
            $logQuery->havingRaw("SUM(CASE WHEN status = ? THEN 1 ELSE 0 END) > 0", [$filterStatus]);
        }

        $logAbsensi = $logQuery
            ->orderByDesc('tanggal')
            ->get()
            ->map(function ($row) {
                return (object) [
                    'tanggal'           => $row->tanggal,
                    'tanggal_formatted' => self::formatTanggalIndo($row->tanggal),
                    'total'             => (int) $row->total,
                    'hadir'             => (int) $row->hadir,
                    'izin'              => (int) $row->izin,
                    'sakit'             => (int) $row->sakit,
                    'alpa'              => (int) $row->alpa,
                ];
            });

        return view('guru-piket.piket-absen', compact(
            'tanggalHariIni',
            'guruList',
            'sudahAbsen',
            'absenHariIni',
            'logAbsensi',
            'filterDari',
            'filterSampai',
            'filterStatus'
        ));
    }

    /** AJAX: Ambil data absensi guru berdasarkan tanggal untuk keperluan Edit */
    public function getAbsenByTanggal(Request $request)
    {
        if (!$this->cekAuth()) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

        $tanggal = trim($request->query('tanggal', now('Asia/Makassar')->toDateString()));
        $records = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggal)
            ->pluck('status', 'kode_guru');

        return response()->json([
            'tanggal'           => $tanggal,
            'tanggal_formatted' => self::formatTanggalIndo($tanggal),
            'exists'            => $records->isNotEmpty(),
            'absensi'           => $records,
        ]);
    }

    /** Simpan / update absensi guru ke tb_absen_guru */
    public function simpan(Request $request)
    {
        if (!$this->cekAuth()) {
            return redirect()->route('login');
        }

        $kehadiran = $request->input('kehadiran', []);
        $tanggalInput = $request->input('tanggal', now('Asia/Makassar')->toDateString());

        // Parse tanggal ke format YYYY-MM-DD jika belum
        try {
            $tanggal = Carbon::parse($tanggalInput)->format('Y-m-d');
        } catch (\Exception $e) {
            $tanggal = now('Asia/Makassar')->format('Y-m-d');
        }

        foreach ($kehadiran as $kode_guru => $rawStatus) {
            // Status di enum DB tb_absen_guru: enum('H','I','S','A')
            $status = match (strtoupper($rawStatus)) {
                'H', 'HADIR' => 'H',
                'I', 'IZIN'  => 'I',
                'S', 'SAKIT' => 'S',
                'A', 'ALPA'  => 'A',
                default      => 'H',
            };

            DB::table('tb_absen_guru')->updateOrInsert(
                [
                    'kode_guru' => (int) $kode_guru,
                    'tanggal'   => $tanggal,
                ],
                [
                    'status'     => $status,
                    'updated_at' => now('Asia/Makassar'),
                ]
            );
        }

        return redirect()->route('piket.absen')
            ->with('sukses', 'Absensi guru tanggal ' . self::formatTanggalIndo($tanggal) . ' berhasil disimpan!');
    }

    /** Hapus Riwayat Absensi Guru per Tanggal */
    public function hapus(Request $request)
    {
        if (!$this->cekAuth()) {
            return redirect()->route('login');
        }

        $tanggal = trim($request->input('tanggal', ''));

        if (empty($tanggal)) {
            return back()->with('error', 'Parameter tanggal tidak valid.');
        }

        DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggal)
            ->delete();

        return redirect()->route('piket.absen')
            ->with('sukses', 'Data absensi guru pada tanggal ' . self::formatTanggalIndo($tanggal) . ' berhasil dihapus.');
    }

    /** Halaman detail absensi per tanggal */
    public function detail(Request $request)
    {
        if (!$this->cekAuth()) {
            return redirect()->route('login');
        }

        // Ambil query param tanggal (bisa format YYYY-MM-DD atau formatted string)
        $rawTanggal = $request->query('tanggal', now('Asia/Makassar')->toDateString());

        try {
            $dt = Carbon::parse($rawTanggal);
            $tanggalDb = $dt->format('Y-m-d');
            $tanggalFormatted = self::formatTanggalIndo($tanggalDb);
        } catch (\Exception $e) {
            $tanggalDb = now('Asia/Makassar')->format('Y-m-d');
            $tanggalFormatted = $rawTanggal;
        }

        // Absensi pada tanggal tersebut
        $absensiDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggalDb)
            ->get()
            ->keyBy('kode_guru');

        // Jika pada tanggal tersebut TIDAK ADA DATA absensi sama sekali di DB, biarkan kosong (jangan generate data dummy!)
        if ($absensiDb->isEmpty()) {
            $absensi = collect();
            $totalHadir = 0;
            $totalIzin  = 0;
            $totalSakit = 0;
            $totalAlpa  = 0;
        } else {
            // Semua guru dari database
            $guruAll = DB::table('tb_guru')
                ->orderBy('nama')
                ->get(['kode_guru', 'nama', 'mapel'])
                ->keyBy('kode_guru');

            $totalHadir = 0;
            $totalIzin  = 0;
            $totalSakit = 0;
            $totalAlpa  = 0;

            // Tampilkan guru-guru yang tercatat pada tanggal tersebut
            $absensi = $guruAll->map(function ($guru) use ($absensiDb, &$totalHadir, &$totalIzin, &$totalSakit, &$totalAlpa) {
                $record = $absensiDb[$guru->kode_guru] ?? null;
                $statusRaw = $record ? strtoupper($record->status) : null;

                $statusText = match ($statusRaw) {
                    'H'     => 'Hadir',
                    'I'     => 'Izin',
                    'S'     => 'Sakit',
                    'A'     => 'Alpa',
                    default => 'Belum Diabsen',
                };

                match ($statusText) {
                    'Hadir' => $totalHadir++,
                    'Izin'  => $totalIzin++,
                    'Sakit' => $totalSakit++,
                    'Alpa'  => $totalAlpa++,
                    default => null,
                };

                return (object) [
                    'kode_guru' => $guru->kode_guru,
                    'nama'      => $guru->nama,
                    'mapel'     => $guru->mapel ?? '-',
                    'status'    => $statusText,
                    'catatan'   => $record->catatan ?? '-',
                ];
            });
        }

        return view('guru-piket.piket-absen-detail', [
            'tanggal'          => $tanggalDb,
            'tanggalFormatted' => $tanggalFormatted,
            'absensi'          => $absensi,
            'totalHadir'       => $totalHadir,
            'totalIzin'        => $totalIzin,
            'totalSakit'       => $totalSakit,
            'totalAlpa'        => $totalAlpa,
        ]);
    }
}

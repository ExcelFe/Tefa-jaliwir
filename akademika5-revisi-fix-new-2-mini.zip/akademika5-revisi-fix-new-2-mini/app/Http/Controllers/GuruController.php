<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Models\AkunGuru;
use App\Models\Guru;
use App\Models\Jurnal;
use App\Support\TahunAjaran;

class GuruController extends Controller
{
    /** Map nama hari Indonesia */
    private $daftarHari = [
        1 => 'senin',
        2 => 'selasa',
        3 => 'rabu',
        4 => 'kamis',
        5 => 'jumat',
    ];

    /** Ambil data guru yang sedang login */
    private function getGuruData(): array
    {
        $akun = Auth::guard('guru')->user();

        if (!$akun) {
            $email = session('email_akun');
            if ($email) {
                $akun = AkunGuru::where('email', $email)->first();
                if ($akun) {
                    Auth::guard('guru')->login($akun);
                }
            }
        }

        $kodeGuru = $akun ? $akun->kode_guru : session('kode_guru');

        $guruRow = null;
        if ($kodeGuru) {
            $guruRow = DB::table('tb_guru')->where('kode_guru', $kodeGuru)->first();
        }

        $namaGuru = $guruRow ? strtoupper(trim($guruRow->nama)) : strtoupper(session('nama_guru') ?? 'GURU PENGAJAR');
        $mapelGuru = $guruRow ? trim($guruRow->mapel) : (session('mapel_guru') ?? '-');

        return [
            'akun'      => $akun,
            'kode_guru' => $kodeGuru,
            'nama'      => $namaGuru,
            'mapel'     => $mapelGuru,
        ];
    }

    /** Helper: Ambil daftar semua kelas unik dari X, XI, XII */
    private function getAllKelas(): array
    {
        $kelasX = DB::table('tb_murid_x')->distinct()->orderBy('kelas')->pluck('kelas')->toArray();
        $kelasXI = DB::table('tb_murid_xi')->distinct()->orderBy('kelas')->pluck('kelas')->toArray();
        $kelasXII = DB::table('tb_murid_xii')->distinct()->orderBy('kelas')->pluck('kelas')->toArray();

        return array_values(array_unique(array_merge($kelasX, $kelasXI, $kelasXII)));
    }

    /** Helper: format DATE ke bahasa Indonesia */
    private function formatTanggalIndo(string $dateStr): string
    {
        return PiketAbsenController::formatTanggalIndo($dateStr);
    }

    /** Helper: terima 'YYYY-MM-DD' yang valid, selain itu null */
    private function tanggalValid($nilai): ?string
    {
        if (!is_string($nilai) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $nilai)) {
            return null;
        }
        try {
            $dt = Carbon::createFromFormat('Y-m-d', $nilai);
            return ($dt && $dt->format('Y-m-d') === $nilai) ? $nilai : null;
        } catch (\Throwable $e) {
            return null;
        }
    }

    /**
     * Daftar mata pelajaran yang benar-benar diajar guru ini:
     * gabungan nama mapel di jadwal mengajar (tb_mapel_guru) dan mapel di profil guru (tb_guru.mapel).
     */
    private function getMapelGuru($kodeGuru): array
    {
        if (empty($kodeGuru)) {
            return [];
        }

        $daftar = collect(DB::table('tb_mapel_guru')
            ->where('kode_guru', $kodeGuru)
            ->whereNotNull('nama_mapel')
            ->distinct()
            ->pluck('nama_mapel')
            ->all());

        $mapelProfil = DB::table('tb_guru')->where('kode_guru', $kodeGuru)->value('mapel');
        foreach (explode(',', (string) $mapelProfil) as $bagian) {
            $bagian = trim($bagian);
            if ($bagian !== '') {
                $daftar->push($bagian);
            }
        }

        return $daftar
            ->map(fn ($m) => trim((string) $m))
            ->filter()
            ->unique(fn ($m) => mb_strtolower($m))
            ->sort(SORT_NATURAL | SORT_FLAG_CASE)
            ->values()
            ->all();
    }

    /** Helper jam: '07.05' / '07:05' -> menit sejak 00:00 */
    private function jamKeMenit(?string $jam): ?int
    {
        if ($jam !== null && preg_match('/^(\d{1,2})[.:](\d{2})$/', trim($jam), $m)) {
            return (int) $m[1] * 60 + (int) $m[2];
        }
        return null;
    }

    /** Redirect dashboard ke jadwal */
    public function dashboard(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        return redirect()->route('guru.jadwal');
    }

    // =========================================================================
    // 1. JADWAL GURU
    // =========================================================================
    public function jadwal(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];
        $kodeGuru = $guru['kode_guru'];

        $now = Carbon::now('Asia/Makassar');
        $hariIni = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';
        $tanggalHariIni = $this->formatTanggalIndo($now->toDateString());

        $hariPilihan = strtolower($request->query('hari', $hariIni));
        if (!in_array($hariPilihan, ['senin', 'selasa', 'rabu', 'kamis', 'jumat'])) {
            $hariPilihan = 'senin';
        }

        // Ambil jadwal mengajar hari ini untuk hero card real-time
        $jadwalHariIni = DB::table('tb_mapel_guru')
            ->where('kode_guru', $kodeGuru)
            ->where('hari', $hariIni)
            ->get();

        // Sort berdasarkan waktu mulai aktual (bukan sekadar angka jam_sekolah)
        $jadwalHariIni = $jadwalHariIni->sort(function ($a, $b) {
            $mA = $this->jamKeMenit($a->jam_mulai) ?? 9999;
            $mB = $this->jamKeMenit($b->jam_mulai) ?? 9999;
            if ($mA === $mB) {
                return $a->jam_sekolah <=> $b->jam_sekolah;
            }
            return $mA <=> $mB;
        })->values();

        // Gabungkan baris mapel berurutan untuk kelas yang sama
        $grupToday = [];
        foreach ($jadwalHariIni as $r) {
            $last = count($grupToday) - 1;
            if ($last >= 0 && $grupToday[$last]->kelas === $r->kelas && $grupToday[$last]->nama_mapel === $r->nama_mapel) {
                $grupToday[$last]->jam_akhir = $r->jam_sekolah;
                $grupToday[$last]->jam_selesai = $r->jam_selesai;
                continue;
            }
            $grupToday[] = (object) [
                'nama_mapel'  => $r->nama_mapel,
                'kelas'       => $r->kelas,
                'jam_awal'    => $r->jam_sekolah,
                'jam_akhir'   => $r->jam_sekolah,
                'jam_mulai'   => $r->jam_mulai,
                'jam_selesai' => $r->jam_selesai,
            ];
        }

        foreach ($grupToday as $k => $g) {
            $grupToday[$k]->jam_ke = ($g->jam_awal === $g->jam_akhir)
                ? (string) $g->jam_awal
                : $g->jam_awal . ' - ' . $g->jam_akhir;
            $grupToday[$k]->waktu = trim(($g->jam_mulai ?? '') . ' - ' . ($g->jam_selesai ?? ''), ' -');
        }

        // Tentukan hero card: sedang berlangsung atau yang paling dekat jam waktunya dengan jam saat ini
        $menitNow = $now->hour * 60 + $now->minute;
        $ongoingJadwal = null;
        $upcomingJadwal = null;
        $minUpcomingDiff = PHP_INT_MAX;

        foreach ($grupToday as $g) {
            $mulai = $this->jamKeMenit($g->jam_mulai);
            $selesai = $this->jamKeMenit($g->jam_selesai);

            if ($mulai !== null && $selesai !== null) {
                if ($menitNow >= $mulai && $menitNow < $selesai) {
                    $ongoingJadwal = $g;
                    break;
                } elseif ($mulai > $menitNow) {
                    $diff = $mulai - $menitNow;
                    if ($diff < $minUpcomingDiff) {
                        $minUpcomingDiff = $diff;
                        $upcomingJadwal = $g;
                    }
                }
            }
        }

        $heroJadwal = null;
        if ($ongoingJadwal) {
            $heroJadwal = (object) [
                'kicker'      => 'Sedang Mengajar',
                'jam_ke'      => $ongoingJadwal->jam_ke,
                'waktu'       => $ongoingJadwal->waktu,
                'mapel'       => $ongoingJadwal->nama_mapel,
                'kelas'       => $ongoingJadwal->kelas,
                'status_text' => 'Sedang Berlangsung',
                'status_slug' => 'ongoing',
            ];
        } elseif ($upcomingJadwal) {
            $heroJadwal = (object) [
                'kicker'      => 'Jadwal Mengajar Berikutnya',
                'jam_ke'      => $upcomingJadwal->jam_ke,
                'waktu'       => $upcomingJadwal->waktu,
                'mapel'       => $upcomingJadwal->nama_mapel,
                'kelas'       => $upcomingJadwal->kelas,
                'status_text' => 'Akan Datang',
                'status_slug' => 'upcoming',
            ];
        } elseif (!empty($grupToday)) {
            $last = end($grupToday);
            $heroJadwal = (object) [
                'kicker'      => 'Selesai Mengajar',
                'jam_ke'      => $last->jam_ke,
                'waktu'       => $last->waktu,
                'mapel'       => $last->nama_mapel,
                'kelas'       => $last->kelas,
                'status_text' => 'Selesai',
                'status_slug' => 'finished',
            ];
        }

        // Ambil jadwal lengkap sesuai hari terpilih (tab)
        $jadwalTabRows = DB::table('tb_mapel_guru')
            ->where('kode_guru', $kodeGuru)
            ->where('hari', $hariPilihan)
            ->get();

        // Sort hari terpilih berdasarkan waktu jam_mulai aktual
        $jadwalTabRows = $jadwalTabRows->sort(function ($a, $b) {
            $mA = $this->jamKeMenit($a->jam_mulai) ?? 9999;
            $mB = $this->jamKeMenit($b->jam_mulai) ?? 9999;
            if ($mA === $mB) {
                return $a->jam_sekolah <=> $b->jam_sekolah;
            }
            return $mA <=> $mB;
        })->values();

        $jadwalList = collect();
        $grupTab = [];
        foreach ($jadwalTabRows as $r) {
            $last = count($grupTab) - 1;
            if ($last >= 0 && $grupTab[$last]->kelas === $r->kelas && $grupTab[$last]->nama_mapel === $r->nama_mapel) {
                $grupTab[$last]->jam_akhir = $r->jam_sekolah;
                $grupTab[$last]->jam_selesai = $r->jam_selesai;
                continue;
            }
            $grupTab[] = (object) [
                'nama_mapel'  => $r->nama_mapel,
                'kelas'       => $r->kelas,
                'jam_awal'    => $r->jam_sekolah,
                'jam_akhir'   => $r->jam_sekolah,
                'jam_mulai'   => $r->jam_mulai,
                'jam_selesai' => $r->jam_selesai,
            ];
        }

        $isHariIni = ($hariPilihan === $hariIni);
        foreach ($grupTab as $g) {
            $mulai = $this->jamKeMenit($g->jam_mulai);
            $selesai = $this->jamKeMenit($g->jam_selesai);
            $isOngoing = false;
            $isFinished = false;
            if ($isHariIni && $mulai !== null && $selesai !== null) {
                if ($menitNow >= $mulai && $menitNow < $selesai) {
                    $isOngoing = true;
                } elseif ($menitNow >= $selesai) {
                    $isFinished = true;
                }
            }

            $jamLabel = ($g->jam_awal === $g->jam_akhir)
                ? 'Jam ke ' . $g->jam_awal
                : 'Jam ke ' . $g->jam_awal . ' - ' . $g->jam_akhir;

            // Deteksi tingkatan kelas: 10 (Fase E), 11 (Fase F), 12 (Fase F Lanjutan)
            $tingkat = '10';
            $kelasUpper = strtoupper(trim($g->kelas));
            if (str_starts_with($kelasUpper, 'XII ') || $kelasUpper === 'XII' || str_contains($kelasUpper, 'XII')) {
                $tingkat = '12';
            } elseif (str_starts_with($kelasUpper, 'XI ') || $kelasUpper === 'XI' || str_contains($kelasUpper, 'XI')) {
                $tingkat = '11';
            }

            $jadwalList->push((object) [
                'mapel'      => $g->nama_mapel,
                'kelas'      => $g->kelas,
                'tingkat'    => $tingkat,
                'jam_ke'     => $jamLabel,
                'waktu'      => trim(($g->jam_mulai ?? '') . ' - ' . ($g->jam_selesai ?? ''), ' -'),
                'is_ongoing' => $isOngoing,
                'is_finished' => $isFinished,
            ]);
        }

        // Kelompokkan jadwalList berdasarkan tingkat kelas (10, 11, 12)
        $jadwalByTingkat = [
            '10' => $jadwalList->where('tingkat', '10')->values(),
            '11' => $jadwalList->where('tingkat', '11')->values(),
            '12' => $jadwalList->where('tingkat', '12')->values(),
        ];

        // Deteksi apakah guru ini bertugas sebagai Guru Piket hari ini (baik jadwal tetap maupun pengganti)
        $notifPiket = null;
        $isPiketTetap = DB::table('tb_guru_piket')
            ->where('kode_guru', $kodeGuru)
            ->where('hari', $hariIni)
            ->first();

        $isPiketPengganti = DB::table('tb_piket_pengganti')
            ->where('kode_guru', $kodeGuru)
            ->whereDate('tanggal', $now->toDateString())
            ->first();

        if ($isPiketPengganti) {
            $notifPiket = (object) [
                'tipe'        => 'pengganti',
                'judul'       => 'Tugas Guru Piket Pengganti',
                'pesan'       => 'Anda telah ditugaskan oleh Admin sebagai Guru Piket Pengganti untuk hari ini (' . ucfirst($hariIni) . ', ' . $tanggalHariIni . ').',
                'keterangan'  => $isPiketPengganti->keterangan ?? 'Akses aktif sementara hari ini.',
                'link'        => route('piket.dashboard'),
            ];
        } elseif ($isPiketTetap) {
            $notifPiket = (object) [
                'tipe'        => 'tetap',
                'judul'       => 'Jadwal Tugas Guru Piket',
                'pesan'       => 'Hari ini (' . ucfirst($hariIni) . ') Anda terjadwal bertugas sebagai Guru Piket shift ' . $isPiketTetap->waktu . '.',
                'keterangan'  => 'Silakan masuk ke halaman Guru Piket untuk memproses presensi dan kontrol piket.',
                'link'        => route('piket.dashboard'),
            ];
        }

        return view('guru.guru-jadwal', compact(
            'namaGuru',
            'mapelGuru',
            'tanggalHariIni',
            'hariIni',
            'hariPilihan',
            'heroJadwal',
            'jadwalList',
            'jadwalByTingkat',
            'notifPiket'
        ));
    }

    // =========================================================================
    // 2. ABSEN SISWA (CRUD)
    // =========================================================================
    public function absen(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];

        $daftarKelas = $this->getAllKelas();

        // Ambil riwayat log absensi gabungan dari tb_absen_murid_x, xi, xii
        $logsX = DB::table('tb_absen_murid_x')
            ->join('tb_murid_x', 'tb_absen_murid_x.nis_x', '=', 'tb_murid_x.nis_x')
            ->select(
                'tb_murid_x.kelas',
                'tb_absen_murid_x.tanggal',
                DB::raw("'X' as tingkat"),
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_x.status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->groupBy('tb_murid_x.kelas', 'tb_absen_murid_x.tanggal');

        $logsXI = DB::table('tb_absen_murid_xi')
            ->join('tb_murid_xi', 'tb_absen_murid_xi.nis_xi', '=', 'tb_murid_xi.nis_xi')
            ->select(
                'tb_murid_xi.kelas',
                'tb_absen_murid_xi.tanggal',
                DB::raw("'XI' as tingkat"),
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xi.status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->groupBy('tb_murid_xi.kelas', 'tb_absen_murid_xi.tanggal');

        $logsXII = DB::table('tb_absen_murid_xii')
            ->join('tb_murid_xii', 'tb_absen_murid_xii.nis_xii', '=', 'tb_murid_xii.nis_xii')
            ->select(
                'tb_murid_xii.kelas',
                'tb_absen_murid_xii.tanggal',
                DB::raw("'XII' as tingkat"),
                DB::raw("COUNT(*) as total"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN tb_absen_murid_xii.status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->groupBy('tb_murid_xii.kelas', 'tb_absen_murid_xii.tanggal');

        $search = trim($request->query('q', ''));

        // Filter log: kelas, rentang tanggal (dari - sampai)
        $filterKelas  = trim((string) $request->query('kelas', ''));
        $filterDari   = $this->tanggalValid($request->query('dari'));
        $filterSampai = $this->tanggalValid($request->query('sampai'));
        if ($filterDari && $filterSampai && $filterDari > $filterSampai) {
            [$filterDari, $filterSampai] = [$filterSampai, $filterDari];
        }

        $allLogs = $logsX->unionAll($logsXI)->unionAll($logsXII)->get();

        if (!empty($search)) {
            $allLogs = $allLogs->filter(function ($item) use ($search) {
                return str_contains(strtolower($item->kelas), strtolower($search)) ||
                       str_contains($item->tanggal, $search);
            });
        }
        if ($filterKelas !== '') {
            $allLogs = $allLogs->filter(fn ($item) => $item->kelas === $filterKelas);
        }
        if ($filterDari) {
            $allLogs = $allLogs->filter(fn ($item) => substr((string) $item->tanggal, 0, 10) >= $filterDari);
        }
        if ($filterSampai) {
            $allLogs = $allLogs->filter(fn ($item) => substr((string) $item->tanggal, 0, 10) <= $filterSampai);
        }

        $allLogs = $allLogs->sortByDesc('tanggal')->values()->map(function ($item) {
            $item->tanggal_formatted = $this->formatTanggalIndo($item->tanggal);
            return $item;
        });

        return view('guru.guru-absen', compact(
            'namaGuru',
            'mapelGuru',
            'allLogs',
            'daftarKelas',
            'search',
            'filterKelas',
            'filterDari',
            'filterSampai'
        ));
    }

    /** AJAX: Ambil daftar siswa per kelas beserta absensi pada tanggal tersebut */
    public function getSiswaByKelas(Request $request)
    {
        $kelas = trim($request->query('kelas', ''));
        $tanggal = trim($request->query('tanggal', Carbon::now('Asia/Makassar')->toDateString()));

        if (empty($kelas)) {
            return response()->json(['error' => 'Kelas harus dipilih'], 400);
        }

        // Deteksi tingkat kelas
        $tingkat = 'X';
        if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
            $tingkat = 'XI';
        }

        $tabelMurid = match ($tingkat) {
            'XI'  => 'tb_murid_xi',
            'XII' => 'tb_murid_xii',
            default => 'tb_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };
        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };

        $muridList = DB::table($tabelMurid)
            ->where('kelas', $kelas)
            ->orderBy('absen')
            ->orderBy('nama')
            ->get();

        $absenMap = DB::table($tabelAbsen)
            ->where('tanggal', $tanggal)
            ->get()
            ->keyBy($nisCol);

        $result = $muridList->map(function ($m) use ($nisCol, $absenMap) {
            $nisVal = $m->$nisCol;
            $absenItem = $absenMap[$nisVal] ?? null;

            return [
                'nis'     => $nisVal,
                'absen'   => $m->absen ?? '-',
                'nama'    => $m->nama,
                'status'  => $absenItem ? strtoupper($absenItem->status) : 'H',
                'catatan' => $absenItem ? ($absenItem->catatan ?? '') : '',
            ];
        });

        return response()->json([
            'kelas'   => $kelas,
            'tingkat' => $tingkat,
            'tanggal' => $tanggal,
            'siswa'   => $result,
        ]);
    }

    /** Simpan Absensi Siswa */
    public function simpanAbsen(Request $request)
    {
        $request->validate([
            'kelas'     => 'required|string',
            'tanggal'   => 'required|date',
            'kehadiran' => 'required|array',
        ]);

        $kelas = trim($request->input('kelas'));
        $tanggal = $request->input('tanggal');
        $kehadiran = $request->input('kehadiran'); // [nis => status]
        $catatan = $request->input('catatan', []);

        $tingkat = 'X';
        if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
            $tingkat = 'XI';
        }

        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };

        $now = now();
        foreach ($kehadiran as $nis => $rawStatus) {
            $statusUpper = strtoupper($rawStatus);
            $statusVal = match ($statusUpper) {
                'HADIR', 'H' => 'H',
                'SAKIT', 'S' => 'S',
                'IZIN', 'I'  => 'I',
                default      => 'A',
            };
            $catatanVal = $catatan[$nis] ?? null;

            DB::table($tabelAbsen)->updateOrInsert(
                [
                    $nisCol   => $nis,
                    'tanggal' => $tanggal,
                ],
                [
                    'status'     => $statusVal,
                    'catatan'    => $catatanVal,
                    'updated_at' => $now,
                ]
            );
        }

        return redirect()->route('guru.absen')->with('success', "Absensi kelas {$kelas} tanggal {$tanggal} berhasil disimpan.");
    }

    /** Hapus Riwayat Absensi Kelas per Tanggal */
    public function hapusAbsen(Request $request)
    {
        $kelas = trim($request->input('kelas', ''));
        $tanggal = trim($request->input('tanggal', ''));

        if (empty($kelas) || empty($tanggal)) {
            return back()->with('error', 'Parameter kelas atau tanggal tidak valid.');
        }

        $tingkat = 'X';
        if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
            $tingkat = 'XI';
        }

        $tabelMurid = match ($tingkat) {
            'XI'  => 'tb_murid_xi',
            'XII' => 'tb_murid_xii',
            default => 'tb_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };
        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };

        $nisList = DB::table($tabelMurid)->where('kelas', $kelas)->pluck($nisCol);

        DB::table($tabelAbsen)
            ->where('tanggal', $tanggal)
            ->whereIn($nisCol, $nisList)
            ->delete();

        return redirect()->route('guru.absen')->with('success', "Data absensi kelas {$kelas} pada {$tanggal} berhasil dihapus.");
    }

    // =========================================================================
    // 3. JURNAL KELAS (CRUD)
    // =========================================================================
    public function jurnal(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];
        $kodeGuru = $guru['kode_guru'];

        $daftarKelas = $this->getAllKelas();

        $search = trim($request->query('q', ''));

        $query = DB::table('tb_jurnal')
            ->where('kode_guru', $kodeGuru)
            ->orderByDesc('tanggal')
            ->orderByDesc('jam_sekolah');

        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('kelas', 'like', "%{$search}%")
                  ->orWhere('nama_mapel', 'like', "%{$search}%")
                  ->orWhere('sub_kompetensi', 'like', "%{$search}%")
                  ->orWhere('keterangan', 'like', "%{$search}%");
            });
        }

        $jurnals = $query->get()->map(function ($jurnal) {
            $jurnal->tanggal_formatted = $this->formatTanggalIndo($jurnal->tanggal);
            return $jurnal;
        });

        // Dropdown mapel hanya berisi pelajaran yang diajar guru yang login
        $daftarMapel = $this->getMapelGuru($kodeGuru);

        return view('guru.guru-jurnal', compact(
            'namaGuru',
            'mapelGuru',
            'jurnals',
            'daftarKelas',
            'daftarMapel',
            'search'
        ));
    }

    /** Simpan / Update Jurnal */
    public function simpanJurnal(Request $request)
    {
        $guru = $this->getGuruData();
        $kodeGuru = $guru['kode_guru'];

        $request->validate([
            'id'             => 'nullable|integer',
            'tanggal'        => 'required|date',
            'jam_sekolah'    => 'required|integer|min:1|max:15', // 1 angka input sesuai instruksi user
            'kelas'          => 'required|string',
            'nama_mapel'     => 'required|string',
            'pertemuan'      => 'required|integer|min:1',
            'sub_kompetensi' => 'required|string',
            'keterangan'     => 'nullable|string',
        ]);

        // Mapel harus termasuk pelajaran yang diajar guru ini (mapel lama pada jurnal yang sedang diedit tetap diizinkan)
        $mapelInput = trim((string) $request->input('nama_mapel'));
        $mapelBoleh = array_map('mb_strtolower', $this->getMapelGuru($kodeGuru));
        $mapelBolehEdit = false;
        if ($idEdit = $request->input('id')) {
            $mapelLama = DB::table('tb_jurnal')->where('id', $idEdit)->where('kode_guru', $kodeGuru)->value('nama_mapel');
            $mapelBolehEdit = $mapelLama !== null && mb_strtolower($mapelLama) === mb_strtolower($mapelInput);
        }
        if (!in_array(mb_strtolower($mapelInput), $mapelBoleh, true) && !$mapelBolehEdit) {
            return redirect()->route('guru.jurnal')->with('error', 'Mata pelajaran tidak sesuai dengan pelajaran yang Anda ajar.');
        }

        $data = [
            'kode_guru'      => $kodeGuru,
            'kelas'          => $request->input('kelas'),
            'tanggal'        => $request->input('tanggal'),
            'jam_sekolah'    => (int) $request->input('jam_sekolah'),
            'nama_mapel'     => $request->input('nama_mapel'),
            'sub_kompetensi' => $request->input('sub_kompetensi'),
            'pertemuan'      => (int) $request->input('pertemuan'),
            'keterangan'     => $request->input('keterangan') ?? 'berjalan normal',
        ];

        if ($id = $request->input('id')) {
            DB::table('tb_jurnal')->where('id', $id)->where('kode_guru', $kodeGuru)->update($data);
            $msg = 'Jurnal kelas berhasil diperbarui.';
        } else {
            DB::table('tb_jurnal')->insert($data);
            $msg = 'Jurnal kelas berhasil ditambahkan.';
        }

        return redirect()->route('guru.jurnal')->with('success', $msg);
    }

    /** Hapus Jurnal */
    public function hapusJurnal($id)
    {
        $guru = $this->getGuruData();
        $kodeGuru = $guru['kode_guru'];

        DB::table('tb_jurnal')->where('id', $id)->where('kode_guru', $kodeGuru)->delete();

        return redirect()->route('guru.jurnal')->with('success', 'Jurnal kelas berhasil dihapus.');
    }

    // =========================================================================
    // HELPER REKAP / EXPORT
    // =========================================================================

    /** Peta tingkat kelas -> nama tabel/kolom */
    private function petaTingkat(string $kelas): array
    {
        $tingkat = 'X';
        if (str_starts_with($kelas, 'XII ') || $kelas === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelas, 'XI ') || $kelas === 'XI') {
            $tingkat = 'XI';
        }

        return match ($tingkat) {
            'XI'  => ['tingkat' => 'XI',  'murid' => 'tb_murid_xi',  'nis' => 'nis_xi',  'absen' => 'tb_absen_murid_xi'],
            'XII' => ['tingkat' => 'XII', 'murid' => 'tb_murid_xii', 'nis' => 'nis_xii', 'absen' => 'tb_absen_murid_xii'],
            default => ['tingkat' => 'X',  'murid' => 'tb_murid_x',   'nis' => 'nis_x',   'absen' => 'tb_absen_murid_x'],
        };
    }

    /** Tahun ajaran terpilih dari ?ta= (default: tahun ajaran berjalan) */
    private function konteksTahunAjaran(Request $request, ?string $tanggalTerawal): array
    {
        $now = Carbon::now('Asia/Makassar');
        $mulai = TahunAjaran::dariInput($request->query('ta'), $now);
        [$awal, $akhir] = TahunAjaran::rentang($mulai);

        return [
            'ta_mulai'  => $mulai,
            'ta_label'  => TahunAjaran::label($mulai),
            'ta_awal'   => $awal,
            'ta_akhir'  => $akhir,
            'ta_daftar' => TahunAjaran::daftar($tanggalTerawal, $now),
        ];
    }

    /** Tanggal absensi siswa paling awal (untuk daftar tahun ajaran) */
    private function tanggalAbsenSiswaTerawal(): ?string
    {
        $kandidat = array_filter([
            DB::table('tb_absen_murid_x')->min('tanggal'),
            DB::table('tb_absen_murid_xi')->min('tanggal'),
            DB::table('tb_absen_murid_xii')->min('tanggal'),
        ]);

        return $kandidat ? min($kandidat) : null;
    }

    /** Label tahun ajaran untuk rentang tanggal (bisa lintas tahun ajaran) */
    private function labelTahunAjaranRentang(string $dari, string $sampai): string
    {
        $a = TahunAjaran::label(TahunAjaran::tahunMulai(Carbon::parse($dari)));
        $b = TahunAjaran::label(TahunAjaran::tahunMulai(Carbon::parse($sampai)));

        return $a === $b ? $a : $a . ' s.d. ' . $b;
    }

    /** Bungkus isi tabel menjadi file .xls (HTML spreadsheet) */
    private function responsExcel(string $filename, string $title, array $metaBaris, string $isi)
    {
        $html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
        $html .= '<head><meta charset="utf-8">';
        $html .= '<style>
            table { border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; }
            th { background-color: #1e3a8a; color: #ffffff; border: 1px solid #94a3b8; padding: 8px 12px; font-weight: bold; }
            td { border: 1px solid #cbd5e1; padding: 6px 10px; }
            .center { text-align: center; }
            .left { text-align: left; }
            .hadir { background-color: #dcfce7; color: #15803d; font-weight: bold; }
            .sakit { background-color: #dbeafe; color: #1d4ed8; font-weight: bold; }
            .izin { background-color: #fef3c7; color: #b45309; font-weight: bold; }
            .alpa { background-color: #fee2e2; color: #b91c1c; font-weight: bold; }
            .title { font-size: 16pt; font-weight: bold; text-align: center; margin-bottom: 4px; }
            .meta { font-size: 10pt; color: #475569; text-align: center; margin-bottom: 4px; }
        </style>';
        $html .= '</head><body>';
        $html .= '<div class="title">' . htmlspecialchars($title) . '</div>';
        foreach ($metaBaris as $baris) {
            $html .= '<div class="meta">' . htmlspecialchars($baris) . '</div>';
        }
        $html .= '<br>' . $isi . '</body></html>';

        return response($html, 200, [
            'Content-Type'        => 'application/vnd.ms-excel; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
            'Cache-Control'       => 'max-age=0',
        ]);
    }

    // =========================================================================
    // 4. REKAP ABSENSI SISWA & EXPORT SPREADSHEET (EXCEL)
    // =========================================================================
    public function rekap(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];

        $daftarKelas = $this->getAllKelas();
        $search = trim($request->query('q', ''));

        $ta = $this->konteksTahunAjaran($request, $this->tanggalAbsenSiswaTerawal());

        // Hitung rekapan per kelas (hanya pada tahun ajaran terpilih)
        $rekapPerKelas = [];
        foreach ($daftarKelas as $kelas) {
            if (!empty($search) && !str_contains(strtolower($kelas), strtolower($search))) {
                continue;
            }

            $t = $this->petaTingkat($kelas);
            $tabelMurid = $t['murid'];
            $nisCol = $t['nis'];
            $tabelAbsen = $t['absen'];

            $totalSiswa = DB::table($tabelMurid)->where('kelas', $kelas)->count();

            $absenStats = DB::table($tabelAbsen)
                ->join($tabelMurid, "{$tabelAbsen}.{$nisCol}", '=', "{$tabelMurid}.{$nisCol}")
                ->where("{$tabelMurid}.kelas", $kelas)
                ->whereBetween("{$tabelAbsen}.tanggal", [$ta['ta_awal'], $ta['ta_akhir']])
                ->select(
                    DB::raw("COUNT(DISTINCT {$tabelAbsen}.tanggal) as total_hari"),
                    DB::raw("COUNT(*) as total_record"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'H' THEN 1 ELSE 0 END) as hadir"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'S' THEN 1 ELSE 0 END) as sakit"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'I' THEN 1 ELSE 0 END) as izin"),
                    DB::raw("SUM(CASE WHEN {$tabelAbsen}.status = 'A' THEN 1 ELSE 0 END) as alpa")
                )
                ->first();

            $totalHadir = $absenStats ? (int) $absenStats->hadir : 0;
            $totalRecord = $absenStats ? (int) $absenStats->total_record : 0;
            $persen = $totalRecord > 0 ? round(($totalHadir / $totalRecord) * 100, 1) : null;

            $rekapPerKelas[] = (object) [
                'kelas'       => $kelas,
                'tingkat'     => $t['tingkat'],
                'total_siswa' => $totalSiswa,
                'total_hari'  => $absenStats ? (int) $absenStats->total_hari : 0,
                'hadir'       => $totalHadir,
                'sakit'       => $absenStats ? (int) $absenStats->sakit : 0,
                'izin'        => $absenStats ? (int) $absenStats->izin : 0,
                'alpa'        => $absenStats ? (int) $absenStats->alpa : 0,
                'persen'      => $persen,
            ];
        }

        return view('guru.guru-rekap', array_merge($ta, compact(
            'namaGuru',
            'mapelGuru',
            'rekapPerKelas',
            'search'
        )));
    }

    /** Export Rekap Absensi Siswa ke File Spreadsheet / Excel */
    public function exportRekap(Request $request, $kelas = null)
    {
        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];

        $semuaKelas = $this->getAllKelas();
        $ta = $this->konteksTahunAjaran($request, null);
        $labelTa = str_replace('/', '-', $ta['ta_label']);

        if ($kelas === 'all' || empty($kelas)) {
            $targetKelas = $semuaKelas;
            $filename = 'Rekap_Absensi_Semua_Kelas_TA' . $labelTa . '_' . date('Ymd_His') . '.xls';
            $title = 'REKAPITULASI ABSENSI SEMUA KELAS';
        } else {
            if (!in_array($kelas, $semuaKelas, true)) {
                abort(404);
            }
            $targetKelas = [$kelas];
            $safeKelas = preg_replace('/[^A-Za-z0-9_-]/', '_', $kelas);
            $filename = 'Rekap_Absensi_' . $safeKelas . '_TA' . $labelTa . '_' . date('Ymd_His') . '.xls';
            $title = 'REKAPITULASI ABSENSI KELAS ' . strtoupper($kelas);
        }

        $meta = [
            'SMK TI Bali Global Badung',
            'Tahun Ajaran: ' . $ta['ta_label'] . ' (Periode data: ' . $this->formatTanggalIndo($ta['ta_awal']) . ' - ' . $this->formatTanggalIndo($ta['ta_akhir']) . ')',
            'Diunduh oleh: ' . $namaGuru . ' | Tanggal unduh: ' . date('d/m/Y H:i') . ' WITA',
        ];

        $isi = '';
        foreach ($targetKelas as $currentKelas) {
            $t = $this->petaTingkat($currentKelas);
            $tabelMurid = $t['murid'];
            $nisCol = $t['nis'];
            $tabelAbsen = $t['absen'];

            $students = DB::table($tabelMurid)
                ->where('kelas', $currentKelas)
                ->orderBy('absen')
                ->orderBy('nama')
                ->get();

            // Satu query agregat per kelas (bukan satu query per siswa)
            $statistik = DB::table($tabelAbsen)
                ->whereIn($nisCol, $students->pluck($nisCol)->all())
                ->whereBetween('tanggal', [$ta['ta_awal'], $ta['ta_akhir']])
                ->select(
                    $nisCol,
                    DB::raw("COUNT(*) as total"),
                    DB::raw("SUM(CASE WHEN status = 'H' THEN 1 ELSE 0 END) as h"),
                    DB::raw("SUM(CASE WHEN status = 'S' THEN 1 ELSE 0 END) as s"),
                    DB::raw("SUM(CASE WHEN status = 'I' THEN 1 ELSE 0 END) as i"),
                    DB::raw("SUM(CASE WHEN status = 'A' THEN 1 ELSE 0 END) as a")
                )
                ->groupBy($nisCol)
                ->get()
                ->keyBy($nisCol);

            $isi .= '<h3 style="margin-top: 20px; color: #1e3a8a;">Kelas: ' . htmlspecialchars($currentKelas) . ' &mdash; Tahun Ajaran ' . htmlspecialchars($ta['ta_label']) . '</h3>';
            $isi .= '<table><thead><tr>
                <th class="center" style="width: 40px;">No.</th>
                <th class="center" style="width: 90px;">NIS</th>
                <th class="left" style="width: 250px;">Nama Siswa</th>
                <th class="center" style="width: 90px;">L/P</th>
                <th class="center" style="width: 80px;">Hadir (H)</th>
                <th class="center" style="width: 80px;">Sakit (S)</th>
                <th class="center" style="width: 80px;">Izin (I)</th>
                <th class="center" style="width: 80px;">Alpa (A)</th>
                <th class="center" style="width: 100px;">Total Hari</th>
                <th class="center" style="width: 100px;">Kehadiran (%)</th>
            </tr></thead><tbody>';

            $no = 1;
            foreach ($students as $st) {
                $nisVal = $st->$nisCol;
                $stat = $statistik[$nisVal] ?? null;

                $h = $stat ? (int) $stat->h : 0;
                $sk = $stat ? (int) $stat->s : 0;
                $iz = $stat ? (int) $stat->i : 0;
                $a = $stat ? (int) $stat->a : 0;
                $total = $stat ? (int) $stat->total : 0;
                $pct = $total > 0 ? round(($h / $total) * 100, 1) . '%' : '-';

                $isi .= '<tr>';
                $isi .= '<td class="center">' . $no++ . '</td>';
                $isi .= '<td class="center" style="mso-number-format:\'@\';">' . htmlspecialchars((string) $nisVal) . '</td>';
                $isi .= '<td class="left">' . htmlspecialchars($st->nama) . '</td>';
                $isi .= '<td class="center">' . htmlspecialchars((string) ($st->kelamin ?? '-')) . '</td>';
                $isi .= '<td class="center hadir">' . $h . '</td>';
                $isi .= '<td class="center sakit">' . $sk . '</td>';
                $isi .= '<td class="center izin">' . $iz . '</td>';
                $isi .= '<td class="center alpa">' . $a . '</td>';
                $isi .= '<td class="center">' . $total . '</td>';
                $isi .= '<td class="center" style="font-weight: bold;">' . $pct . '</td>';
                $isi .= '</tr>';
            }

            $isi .= '</tbody></table>';
        }

        return $this->responsExcel($filename, $title, $meta, $isi);
    }

    // =========================================================================
    // 5. REKAP JURNAL MENGAJAR (milik guru yang login)
    // =========================================================================

    /** Query dasar jurnal milik guru + filter (dipakai halaman & export) */
    private function queryJurnalGuru($kodeGuru, array $ta, string $kelas, string $mapel)
    {
        $query = DB::table('tb_jurnal')
            ->where('kode_guru', $kodeGuru)
            ->whereBetween('tanggal', [$ta['ta_awal'], $ta['ta_akhir']]);

        if ($kelas !== '') {
            $query->where('kelas', $kelas);
        }
        if ($mapel !== '') {
            $query->where('nama_mapel', $mapel);
        }

        return $query;
    }

    public function rekapJurnal(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];
        $kodeGuru = $guru['kode_guru'];

        $terawal = DB::table('tb_jurnal')->where('kode_guru', $kodeGuru)->min('tanggal');
        $ta = $this->konteksTahunAjaran($request, $terawal);

        $filterKelas = trim((string) $request->query('kelas', ''));
        $filterMapel = trim((string) $request->query('mapel', ''));

        // Pilihan filter hanya dari jurnal yang pernah diisi guru ini
        $daftarKelasJurnal = DB::table('tb_jurnal')->where('kode_guru', $kodeGuru)->distinct()->orderBy('kelas')->pluck('kelas')->all();
        $daftarMapelJurnal = DB::table('tb_jurnal')->where('kode_guru', $kodeGuru)->distinct()->orderBy('nama_mapel')->pluck('nama_mapel')->all();

        // Rekap per kelas + mapel
        $rekapJurnal = $this->queryJurnalGuru($kodeGuru, $ta, $filterKelas, $filterMapel)
            ->select(
                'kelas',
                'nama_mapel',
                DB::raw('COUNT(*) as total_jurnal'),
                DB::raw('MAX(pertemuan) as pertemuan_terakhir'),
                DB::raw('MIN(tanggal) as pertama'),
                DB::raw('MAX(tanggal) as terakhir')
            )
            ->groupBy('kelas', 'nama_mapel')
            ->orderBy('kelas')
            ->orderBy('nama_mapel')
            ->get()
            ->map(function ($r) {
                $r->terakhir_formatted = $this->formatTanggalIndo($r->terakhir);
                return $r;
            });

        // Detail jurnal (terbaru di atas)
        $detailJurnal = $this->queryJurnalGuru($kodeGuru, $ta, $filterKelas, $filterMapel)
            ->orderByDesc('tanggal')
            ->orderByDesc('jam_sekolah')
            ->get()
            ->map(function ($j) {
                $j->tanggal_formatted = $this->formatTanggalIndo($j->tanggal);
                return $j;
            });

        $totalJurnal = $detailJurnal->count();
        $totalKelas = $detailJurnal->pluck('kelas')->unique()->count();
        $totalHariMengajar = $detailJurnal->pluck('tanggal')->unique()->count();

        return view('guru.guru-rekap-jurnal', array_merge($ta, compact(
            'namaGuru',
            'mapelGuru',
            'rekapJurnal',
            'detailJurnal',
            'daftarKelasJurnal',
            'daftarMapelJurnal',
            'filterKelas',
            'filterMapel',
            'totalJurnal',
            'totalKelas',
            'totalHariMengajar'
        )));
    }

    public function exportRekapJurnal(Request $request)
    {
        $guru = $this->getGuruData();
        $kodeGuru = $guru['kode_guru'];
        $namaGuru = $guru['nama'];

        $ta = $this->konteksTahunAjaran($request, null);
        $filterKelas = trim((string) $request->query('kelas', ''));
        $filterMapel = trim((string) $request->query('mapel', ''));

        $rows = $this->queryJurnalGuru($kodeGuru, $ta, $filterKelas, $filterMapel)
            ->orderBy('tanggal')
            ->orderBy('jam_sekolah')
            ->get();

        $meta = [
            'SMK TI Bali Global Badung',
            'Tahun Ajaran: ' . $ta['ta_label'] . ' (Periode data: ' . $this->formatTanggalIndo($ta['ta_awal']) . ' - ' . $this->formatTanggalIndo($ta['ta_akhir']) . ')',
            'Guru: ' . $namaGuru . ($filterKelas !== '' ? ' | Kelas: ' . $filterKelas : '') . ($filterMapel !== '' ? ' | Mapel: ' . $filterMapel : ''),
            'Tanggal unduh: ' . date('d/m/Y H:i') . ' WITA',
        ];

        $isi = '<table><thead><tr>
            <th class="center" style="width: 40px;">No.</th>
            <th class="center" style="width: 160px;">Tanggal</th>
            <th class="center" style="width: 90px;">Kelas</th>
            <th class="center" style="width: 70px;">Jam Ke</th>
            <th class="left" style="width: 220px;">Mata Pelajaran</th>
            <th class="center" style="width: 90px;">Pertemuan</th>
            <th class="left" style="width: 320px;">Sub Kompetensi</th>
            <th class="left" style="width: 220px;">Keterangan</th>
        </tr></thead><tbody>';

        $no = 1;
        foreach ($rows as $r) {
            $isi .= '<tr>';
            $isi .= '<td class="center">' . $no++ . '</td>';
            $isi .= '<td class="center">' . htmlspecialchars($this->formatTanggalIndo($r->tanggal)) . '</td>';
            $isi .= '<td class="center">' . htmlspecialchars($r->kelas) . '</td>';
            $isi .= '<td class="center">' . (int) $r->jam_sekolah . '</td>';
            $isi .= '<td class="left">' . htmlspecialchars($r->nama_mapel) . '</td>';
            $isi .= '<td class="center">' . (int) $r->pertemuan . '</td>';
            $isi .= '<td class="left">' . htmlspecialchars($r->sub_kompetensi) . '</td>';
            $isi .= '<td class="left">' . htmlspecialchars((string) $r->keterangan) . '</td>';
            $isi .= '</tr>';
        }
        if ($rows->isEmpty()) {
            $isi .= '<tr><td class="center" colspan="8">Belum ada jurnal pada tahun ajaran ini.</td></tr>';
        }
        $isi .= '</tbody></table>';

        $filename = 'Rekap_Jurnal_' . preg_replace('/[^A-Za-z0-9_-]/', '_', (string) $kodeGuru) . '_TA' . str_replace('/', '-', $ta['ta_label']) . '_' . date('Ymd_His') . '.xls';

        return $this->responsExcel($filename, 'REKAPITULASI JURNAL MENGAJAR GURU', $meta, $isi);
    }

    // =========================================================================
    // 6. REKAP KEHADIRAN GURU (semua guru, per periode)
    // =========================================================================

    /** Rentang tanggal dari ?dari & ?sampai (default: awal bulan ini s.d. hari ini) */
    private function rentangKehadiran(Request $request): array
    {
        $now = Carbon::now('Asia/Makassar');
        $dari = $this->tanggalValid($request->query('dari')) ?? $now->copy()->startOfMonth()->toDateString();
        $sampai = $this->tanggalValid($request->query('sampai')) ?? $now->toDateString();

        if ($dari > $sampai) {
            [$dari, $sampai] = [$sampai, $dari];
        }

        return [$dari, $sampai];
    }

    /** Data rekap kehadiran per guru pada rentang tanggal */
    private function dataRekapKehadiran(string $dari, string $sampai)
    {
        $statistik = DB::table('tb_absen_guru')
            ->whereBetween('tanggal', [$dari, $sampai])
            ->select(
                'kode_guru',
                DB::raw('COUNT(*) as total'),
                DB::raw("SUM(CASE WHEN status = 'H' THEN 1 ELSE 0 END) as hadir"),
                DB::raw("SUM(CASE WHEN status = 'I' THEN 1 ELSE 0 END) as izin"),
                DB::raw("SUM(CASE WHEN status = 'S' THEN 1 ELSE 0 END) as sakit"),
                DB::raw("SUM(CASE WHEN status = 'A' THEN 1 ELSE 0 END) as alpa")
            )
            ->groupBy('kode_guru')
            ->get()
            ->keyBy('kode_guru');

        return DB::table('tb_guru')->orderBy('nama')->get()->map(function ($g) use ($statistik) {
            $st = $statistik[$g->kode_guru] ?? null;
            $hadir = $st ? (int) $st->hadir : 0;
            $total = $st ? (int) $st->total : 0;

            return (object) [
                'kode_guru' => $g->kode_guru,
                'nama'      => $g->nama,
                'mapel'     => $g->mapel ?: '-',
                'hadir'     => $hadir,
                'izin'      => $st ? (int) $st->izin : 0,
                'sakit'     => $st ? (int) $st->sakit : 0,
                'alpa'      => $st ? (int) $st->alpa : 0,
                'total'     => $total,
                'persen'    => $total > 0 ? round(($hadir / $total) * 100, 1) : null,
            ];
        });
    }

    public function rekapKehadiran(Request $request)
    {
        if (!session('sudah_login')) {
            return redirect()->route('login');
        }

        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];
        $mapelGuru = $guru['mapel'];
        $kodeGuruSaya = $guru['kode_guru'];

        [$dari, $sampai] = $this->rentangKehadiran($request);
        $search = trim((string) $request->query('q', ''));

        $rekapGuru = $this->dataRekapKehadiran($dari, $sampai);
        $ringkasan = (object) [
            'hadir' => $rekapGuru->sum('hadir'),
            'izin'  => $rekapGuru->sum('izin'),
            'sakit' => $rekapGuru->sum('sakit'),
            'alpa'  => $rekapGuru->sum('alpa'),
            'total' => $rekapGuru->sum('total'),
        ];

        if ($search !== '') {
            $rekapGuru = $rekapGuru->filter(function ($g) use ($search) {
                return str_contains(mb_strtolower($g->nama), mb_strtolower($search))
                    || str_contains(mb_strtolower($g->mapel), mb_strtolower($search));
            })->values();
        }

        $labelTa = $this->labelTahunAjaranRentang($dari, $sampai);
        $dariFormatted = $this->formatTanggalIndo($dari);
        $sampaiFormatted = $this->formatTanggalIndo($sampai);

        return view('guru.guru-rekap-kehadiran', compact(
            'namaGuru',
            'mapelGuru',
            'kodeGuruSaya',
            'rekapGuru',
            'ringkasan',
            'dari',
            'sampai',
            'dariFormatted',
            'sampaiFormatted',
            'labelTa',
            'search'
        ));
    }

    public function exportRekapKehadiran(Request $request)
    {
        $guru = $this->getGuruData();
        $namaGuru = $guru['nama'];

        [$dari, $sampai] = $this->rentangKehadiran($request);
        $rekapGuru = $this->dataRekapKehadiran($dari, $sampai);
        $labelTa = $this->labelTahunAjaranRentang($dari, $sampai);

        $meta = [
            'SMK TI Bali Global Badung',
            'Tahun Ajaran: ' . $labelTa,
            'Periode: ' . $this->formatTanggalIndo($dari) . ' - ' . $this->formatTanggalIndo($sampai),
            'Diunduh oleh: ' . $namaGuru . ' | Tanggal unduh: ' . date('d/m/Y H:i') . ' WITA',
        ];

        $isi = '<table><thead><tr>
            <th class="center" style="width: 40px;">No.</th>
            <th class="center" style="width: 80px;">Kode</th>
            <th class="left" style="width: 300px;">Nama Guru</th>
            <th class="left" style="width: 300px;">Mata Pelajaran</th>
            <th class="center" style="width: 80px;">Hadir (H)</th>
            <th class="center" style="width: 80px;">Izin (I)</th>
            <th class="center" style="width: 80px;">Sakit (S)</th>
            <th class="center" style="width: 80px;">Alpa (A)</th>
            <th class="center" style="width: 100px;">Total Hari</th>
            <th class="center" style="width: 100px;">Kehadiran (%)</th>
        </tr></thead><tbody>';

        $no = 1;
        foreach ($rekapGuru as $g) {
            $isi .= '<tr>';
            $isi .= '<td class="center">' . $no++ . '</td>';
            $isi .= '<td class="center">' . (int) $g->kode_guru . '</td>';
            $isi .= '<td class="left">' . htmlspecialchars($g->nama) . '</td>';
            $isi .= '<td class="left">' . htmlspecialchars($g->mapel) . '</td>';
            $isi .= '<td class="center hadir">' . $g->hadir . '</td>';
            $isi .= '<td class="center izin">' . $g->izin . '</td>';
            $isi .= '<td class="center sakit">' . $g->sakit . '</td>';
            $isi .= '<td class="center alpa">' . $g->alpa . '</td>';
            $isi .= '<td class="center">' . $g->total . '</td>';
            $isi .= '<td class="center" style="font-weight: bold;">' . ($g->persen !== null ? $g->persen . '%' : '-') . '</td>';
            $isi .= '</tr>';
        }
        $isi .= '</tbody></table>';

        $filename = 'Rekap_Kehadiran_Guru_' . $dari . '_sd_' . $sampai . '_' . date('His') . '.xls';

        return $this->responsExcel($filename, 'REKAPITULASI KEHADIRAN GURU', $meta, $isi);
    }
}

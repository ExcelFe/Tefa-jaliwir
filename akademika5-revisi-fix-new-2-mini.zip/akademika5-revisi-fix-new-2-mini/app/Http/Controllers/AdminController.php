<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class AdminController extends Controller
{
    /** Map nama hari Indonesia */
    private $daftarHari = [
        1 => 'senin',
        2 => 'selasa',
        3 => 'rabu',
        4 => 'kamis',
        5 => 'jumat',
    ];

    /** Helper: format DATE ke bahasa Indonesia */
    private function formatTanggalIndo(string $dateStr): string
    {
        return PiketAbsenController::formatTanggalIndo($dateStr);
    }

    /** Helper cek akses admin */
    private function checkAdmin()
    {
        if (!session('sudah_login') || session('jenis_akun') !== 'admin') {
            return false;
        }
        return true;
    }

    // =========================================================================
    // 1. STATUS GURU (Melihat status kehadiran & mengajar semua guru secara real-time)
    // =========================================================================
    public function status(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $now = Carbon::now('Asia/Makassar');
        $hariDb = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';

        $tanggalPilihan = $request->query('tanggal', $now->toDateString());
        $tanggalFormatted = $this->formatTanggalIndo($tanggalPilihan);

        $guruList = DB::table('tb_guru')->orderBy('kode_guru')->get();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggalPilihan)
            ->get()
            ->keyBy('kode_guru');

        $jadwalHariIni = DB::table('tb_mapel_guru')
            ->where('hari', $hariDb)
            ->orderBy('jam_mulai')
            ->get()
            ->groupBy('kode_guru');

        $jamMenitSekarang = (float) $now->format('H.i');

        $isToday = ($tanggalPilihan === $now->toDateString());
        if ($absenDb->isEmpty() && !$isToday) {
            $dataGuru = collect();
        } else {
            $dataGuru = $guruList->map(function ($guru) use ($absenDb, $jadwalHariIni, $jamMenitSekarang, $tanggalFormatted) {
                $absen = $absenDb[$guru->kode_guru] ?? null;
                $statusRaw = $absen ? strtoupper($absen->status) : null;

                $statusText = match ($statusRaw) {
                    'H'      => 'Hadir',
                    'I'      => 'Izin',
                    'S'      => 'Sakit',
                    'A', 'T' => 'Alpa',
                    default  => 'Belum Diabsen',
                };
                $isHadir = ($statusText === 'Hadir');

                $jadwalGuru = $jadwalHariIni->get($guru->kode_guru, collect());
                $sedangNgajar = null;
                foreach ($jadwalGuru as $j) {
                    $mulai   = (float) str_replace(':', '.', $j->jam_mulai);
                    $selesai = (float) str_replace(':', '.', $j->jam_selesai);
                    if ($jamMenitSekarang >= $mulai && $jamMenitSekarang <= $selesai) {
                        $sedangNgajar = $j->nama_mapel . ' di ' . $j->kelas . ' (' . $j->waktu_pelajaran . ')';
                        break;
                    }
                }

                if (!$sedangNgajar) {
                    $sedangNgajar = $jadwalGuru->isNotEmpty()
                        ? 'Tidak sedang mengajar (' . $jadwalGuru->count() . ' jam hari ini)'
                        : 'Tidak ada jadwal mengajar hari ini';
                }

                return (object) [
                    'kode_guru'         => $guru->kode_guru,
                    'nama'              => $guru->nama,
                    'mapel'             => $guru->mapel ?: '-',
                    'status'            => $statusText,
                    'is_hadir'          => $isHadir,
                    'sedang_ngajar'     => $sedangNgajar,
                    'tanggal_formatted' => $tanggalFormatted,
                ];
            });
        }

        return view('admin.admin-status', compact(
            'dataGuru',
            'tanggalPilihan',
            'tanggalFormatted'
        ));
    }

    // =========================================================================
    // 2. GURU PIKET & GURU PIKET PENGGANTI (Real-time jadwal & penugasan pengganti)
    // =========================================================================
    public function piket(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $now = Carbon::now('Asia/Makassar');
        $hariIni = $this->daftarHari[$now->dayOfWeekIso] ?? 'senin';
        $tanggalHariIni = $now->toDateString();
        $tanggalFormatted = $this->formatTanggalIndo($tanggalHariIni);
        $jamMenitSekarang = (float) $now->format('H.i');

        // Tentukan shift aktif saat ini
        $shiftAktif = ($jamMenitSekarang >= 12.30) ? 'siang' : 'pagi';

        // Ambil semua jadwal tetap piket (tb_guru_piket)
        $semuaJadwalPiket = DB::table('tb_guru_piket')
            ->join('tb_guru', 'tb_guru_piket.kode_guru', '=', 'tb_guru.kode_guru')
            ->select('tb_guru_piket.*', 'tb_guru.nama as nama_guru', 'tb_guru.mapel as mapel_guru')
            ->orderByRaw("FIELD(tb_guru_piket.hari, 'senin', 'selasa', 'rabu', 'kamis', 'jumat')")
            ->orderBy('tb_guru_piket.id')
            ->get();

        // Cari guru piket asli untuk hari ini
        $piketHariIniRows = $semuaJadwalPiket->where('hari', $hariIni);

        // Ambil penugasan piket pengganti aktif untuk hari ini
        $penggantiHariIni = DB::table('tb_piket_pengganti')
            ->join('tb_guru', 'tb_piket_pengganti.kode_guru', '=', 'tb_guru.kode_guru')
            ->leftJoin('tb_guru as guru_asli', 'tb_piket_pengganti.kode_guru_asli', '=', 'guru_asli.kode_guru')
            ->whereDate('tb_piket_pengganti.tanggal', $tanggalHariIni)
            ->select(
                'tb_piket_pengganti.*',
                'tb_guru.nama as nama_pengganti',
                'tb_guru.mapel as mapel_pengganti',
                'guru_asli.nama as nama_asli'
            )
            ->get();

        // Tentukan guru piket yang sedang bertugas saat ini
        $piketAktif = null;
        $piketHariIniAktif = $piketHariIniRows->first(function ($p) use ($shiftAktif) {
            return str_contains(strtolower($p->waktu), $shiftAktif);
        }) ?? $piketHariIniRows->first();

        // Cek apakah ada pengganti untuk shift ini atau tanggal ini
        $penggantiAktif = $penggantiHariIni->first(function ($p) use ($shiftAktif) {
            return $p->shift === 'semua' || strtolower($p->shift) === $shiftAktif;
        });

        if ($penggantiAktif) {
            $piketAktif = (object) [
                'nama'          => $penggantiAktif->nama_pengganti,
                'mapel'         => $penggantiAktif->mapel_pengganti,
                'status_label'  => 'Guru Piket Pengganti',
                'waktu_tugas'   => $piketHariIniAktif ? $piketHariIniAktif->waktu : '07.00 - 17.15',
                'is_pengganti'  => true,
                'pengganti_id'  => $penggantiAktif->id,
                'keterangan'    => $penggantiAktif->keterangan ?? 'Menggantikan ' . ($penggantiAktif->nama_asli ?? 'guru piket'),
            ];
        } elseif ($piketHariIniAktif) {
            $piketAktif = (object) [
                'nama'          => $piketHariIniAktif->nama_guru,
                'mapel'         => $piketHariIniAktif->mapel_guru,
                'status_label'  => 'Guru Piket Terjadwal (' . ucfirst($shiftAktif) . ')',
                'waktu_tugas'   => $piketHariIniAktif->waktu,
                'is_pengganti'  => false,
                'kode_guru'     => $piketHariIniAktif->kode_guru,
                'keterangan'    => 'Bertugas sesuai jadwal tetap ' . ucfirst($hariIni),
            ];
        }

        // Daftar semua guru untuk pilihan dropdown pengganti
        $daftarSemuaGuru = DB::table('tb_guru')->orderBy('nama')->get();

        return view('admin.admin-piket', compact(
            'piketAktif',
            'semuaJadwalPiket',
            'penggantiHariIni',
            'daftarSemuaGuru',
            'tanggalFormatted',
            'hariIni',
            'shiftAktif'
        ));
    }

    /** Simpan Guru Piket Pengganti (Admin menugaskan guru lain) */
    public function simpanPiketPengganti(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $request->validate([
            'kode_guru' => 'required|integer',
            'tanggal'   => 'required|date',
            'shift'     => 'nullable|string',
            'keterangan'=> 'nullable|string',
        ]);

        $kodeGuru = (int) $request->input('kode_guru');
        $tanggal  = $request->input('tanggal');
        $shift    = $request->input('shift', 'semua');
        $ket      = $request->input('keterangan', 'Ditugaskan oleh Admin karena guru piket berhalangan');

        // Cari guru piket asli untuk hari dari tanggal tersebut
        $dt = Carbon::parse($tanggal);
        $hariName = $this->daftarHari[$dt->dayOfWeekIso] ?? 'senin';
        $piketAsliRow = DB::table('tb_guru_piket')
            ->where('hari', $hariName)
            ->first();
        $kodeGuruAsli = $piketAsliRow ? $piketAsliRow->kode_guru : null;

        DB::table('tb_piket_pengganti')->insert([
            'kode_guru'       => $kodeGuru,
            'tanggal'         => $tanggal,
            'shift'           => $shift,
            'kode_guru_asli'  => $kodeGuruAsli,
            'keterangan'      => $ket,
            'created_at'      => now(),
            'updated_at'      => now(),
        ]);

        $guruRow = DB::table('tb_guru')->where('kode_guru', $kodeGuru)->first();
        $nama = $guruRow ? $guruRow->nama : 'Guru';

        return redirect()->route('admin.piket')->with('success', "Akses guru piket pengganti berhasil diberikan kepada {$nama}. Notifikasi akses telah dikirimkan ke dashboard guru terkait.");
    }

    /** Batalkan Akses Guru Piket Pengganti */
    public function batalPiketPengganti($id)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        DB::table('tb_piket_pengganti')->where('id', $id)->delete();

        return redirect()->route('admin.piket')->with('success', 'Akses guru piket pengganti berhasil dibatalkan.');
    }

    // =========================================================================
    // 3. REKAP SISWA (Detail per kelas & per tanggal, tabel terperinci)
    // =========================================================================
    public function rekapSiswa(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $allKelas = array_values(array_unique(array_merge(
            DB::table('tb_murid_x')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xi')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xii')->distinct()->pluck('kelas')->toArray()
        )));

        $kelasPilihan = $request->query('kelas', $allKelas[0] ?? 'X PPLG 1');
        $tanggalPilihan = $request->query('tanggal', date('Y-m-d'));
        $tanggalFormatted = $this->formatTanggalIndo($tanggalPilihan);

        $tingkat = 'X';
        if (str_starts_with($kelasPilihan, 'XII ') || $kelasPilihan === 'XII') {
            $tingkat = 'XII';
        } elseif (str_starts_with($kelasPilihan, 'XI ') || $kelasPilihan === 'XI') {
            $tingkat = 'XI';
        }

        $tabelMurid = match ($tingkat) {
            'XI'  => 'tb_murid_xi',
            'XII' => 'tb_murid_xii',
            default => 'tb_murid_x',
        };
        $nisCol = match ($tingkat) {
            'XI'  => 'nis_xi',
            'XII' => 'nis_xii',
            default => 'nis_x',
        };
        $tabelAbsen = match ($tingkat) {
            'XI'  => 'tb_absen_murid_xi',
            'XII' => 'tb_absen_murid_xii',
            default => 'tb_absen_murid_x',
        };

        // Ambil daftar siswa kelas tersebut
        $muridList = DB::table($tabelMurid)
            ->where('kelas', $kelasPilihan)
            ->orderBy('absen')
            ->orderBy('nama')
            ->get();

        // Ambil data absensi tanggal tersebut
        $absenDb = DB::table($tabelAbsen)
            ->where('tanggal', $tanggalPilihan)
            ->get()
            ->keyBy($nisCol);

        $totalHadir = 0;
        $totalSakit = 0;
        $totalIzin = 0;
        $totalAlpa = 0;

        // Jika pada tanggal tersebut belum ada presensi di database, jangan generate data dummy!
        if ($absenDb->isEmpty()) {
            $daftarPresensi = collect();
        } else {
            $daftarPresensi = $muridList->map(function ($m, $idx) use ($nisCol, $absenDb, &$totalHadir, &$totalSakit, &$totalIzin, &$totalAlpa) {
                $nis = $m->$nisCol;
                $absen = $absenDb[$nis] ?? null;
                $statusRaw = $absen ? strtoupper($absen->status) : null;

                $statusText = match ($statusRaw) {
                    'H' => 'Hadir',
                    'S' => 'Sakit',
                    'I' => 'Izin',
                    'A' => 'Alpa',
                    default => 'Belum Diabsen',
                };

                match ($statusText) {
                    'Hadir' => $totalHadir++,
                    'Sakit' => $totalSakit++,
                    'Izin'  => $totalIzin++,
                    'Alpa'  => $totalAlpa++,
                    default => null,
                };

                return (object) [
                    'nis'     => $nis,
                    'no'      => $m->absen ?: ($idx + 1),
                    'nama'    => $m->nama,
                    'status'  => $statusText,
                    'catatan' => $absen ? ($absen->catatan ?? '-') : '-',
                ];
            });
        }

        // Ringkasan per semua kelas untuk overview
        $overviewKelas = [];
        foreach ($allKelas as $k) {
            $t = (str_starts_with($k, 'XII ') || $k === 'XII') ? 'XII' : ((str_starts_with($k, 'XI ') || $k === 'XI') ? 'XI' : 'X');
            $tm = match ($t) { 'XI' => 'tb_murid_xi', 'XII' => 'tb_murid_xii', default => 'tb_murid_x' };
            $cnt = DB::table($tm)->where('kelas', $k)->count();
            $overviewKelas[] = (object) ['kelas' => $k, 'total_siswa' => $cnt];
        }

        return view('admin.admin-rekap-siswa', compact(
            'allKelas',
            'kelasPilihan',
            'tanggalPilihan',
            'tanggalFormatted',
            'daftarPresensi',
            'totalHadir',
            'totalSakit',
            'totalIzin',
            'totalAlpa',
            'overviewKelas'
        ));
    }

    // =========================================================================
    // 4. REKAP GURU (Detail absensi guru per tanggal terperinci)
    // =========================================================================
    public function rekapGuru(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $tanggalPilihan = $request->query('tanggal', date('Y-m-d'));
        $tanggalFormatted = $this->formatTanggalIndo($tanggalPilihan);

        $guruList = DB::table('tb_guru')->orderBy('nama')->get();

        $absenDb = DB::table('tb_absen_guru')
            ->whereDate('tanggal', $tanggalPilihan)
            ->get()
            ->keyBy('kode_guru');

        $totalHadir = 0;
        $totalSakit = 0;
        $totalIzin = 0;
        $totalAlpa = 0;

        // Jika pada tanggal tersebut tidak ada data absensi di DB, jangan generate data dummy!
        if ($absenDb->isEmpty()) {
            $daftarGuruAbsen = collect();
        } else {
            $daftarGuruAbsen = $guruList->map(function ($guru, $idx) use ($absenDb, &$totalHadir, &$totalSakit, &$totalIzin, &$totalAlpa) {
                $absen = $absenDb[$guru->kode_guru] ?? null;
                $statusRaw = $absen ? strtoupper($absen->status) : null;

                $statusText = match ($statusRaw) {
                    'H' => 'Hadir',
                    'S' => 'Sakit',
                    'I' => 'Izin',
                    'A' => 'Alpa',
                    default => 'Belum Diabsen',
                };

                match ($statusText) {
                    'Hadir'       => $totalHadir++,
                    'Sakit'       => $totalSakit++,
                    'Izin'        => $totalIzin++,
                    'Alpa'        => $totalAlpa++,
                    default       => null,
                };

                return (object) [
                    'no'        => $idx + 1,
                    'kode_guru' => $guru->kode_guru,
                    'nama'      => $guru->nama,
                    'mapel'     => $guru->mapel ?: '-',
                    'status'    => $statusText,
                    'catatan'   => $absen ? ($absen->catatan ?? '-') : '-',
                ];
            });
        }

        return view('admin.admin-rekap-guru', compact(
            'tanggalPilihan',
            'tanggalFormatted',
            'daftarGuruAbsen',
            'totalHadir',
            'totalSakit',
            'totalIzin',
            'totalAlpa'
        ));
    }

    // =========================================================================
    // 5. REKAP JURNAL (Melihat rekapan seluruh jurnal mengajar guru dengan filter tanggal/kelas)
    // =========================================================================
    public function rekapJurnal(Request $request)
    {
        if (!$this->checkAdmin()) {
            return redirect()->route('login');
        }

        $allKelas = array_values(array_unique(array_merge(
            DB::table('tb_murid_x')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xi')->distinct()->pluck('kelas')->toArray(),
            DB::table('tb_murid_xii')->distinct()->pluck('kelas')->toArray()
        )));

        $kelasPilihan   = $request->query('kelas', '');
        $tanggalPilihan = $request->query('tanggal', '');
        $search         = trim($request->query('q', ''));

        $query = DB::table('tb_jurnal')
            ->join('tb_guru', 'tb_jurnal.kode_guru', '=', 'tb_guru.kode_guru')
            ->select('tb_jurnal.*', 'tb_guru.nama as nama_guru')
            ->orderByDesc('tb_jurnal.tanggal')
            ->orderByDesc('tb_jurnal.jam_sekolah');

        if (!empty($kelasPilihan)) {
            $query->where('tb_jurnal.kelas', $kelasPilihan);
        }
        if (!empty($tanggalPilihan)) {
            $query->whereDate('tb_jurnal.tanggal', $tanggalPilihan);
        }
        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('tb_guru.nama', 'like', "%{$search}%")
                  ->orWhere('tb_jurnal.nama_mapel', 'like', "%{$search}%")
                  ->orWhere('tb_jurnal.sub_kompetensi', 'like', "%{$search}%");
            });
        }

        $jurnals = $query->paginate(25)->through(function ($j) {
            $j->tanggal_formatted = $this->formatTanggalIndo($j->tanggal);
            return $j;
        });

        return view('admin.admin-rekap-jurnal', compact(
            'jurnals',
            'allKelas',
            'kelasPilihan',
            'tanggalPilihan',
            'search'
        ));
    }
}

<?php

namespace App\Support;

/**
 * Pemetaan kode_guru -> file foto di public/media/profil.
 *
 * tb_guru tidak punya kolom foto, sedangkan foto guru tersimpan sebagai berkas
 * statis (nama berkas tidak memakai kode guru). Pemetaan di bawah disusun dari
 * pasangan foto-nama pada halaman profil-guru. Guru yang belum punya foto
 * dikembalikan null sehingga tampilan memakai avatar inisial.
 */
class GuruFoto
{
    private const PETA = [
        1  => 'media/profil/manajemen/kepalasekolah.jpg',
        2  => 'media/profil/manajemen/wakakurikulum.jpeg',
        3  => 'media/profil/manajemen/wakasarpras.jpeg',
        4  => 'media/profil/manajemen/wakahumas.jpeg',
        5  => 'media/profil/manajemen/wakakesiswaan.jpeg',
        6  => 'media/profil/kaprog/kaprogpplg.jpeg',
        7  => 'media/profil/kaprog/kaprogdkv.jpeg',
        8  => 'media/profil/kaprog/kaprogtjkt.jpeg',
        9  => 'media/profil/kaprog/kaprogbd.jpeg',
        11 => 'media/profil/staff/assmarkom.jpeg',
        12 => 'media/profil/produktif/darmamatik.jpeg',
        13 => 'media/profil/produktif/muliawanpenjas.jpeg',
        14 => 'media/profil/produktif/murniproduktif.jpeg',
        15 => 'media/profil/produktif/kantianimatik.jpeg',
        16 => 'media/profil/produktif/yanpancasila.jpeg',
        17 => 'media/profil/produktif/ratihpkwu.jpeg',
        18 => 'media/profil/produktif/ditaipas.jpeg',
        19 => 'media/profil/produktif/lalaipas.jpeg',
        20 => 'media/profil/produktif/sinthyabing.jpeg',
        21 => 'media/profil/produktif/wahyuproduktif.jpeg',
        22 => 'media/profil/produktif/candrabindo.jpeg',
        23 => 'media/profil/produktif/imeldajapan.jpeg',
        24 => 'media/profil/produktif/oktiabing.jpeg',
        25 => 'media/profil/produktif/thessaproduktif.jpeg',
        26 => 'media/profil/produktif/bintabindo.jpeg',
        27 => 'media/profil/produktif/samsulislam.jpeg',
        28 => 'media/profil/produktif/ratnasenibudaya.jpeg',
        29 => 'media/profil/produktif/meirahindu.jpeg',
        30 => 'media/profil/staff/urusankesiswaan.jpeg',
        31 => 'media/profil/staff/asslab.jpeg',
        34 => 'media/profil/produktif/masrikristen.jpeg',
        35 => 'media/profil/staff/kepalatatausaha.jpeg',
    ];

    /** URL foto guru, atau null bila belum ada / berkas tidak ditemukan. */
    public static function url($kodeGuru): ?string
    {
        if ($kodeGuru === null || $kodeGuru === '') {
            return null;
        }

        $path = self::PETA[(int) $kodeGuru] ?? null;
        if ($path === null || !is_file(public_path($path))) {
            return null;
        }

        return asset($path);
    }

    /** Inisial (maks. 2 huruf) untuk avatar cadangan. */
    public static function inisial(?string $nama): string
    {
        $nama = trim((string) $nama);
        if ($nama === '') {
            return '?';
        }

        $kata = preg_split('/[\s,.]+/', $nama, -1, PREG_SPLIT_NO_EMPTY);
        $abaikan = ['i', 'ni', 'ida', 'ayu', 'gusti', 'gst', 'putu', 'made', 'nyoman', 'ketut', 'luh', 'wayan', 'gede', 'kadek', 'aa'];
        $kandidat = array_values(array_filter($kata, fn ($k) => !in_array(strtolower($k), $abaikan, true)));
        $kata = count($kandidat) >= 1 ? $kandidat : $kata;

        $hasil = mb_strtoupper(mb_substr($kata[0], 0, 1));
        if (isset($kata[1])) {
            $hasil .= mb_strtoupper(mb_substr($kata[1], 0, 1));
        }

        return $hasil;
    }
}

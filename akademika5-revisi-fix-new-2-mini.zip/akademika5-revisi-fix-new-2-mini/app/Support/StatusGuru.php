<?php

namespace App\Support;

/** Pemetaan label status kehadiran guru -> slug warna (hadir/izin/sakit/alpa/belum). */
class StatusGuru
{
    public const DAFTAR = [
        'hadir' => 'Hadir',
        'izin'  => 'Izin',
        'sakit' => 'Sakit',
        'alpa'  => 'Alpa',
        'belum' => 'Belum Diabsen',
    ];

    public static function slug(?string $status): string
    {
        return match (strtolower(trim((string) $status))) {
            'hadir'                      => 'hadir',
            'izin'                       => 'izin',
            'sakit'                      => 'sakit',
            'alpa', 'tidak hadir', 'a', 't' => 'alpa',
            default                      => 'belum',
        };
    }
}

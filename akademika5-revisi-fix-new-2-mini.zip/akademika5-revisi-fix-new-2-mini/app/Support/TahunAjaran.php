<?php

namespace App\Support;

use Carbon\Carbon;

/**
 * Tahun ajaran Indonesia: dimulai 1 Juli, berakhir 30 Juni.
 * Semester Ganjil = Juli-Desember, Genap = Januari-Juni.
 */
class TahunAjaran
{
    /** Tahun mulai (mis. 2026 untuk 2026/2027) dari sebuah tanggal. */
    public static function tahunMulai(Carbon $tanggal): int
    {
        return $tanggal->month >= 7 ? $tanggal->year : $tanggal->year - 1;
    }

    public static function label(int $tahunMulai): string
    {
        return $tahunMulai . '/' . ($tahunMulai + 1);
    }

    /** [tanggal mulai, tanggal akhir] format Y-m-d */
    public static function rentang(int $tahunMulai): array
    {
        return [$tahunMulai . '-07-01', ($tahunMulai + 1) . '-06-30'];
    }

    public static function semester(Carbon $tanggal): string
    {
        return $tanggal->month >= 7 ? 'Ganjil' : 'Genap';
    }

    /** Normalisasi input ?ta=2026 (atau "2026/2027"); bila tidak valid pakai tahun ajaran berjalan. */
    public static function dariInput($input, Carbon $sekarang): int
    {
        if (is_string($input) && preg_match('/^(\d{4})(?:\/\d{4})?$/', trim($input), $m)) {
            $tahun = (int) $m[1];
            if ($tahun >= 2000 && $tahun <= 2100) {
                return $tahun;
            }
        }

        return self::tahunMulai($sekarang);
    }

    /** Daftar tahun mulai dari data paling awal (minimal tahun ajaran berjalan). */
    public static function daftar(?string $tanggalTerawal, Carbon $sekarang): array
    {
        $akhir = self::tahunMulai($sekarang);
        $awal = $akhir;

        if ($tanggalTerawal) {
            try {
                $awal = min($akhir, self::tahunMulai(Carbon::parse($tanggalTerawal)));
            } catch (\Throwable $e) {
                $awal = $akhir;
            }
        }

        return range($akhir, $awal);
    }
}

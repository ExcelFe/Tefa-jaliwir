<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Jurnal Mengajar - Dashboard Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        /* Card Layout untuk Rekap Absensi */
        .rekap-card {
            display: flex;
            flex-direction: column;
            gap: 0.65rem;
            width: 100%;
            padding: 1.1rem 1.35rem;
        }

        .rekap-card__top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .rekap-card__title {
            font-family: var(--font-body);
            font-size: 0.95rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--dash-ink);
            letter-spacing: 0.02em;
            margin: 0;
            line-height: 1.3;
        }

        .rekap-card__meta {
            font-size: 0.8125rem;
            color: var(--dash-muted);
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
        }

        .rekap-card__bottom {
            display: flex;
            align-items: center;
            gap: 0.55rem;
            flex-wrap: wrap;
        }

        .rekap-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.28rem 0.75rem;
            border-radius: var(--radius-pill);
            font-weight: 700;
            font-size: 0.775rem;
            line-height: 1;
            white-space: nowrap;
        }
        .rekap-badge--rate {
            background: #dbeafe;
            color: #1d4ed8;
            border: 1px solid rgba(29, 78, 216, 0.2);
            font-weight: 800;
        }
        [data-theme="dark"] .rekap-badge--rate {
            background: rgba(59, 130, 246, 0.2);
            color: #93c5fd;
            border-color: rgba(59, 130, 246, 0.3);
        }

        .rekap-badge--hadir {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid rgba(21, 128, 61, 0.2);
        }
        [data-theme="dark"] .rekap-badge--hadir {
            background: rgba(34, 197, 94, 0.18);
            color: #86efac;
            border-color: rgba(34, 197, 94, 0.3);
        }

        .rekap-badge--sakit {
            background: #e0f2fe;
            color: #0369a1;
            border: 1px solid rgba(3, 105, 161, 0.2);
        }
        [data-theme="dark"] .rekap-badge--sakit {
            background: rgba(14, 165, 233, 0.18);
            color: #7dd3fc;
            border-color: rgba(14, 165, 233, 0.3);
        }

        .rekap-badge--izin {
            background: #fef3c7;
            color: #b45309;
            border: 1px solid rgba(180, 83, 9, 0.2);
        }
        [data-theme="dark"] .rekap-badge--izin {
            background: rgba(245, 158, 11, 0.18);
            color: #fde68a;
            border-color: rgba(245, 158, 11, 0.3);
        }

        .rekap-badge--alpa {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid rgba(185, 28, 28, 0.2);
        }
        [data-theme="dark"] .rekap-badge--alpa {
            background: rgba(239, 68, 68, 0.18);
            color: #fca5a5;
            border-color: rgba(239, 68, 68, 0.3);
        }
        
        .btn-download-all {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: #16a34a;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.85rem;
            padding: 0.6rem 1.15rem;
            border-radius: var(--radius-pill);
            text-decoration: none;
            transition: all 0.2s;
            border: none;
            box-shadow: 0 2px 4px rgba(22, 163, 74, 0.2);
            white-space: nowrap;
        }
        .btn-download-all:hover {
            background: #15803d;
            transform: translateY(-1px);
        }
        .btn-download-all svg {
            width: 18px;
            height: 18px;
            fill: currentColor;
        }

        @media (max-width: 640px) {
            .rekap-card__top {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.25rem;
            }
            .rekap-card__meta {
                margin-left: 0;
            }
        }

        .stat-row { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 1.25rem; }
        .stat-box { flex: 1; min-width: 150px; padding: 0.9rem 1.1rem; background: var(--dash-surface); border: 1px solid var(--dash-edge); border-radius: var(--radius-md); box-shadow: var(--dash-shadow); }
        .stat-box__label { font-size: 0.75rem; font-weight: 600; color: var(--dash-muted); text-transform: uppercase; letter-spacing: 0.03em; }
        .stat-box__value { font-family: var(--font-heading); font-size: 1.7rem; line-height: 1.2; color: var(--dash-ink); }
        .section-title { font-family: var(--font-heading); font-size: 1.15rem; text-transform: uppercase; letter-spacing: 0.02em; margin: 1.5rem 0 0.75rem; }
        .table-scroll { overflow-x: auto; border: 1px solid var(--dash-edge); border-radius: var(--radius-md); background: var(--dash-surface); }
        .rekap-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; min-width: 680px; }
        .rekap-table th { text-align: left; padding: 0.65rem 0.8rem; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.03em; color: var(--dash-muted); border-bottom: 1px solid var(--dash-edge); white-space: nowrap; }
        .rekap-table td { padding: 0.65rem 0.8rem; border-bottom: 1px solid var(--dash-edge); vertical-align: top; color: var(--dash-ink); }
        .rekap-table tr:last-child td { border-bottom: none; }
        .rekap-table .num { text-align: center; white-space: nowrap; }
        .rekap-table tr.baris-saya td { background: color-mix(in srgb, #2563eb 8%, transparent); font-weight: 600; }
        .empty-note { padding: 2rem 1rem; text-align: center; color: var(--dash-muted); }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        @include('partials.guru-sidebar', ['aktif' => 'rekap-jurnal'])

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @include('partials.flash')
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Rekap Jurnal Mengajar</h1>
                    </div>
                    <div class="dash-tools">
                        <a href="{{ route('guru.rekap.jurnal.export', ['ta' => $ta_mulai, 'kelas' => $filterKelas, 'mapel' => $filterMapel]) }}" class="btn-download-all" title="Unduh rekap jurnal (TA {{ $ta_label }})">
                            <svg viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                            <span>Unduh Excel</span>
                        </a>
                    </div>
                </header>

                <form method="GET" action="{{ route('guru.rekap.jurnal') }}" class="log-filter" aria-label="Filter rekap jurnal">
                    <div class="log-filter__field">
                        <label for="filter-ta">Tahun Ajaran</label>
                        <select id="filter-ta" name="ta">
                            @foreach (collect($ta_daftar)->push($ta_mulai)->unique()->sortDesc() as $th)
                                <option value="{{ $th }}" {{ $th === $ta_mulai ? 'selected' : '' }}>{{ $th }}/{{ $th + 1 }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="log-filter__field">
                        <label for="filter-kelas">Kelas</label>
                        <select id="filter-kelas" name="kelas">
                            <option value="">Semua kelas</option>
                            @foreach ($daftarKelasJurnal as $k)
                                <option value="{{ $k }}" {{ $filterKelas === $k ? 'selected' : '' }}>{{ $k }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="log-filter__field">
                        <label for="filter-mapel">Mata Pelajaran</label>
                        <select id="filter-mapel" name="mapel">
                            <option value="">Semua mapel</option>
                            @foreach ($daftarMapelJurnal as $m)
                                <option value="{{ $m }}" {{ $filterMapel === $m ? 'selected' : '' }}>{{ $m }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="log-filter__actions">
                        <button type="submit" class="dash-btn">Terapkan</button>
                        <a href="{{ route('guru.rekap.jurnal') }}" class="dash-btn dash-btn--ghost" style="text-decoration: none;">Reset</a>
                    </div>
                </form>
                <p class="log-filter__info">Tahun ajaran <strong>{{ $ta_label }}</strong> (1 Juli {{ $ta_mulai }} &ndash; 30 Juni {{ $ta_mulai + 1 }}).</p>

                <div class="stat-row">
                    <div class="stat-box"><div class="stat-box__label">Total Jurnal</div><div class="stat-box__value">{{ $totalJurnal }}</div></div>
                    <div class="stat-box"><div class="stat-box__label">Hari Mengajar</div><div class="stat-box__value">{{ $totalHariMengajar }}</div></div>
                    <div class="stat-box"><div class="stat-box__label">Kelas Diajar</div><div class="stat-box__value">{{ $totalKelas }}</div></div>
                </div>

                <h2 class="section-title">Rekap per Kelas &amp; Mata Pelajaran</h2>
                <ul class="dash-list">
                    @forelse ($rekapJurnal as $r)
                        <li class="dash-item">
                            <div class="dash-card rekap-card">
                                <div class="rekap-card__top">
                                    <h3 class="rekap-card__title">{{ $r->kelas }} &mdash; {{ $r->nama_mapel }}</h3>
                                    <span class="rekap-card__meta">Terakhir diisi: {{ $r->terakhir_formatted }}</span>
                                </div>
                                <div class="rekap-card__bottom">
                                    <span class="rekap-badge rekap-badge--rate">Jurnal: {{ $r->total_jurnal }}</span>
                                    <span class="rekap-badge rekap-badge--hadir">Pertemuan terakhir: ke-{{ $r->pertemuan_terakhir }}</span>
                                </div>
                            </div>
                        </li>
                    @empty
                        <li class="dash-item" style="display: block;"><p class="empty-note">Belum ada jurnal pada tahun ajaran dan filter ini.</p></li>
                    @endforelse
                </ul>

                <h2 class="section-title">Detail Jurnal</h2>
                <div class="table-scroll">
                    <table class="rekap-table">
                        <thead>
                            <tr>
                                <th class="num">No</th>
                                <th>Tanggal</th>
                                <th>Kelas</th>
                                <th class="num">Jam</th>
                                <th>Mata Pelajaran</th>
                                <th class="num">Pertemuan</th>
                                <th>Sub Kompetensi</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($detailJurnal as $i => $j)
                                <tr>
                                    <td class="num">{{ $i + 1 }}</td>
                                    <td>{{ $j->tanggal_formatted }}</td>
                                    <td>{{ $j->kelas }}</td>
                                    <td class="num">{{ $j->jam_sekolah }}</td>
                                    <td>{{ $j->nama_mapel }}</td>
                                    <td class="num">{{ $j->pertemuan }}</td>
                                    <td>{{ $j->sub_kompetensi }}</td>
                                    <td>{{ $j->keterangan }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="8" class="empty-note">Belum ada jurnal.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Mengajar Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        /* Header Profil Guru */
        .teacher-profile-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: var(--space-3);
        }
        .teacher-profile-name-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.65rem;
        }
        .teacher-profile-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: var(--dash-sidebar);
            color: var(--white);
            display: grid;
            place-items: center;
            flex-shrink: 0;
        }
        [data-theme="dark"] .teacher-profile-avatar {
            background: #3b82f6;
        }
        .teacher-profile-name {
            font-family: var(--font-heading);
            font-size: clamp(1.2rem, 2.8vw, 1.65rem);
            font-weight: 400;
            letter-spacing: 0.03em;
            color: var(--dash-ink);
            text-transform: uppercase;
        }
        .teacher-profile-date {
            font-size: 0.825rem;
            font-weight: 600;
            color: #3b82f6;
            margin-left: 0.25rem;
        }

        /* Section Title Anton */
        .schedule-main-heading {
            font-family: var(--font-heading);
            font-size: clamp(1.35rem, 3.2vw, 1.85rem);
            font-weight: 400;
            letter-spacing: 0.02em;
            color: var(--dash-ink);
            text-transform: uppercase;
            margin: 0 0 var(--space-3) 0;
        }

        /* Hero Schedule Container (Outer Card matching dashboard surface) */
        .hero-schedule-wrapper {
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: 22px;
            padding: 16px;
            box-shadow: var(--dash-shadow);
            margin-bottom: var(--space-4);
            transition: all 0.2s ease;
        }

        /* Hero Schedule Card (Inner Card matching reference layout) */
        .hero-schedule-card {
            background: radial-gradient(circle at 92% 25%, rgba(59, 130, 246, 0.12) 0%, rgba(255, 255, 255, 0) 55%), #ffffff;
            border: 1.5px solid #3b82f6;
            border-radius: 16px;
            padding: 22px 26px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: var(--space-4);
            margin-bottom: 0;
            transition: all 0.2s ease;
        }
        [data-theme="dark"] .hero-schedule-wrapper {
            background: var(--dash-surface);
            border-color: var(--dash-edge);
        }
        [data-theme="dark"] .hero-schedule-card {
            background: radial-gradient(circle at 92% 25%, rgba(96, 165, 250, 0.16) 0%, rgba(37, 47, 66, 0) 55%), var(--dash-surface);
            border-color: #60a5fa;
        }
        .hero-schedule-card__left {
            flex: 1;
            min-width: 0;
        }
        .hero-schedule-card__kicker-row {
            display: flex;
            align-items: center;
            gap: 0.65rem;
            margin-bottom: 0.4rem;
        }
        .hero-schedule-card__kicker {
            font-weight: 800;
            font-size: 0.88rem;
            color: #2563eb;
        }
        [data-theme="dark"] .hero-schedule-card__kicker {
            color: #60a5fa;
        }
        .hero-schedule-card__jam-badge {
            background: var(--dash-surface);
            color: var(--dash-muted);
            border: 1px solid var(--dash-edge);
            padding: 0.15rem 0.65rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 600;
        }
        [data-theme="dark"] .hero-schedule-card__jam-badge {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
            color: #cbd5e1;
        }
        .hero-schedule-card__time {
            font-size: 0.85rem;
            color: var(--dash-muted);
            margin-bottom: 0.35rem;
            font-weight: 500;
        }
        .hero-schedule-card__subject {
            font-family: var(--font-heading);
            font-size: clamp(1.6rem, 3.8vw, 2.35rem);
            font-weight: 400;
            line-height: 1.15;
            letter-spacing: 0.02em;
            text-transform: uppercase;
            color: var(--dash-ink);
            margin: 0 0 0.4rem 0;
        }
        .hero-schedule-card__status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--dash-ink);
        }
        .hero-status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
        }
        .hero-status-dot--ongoing {
            background: #16a34a;
            box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.25);
        }
        .hero-status-dot--upcoming {
            background: #f59e0b;
            box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.25);
        }
        .hero-status-dot--finished {
            background: #2563eb;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.25);
        }

        /* Right section: Target Kelas squircle box */
        .hero-schedule-card__right {
            flex-shrink: 0;
            text-align: center;
            padding: 0.25rem 0.5rem;
            min-width: 130px;
        }
        .hero-target-heading {
            display: block;
            font-size: 0.75rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--dash-ink);
            margin-bottom: 0.4rem;
        }
        .hero-target-squircle {
            width: 78px;
            height: 86px;
            border: 1.5px dashed #60a5fa;
            border-radius: 16px;
            margin: 0 auto 0.45rem auto;
            display: grid;
            place-items: center;
            background: rgba(59, 130, 246, 0.05);
            color: #2563eb;
        }
        [data-theme="dark"] .hero-target-squircle {
            background: rgba(96, 165, 250, 0.12);
            border-color: rgba(96, 165, 250, 0.45);
            color: #60a5fa;
        }
        .hero-target-name {
            font-size: 0.85rem;
            font-weight: 800;
            color: var(--dash-ink);
            line-height: 1.25;
            max-width: 140px;
            margin: 0 auto 0.4rem auto;
        }
        .hero-target-badge {
            display: inline-block;
            padding: 0.18rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.72rem;
            font-weight: 700;
            background: #dcfce7;
            color: #15803d;
            border: 1px solid color-mix(in srgb, #22c55e 30%, transparent);
        }

        /* Tingkat Header & Grouping */
        .tingkat-section {
            margin-top: 1.5rem;
        }
        .tingkat-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0.5rem 0.75rem;
            margin-bottom: 0.75rem;
            border-left: 4px solid #2563eb;
            background: color-mix(in srgb, #2563eb 8%, transparent);
            border-radius: 0 8px 8px 0;
        }
        .tingkat-header__title {
            font-family: var(--font-heading);
            font-size: 1.15rem;
            font-weight: 400;
            letter-spacing: 0.02em;
            text-transform: uppercase;
            color: var(--dash-ink);
            margin: 0;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .tingkat-header__count {
            font-size: 0.775rem;
            font-weight: 700;
            padding: 0.15rem 0.55rem;
            border-radius: var(--radius-pill);
            background: var(--dash-surface);
            color: #2563eb;
            border: 1px solid var(--dash-edge);
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        @include('partials.guru-sidebar', ['aktif' => 'jadwal'])

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @include('partials.flash')

                <!-- 1. IDENTITAS GURU DI KONTEN: NAMA ASLI & TANGGAL HARI INI -->
                <div class="teacher-profile-header">
                    <div class="teacher-profile-name-badge">
                        <div class="teacher-profile-avatar">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                            </svg>
                        </div>
                        <h1 class="teacher-profile-name">{{ $namaGuru }}</h1>
                    </div>
                    <span class="teacher-profile-date">{{ $tanggalHariIni }}</span>
                </div>

                <!-- NOTIFIKASI GURU PIKET HARI INI (TETAP ATAU PENGGANTI) -->
                @if (isset($notifPiket) && $notifPiket)
                    <div style="background: linear-gradient(135deg, #1d4ed8 0%, #2563eb 100%); color: #ffffff; border-radius: 18px; padding: 1.25rem 1.5rem; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: space-between; gap: 1rem; box-shadow: 0 10px 25px -5px rgba(37, 99, 235, 0.4); flex-wrap: wrap;">
                        <div style="display: flex; align-items: center; gap: 1rem; min-width: 0; flex: 1;">
                            <div style="width: 48px; height: 48px; border-radius: 12px; background: rgba(255, 255, 255, 0.2); display: grid; place-items: center; flex-shrink: 0;">
                                <svg width="26" height="26" viewBox="0 0 24 24" fill="#ffffff">
                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/>
                                </svg>
                            </div>
                            <div style="min-width: 0;">
                                <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                    <strong style="font-size: 1.05rem; letter-spacing: 0.01em;">{{ $notifPiket->judul }}</strong>
                                    <span style="font-size: 0.72rem; padding: 0.15rem 0.6rem; border-radius: var(--radius-pill); font-weight: 700; background: #dcfce7; color: #15803d;">
                                        {{ $notifPiket->tipe === 'pengganti' ? 'Piket Pengganti' : 'Piket Terjadwal' }}
                                    </span>
                                </div>
                                <p style="margin: 0.25rem 0 0 0; font-size: 0.875rem; color: #eff6ff; line-height: 1.4;">
                                    {{ $notifPiket->pesan }} {{ $notifPiket->keterangan }}
                                </p>
                            </div>
                        </div>
                        <a href="{{ $notifPiket->link }}" style="display: inline-flex; align-items: center; gap: 0.5rem; background: #ffffff; color: #1d4ed8; font-weight: 700; font-size: 0.85rem; padding: 0.65rem 1.25rem; border-radius: var(--radius-pill); text-decoration: none; transition: transform 0.2s, box-shadow 0.2s; white-space: nowrap; flex-shrink: 0;">
                            <span>Masuk ke Halaman Guru Piket</span>
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M5 13h11.86l-5.43 5.43 1.42 1.42L21.14 12l-8.29-8.29-1.42 1.42L16.86 11H5v2z"/>
                            </svg>
                        </a>
                    </div>
                @endif

                <!-- 2. JUDUL SECTION: JADWAL MENGAJAR HARI INI -->
                <h2 class="schedule-main-heading">JADWAL MENGAJAR HARI INI</h2>

                <!-- 3. HERO CARD JADWAL REAL-TIME HARI INI -->
                @if ($heroJadwal)
                    <div class="hero-schedule-wrapper">
                        <div class="hero-schedule-card">
                            <div class="hero-schedule-card__left">
                                <div class="hero-schedule-card__kicker-row">
                                    <span class="hero-schedule-card__kicker">{{ $heroJadwal->kicker }}</span>
                                    <span class="hero-schedule-card__jam-badge">jam ke {{ $heroJadwal->jam_ke }}</span>
                                </div>
                                <div class="hero-schedule-card__time">{{ $heroJadwal->waktu }}</div>
                                <h3 class="hero-schedule-card__subject">{{ $heroJadwal->mapel }}</h3>
                                <div class="hero-schedule-card__status">
                                    <span class="hero-status-dot hero-status-dot--{{ $heroJadwal->status_slug }}"></span>
                                    <span>{{ $heroJadwal->status_text }} &bull; Kelas {{ $heroJadwal->kelas }}</span>
                                </div>
                            </div>

                            <div class="hero-schedule-card__right">
                                <span class="hero-target-heading">TARGET KELAS</span>
                                <div class="hero-target-squircle">
                                    <svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M12 3L1 9l4 2.18v6L12 21l7-3.82v-6l2-1.09V17h2V9L12 3zm6.82 6L12 12.72 5.18 9 12 5.28 18.82 9zM17 15.99l-5 2.73-5-2.73v-3.72L12 15l5-2.73v3.72z"/>
                                    </svg>
                                </div>
                                <div class="hero-target-name">{{ $heroJadwal->kelas }}</div>
                                <span class="hero-target-badge">
                                    Jadwal Aktif
                                </span>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="hero-schedule-wrapper">
                        <div class="hero-schedule-card">
                            <div class="hero-schedule-card__left">
                                <div class="hero-schedule-card__kicker-row">
                                    <span class="hero-schedule-card__kicker">Informasi Jadwal Mengajar</span>
                                </div>
                                <h3 class="hero-schedule-card__subject">Tidak Ada Jadwal Mengajar Hari Ini</h3>
                                <div class="hero-schedule-card__time">Hari ini tidak ada sesi jam belajar-mengajar aktif untuk Anda.</div>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- 4. DAFTAR JADWAL MENGAJAR MINGGUAN GURU & TAB HARI -->
                <section class="dash-section" aria-labelledby="jadwal-hari-ini-guru">
                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: var(--space-2);">
                        <h2 class="dash-subtitle" id="jadwal-hari-ini-guru" style="margin: 0;">
                            Jadwal Hari {{ ucfirst($hariPilihan) }}
                        </h2>
                        <span style="font-size: 0.85rem; color: var(--dash-muted);">
                            Total Sesi: <strong>{{ $jadwalList->count() }}</strong>
                        </span>
                    </div>

                    <!-- Day-of-week tabs -->
                    <div class="dash-daytabs" role="tablist" aria-label="Pilih hari">
                        @foreach (['senin' => 'Senin', 'selasa' => 'Selasa', 'rabu' => 'Rabu', 'kamis' => 'Kamis', 'jumat' => 'Jumat'] as $key => $label)
                            <a href="{{ route('guru.jadwal', ['hari' => $key]) }}"
                               class="dash-daytab {{ $hariPilihan === $key ? 'is-active' : '' }}"
                               role="tab"
                               aria-selected="{{ $hariPilihan === $key ? 'true' : 'false' }}"
                               style="text-decoration: none; display: inline-flex; align-items: center; justify-content: center;">
                                {{ $label }}
                            </a>
                        @endforeach
                    </div>

                    <!-- Schedule cards separated by class level: Kelas 10, Kelas 11, Kelas 12 -->
                    @php
                        $hasAnyJadwal = $jadwalList->isNotEmpty();
                    @endphp

                    @if ($hasAnyJadwal)
                        @foreach (['10' => 'Kelas 10', '11' => 'Kelas 11', '12' => 'Kelas 12'] as $tingkatKey => $tingkatLabel)
                            @if (!empty($jadwalByTingkat[$tingkatKey]) && $jadwalByTingkat[$tingkatKey]->isNotEmpty())
                                <div class="tingkat-section">
                                    <div class="tingkat-header">
                                        <h3 class="tingkat-header__title">
                                            {{ $tingkatLabel }}
                                        </h3>
                                        <span class="tingkat-header__count">
                                            {{ $jadwalByTingkat[$tingkatKey]->count() }} Sesi
                                        </span>
                                    </div>

                                    <ul class="dash-list">
                                        @foreach ($jadwalByTingkat[$tingkatKey] as $jadwal)
                                            <li>
                                                <div class="dash-jadwal-card {{ $jadwal->is_ongoing ? 'dash-jadwal-card--on' : ($jadwal->is_finished ? 'dash-jadwal-card--done' : 'dash-jadwal-card--off') }}">
                                                    <div class="dash-jadwal-card__info">
                                                        <div style="display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;">
                                                            <span class="dash-jadwal-card__subject">{{ $jadwal->mapel }}</span>
                                                            <span style="font-size: 0.75rem; padding: 0.15rem 0.5rem; border-radius: var(--radius-pill); font-weight: 600; background: var(--dash-hover); color: var(--dash-muted);">
                                                                {{ $jadwal->jam_ke }}
                                                            </span>
                                                            @if ($jadwal->is_ongoing)
                                                                <span style="font-size: 0.75rem; padding: 0.15rem 0.5rem; border-radius: var(--radius-pill); font-weight: 600; background: color-mix(in srgb, #22c55e 20%, transparent); color: #16a34a;">
                                                                    ● Sedang Berlangsung
                                                                </span>
                                                            @elseif ($jadwal->is_finished)
                                                                <span class="tag-selesai">✓ Selesai</span>
                                                            @endif
                                                        </div>
                                                        <span class="dash-jadwal-card__teacher" style="margin-top: 0.25rem;">
                                                            Kelas: <strong>{{ $jadwal->kelas }}</strong>
                                                        </span>
                                                    </div>
                                                    <span class="dash-jadwal-card__time">{{ $jadwal->waktu }}</span>
                                                </div>
                                            </li>
                                        @endforeach
                                    </ul>
                                </div>
                            @endif
                        @endforeach
                    @else
                        <ul class="dash-list" style="margin-top: 1rem;">
                            <li class="dash-item">
                                <div class="dash-card">
                                    <span class="dash-card__name">Tidak ada jadwal mengajar pada hari {{ ucfirst($hariPilihan) }}.</span>
                                </div>
                            </li>
                        </ul>
                    @endif
                </section>
            </div>
        </main>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Kehadiran Guru - Dashboard Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        /* Card Layout untuk Rekap Absensi */
        .rekap-card {
            display: flex;
            flex-direction: column;
            gap: 0.65rem;
            width: 100%;
            padding: 1.1rem 1.35rem;
        }

        .rekap-card__top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .rekap-card__title {
            font-family: var(--font-body);
            font-size: 0.95rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--dash-ink);
            letter-spacing: 0.02em;
            margin: 0;
            line-height: 1.3;
        }

        .rekap-card__meta {
            font-size: 0.8125rem;
            color: var(--dash-muted);
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
        }

        .rekap-card__bottom {
            display: flex;
            align-items: center;
            gap: 0.55rem;
            flex-wrap: wrap;
        }

        .rekap-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.28rem 0.75rem;
            border-radius: var(--radius-pill);
            font-weight: 700;
            font-size: 0.775rem;
            line-height: 1;
            white-space: nowrap;
        }
        .rekap-badge--rate {
            background: #dbeafe;
            color: #1d4ed8;
            border: 1px solid rgba(29, 78, 216, 0.2);
            font-weight: 800;
        }
        [data-theme="dark"] .rekap-badge--rate {
            background: rgba(59, 130, 246, 0.2);
            color: #93c5fd;
            border-color: rgba(59, 130, 246, 0.3);
        }

        .rekap-badge--hadir {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid rgba(21, 128, 61, 0.2);
        }
        [data-theme="dark"] .rekap-badge--hadir {
            background: rgba(34, 197, 94, 0.18);
            color: #86efac;
            border-color: rgba(34, 197, 94, 0.3);
        }

        .rekap-badge--sakit {
            background: #e0f2fe;
            color: #0369a1;
            border: 1px solid rgba(3, 105, 161, 0.2);
        }
        [data-theme="dark"] .rekap-badge--sakit {
            background: rgba(14, 165, 233, 0.18);
            color: #7dd3fc;
            border-color: rgba(14, 165, 233, 0.3);
        }

        .rekap-badge--izin {
            background: #fef3c7;
            color: #b45309;
            border: 1px solid rgba(180, 83, 9, 0.2);
        }
        [data-theme="dark"] .rekap-badge--izin {
            background: rgba(245, 158, 11, 0.18);
            color: #fde68a;
            border-color: rgba(245, 158, 11, 0.3);
        }

        .rekap-badge--alpa {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid rgba(185, 28, 28, 0.2);
        }
        [data-theme="dark"] .rekap-badge--alpa {
            background: rgba(239, 68, 68, 0.18);
            color: #fca5a5;
            border-color: rgba(239, 68, 68, 0.3);
        }
        
        .btn-download-all {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: #16a34a;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.85rem;
            padding: 0.6rem 1.15rem;
            border-radius: var(--radius-pill);
            text-decoration: none;
            transition: all 0.2s;
            border: none;
            box-shadow: 0 2px 4px rgba(22, 163, 74, 0.2);
            white-space: nowrap;
        }
        .btn-download-all:hover {
            background: #15803d;
            transform: translateY(-1px);
        }
        .btn-download-all svg {
            width: 18px;
            height: 18px;
            fill: currentColor;
        }

        @media (max-width: 640px) {
            .rekap-card__top {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.25rem;
            }
            .rekap-card__meta {
                margin-left: 0;
            }
        }

        .stat-row { display: flex; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 1.25rem; }
        .stat-box { flex: 1; min-width: 150px; padding: 0.9rem 1.1rem; background: var(--dash-surface); border: 1px solid var(--dash-edge); border-radius: var(--radius-md); box-shadow: var(--dash-shadow); }
        .stat-box__label { font-size: 0.75rem; font-weight: 600; color: var(--dash-muted); text-transform: uppercase; letter-spacing: 0.03em; }
        .stat-box__value { font-family: var(--font-heading); font-size: 1.7rem; line-height: 1.2; color: var(--dash-ink); }
        .section-title { font-family: var(--font-heading); font-size: 1.15rem; text-transform: uppercase; letter-spacing: 0.02em; margin: 1.5rem 0 0.75rem; }
        .table-scroll { overflow-x: auto; border: 1px solid var(--dash-edge); border-radius: var(--radius-md); background: var(--dash-surface); }
        .rekap-table { width: 100%; border-collapse: collapse; font-size: 0.85rem; min-width: 680px; }
        .rekap-table th { text-align: left; padding: 0.65rem 0.8rem; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.03em; color: var(--dash-muted); border-bottom: 1px solid var(--dash-edge); white-space: nowrap; }
        .rekap-table td { padding: 0.65rem 0.8rem; border-bottom: 1px solid var(--dash-edge); vertical-align: top; color: var(--dash-ink); }
        .rekap-table tr:last-child td { border-bottom: none; }
        .rekap-table .num { text-align: center; white-space: nowrap; }
        .rekap-table tr.baris-saya td { background: color-mix(in srgb, #2563eb 8%, transparent); font-weight: 600; }
        .empty-note { padding: 2rem 1rem; text-align: center; color: var(--dash-muted); }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        @include('partials.guru-sidebar', ['aktif' => 'rekap-kehadiran'])

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @include('partials.flash')
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Rekap Kehadiran Guru</h1>
                    </div>
                    <div class="dash-tools">
                        <form method="GET" action="{{ route('guru.rekap.kehadiran') }}" class="dash-search" role="search">
                            <input type="search" name="q" value="{{ $search }}" placeholder="Cari nama atau mapel..." aria-label="Cari guru">
                            <input type="hidden" name="dari" value="{{ $dari }}">
                            <input type="hidden" name="sampai" value="{{ $sampai }}">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </form>
                        <a href="{{ route('guru.rekap.kehadiran.export', ['dari' => $dari, 'sampai' => $sampai]) }}" class="btn-download-all" title="Unduh rekap kehadiran guru (TA {{ $labelTa }})">
                            <svg viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                            <span>Unduh Excel</span>
                        </a>
                    </div>
                </header>

                <form method="GET" action="{{ route('guru.rekap.kehadiran') }}" class="log-filter" aria-label="Filter periode rekap kehadiran">
                    <input type="hidden" name="q" value="{{ $search }}">
                    <div class="log-filter__field">
                        <label for="filter-dari">Dari tanggal</label>
                        <input type="date" id="filter-dari" name="dari" value="{{ $dari }}">
                    </div>
                    <div class="log-filter__field">
                        <label for="filter-sampai">Sampai tanggal</label>
                        <input type="date" id="filter-sampai" name="sampai" value="{{ $sampai }}">
                    </div>
                    <div class="log-filter__actions">
                        <button type="submit" class="dash-btn">Terapkan</button>
                        <a href="{{ route('guru.rekap.kehadiran') }}" class="dash-btn dash-btn--ghost" style="text-decoration: none;">Bulan Ini</a>
                    </div>
                </form>
                <p class="log-filter__info">Periode <strong>{{ $dariFormatted }}</strong> s.d. <strong>{{ $sampaiFormatted }}</strong> &bull; Tahun ajaran <strong>{{ $labelTa }}</strong></p>

                <div class="stat-row">
                    <div class="stat-box"><div class="stat-box__label">Hadir</div><div class="stat-box__value" style="color: #16a34a;">{{ $ringkasan->hadir }}</div></div>
                    <div class="stat-box"><div class="stat-box__label">Izin</div><div class="stat-box__value" style="color: #ca8a04;">{{ $ringkasan->izin }}</div></div>
                    <div class="stat-box"><div class="stat-box__label">Sakit</div><div class="stat-box__value" style="color: #7c3aed;">{{ $ringkasan->sakit }}</div></div>
                    <div class="stat-box"><div class="stat-box__label">Alpa</div><div class="stat-box__value" style="color: #dc2626;">{{ $ringkasan->alpa }}</div></div>
                </div>

                <div class="table-scroll">
                    <table class="rekap-table">
                        <thead>
                            <tr>
                                <th class="num">No</th>
                                <th>Nama Guru</th>
                                <th>Mata Pelajaran</th>
                                <th class="num">Hadir</th>
                                <th class="num">Izin</th>
                                <th class="num">Sakit</th>
                                <th class="num">Alpa</th>
                                <th class="num">Total Hari</th>
                                <th class="num">Kehadiran</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse ($rekapGuru as $i => $g)
                                <tr class="{{ (string) $g->kode_guru === (string) $kodeGuruSaya ? 'baris-saya' : '' }}">
                                    <td class="num">{{ $i + 1 }}</td>
                                    <td>{{ $g->nama }}@if ((string) $g->kode_guru === (string) $kodeGuruSaya) <small>(Anda)</small>@endif</td>
                                    <td>{{ $g->mapel }}</td>
                                    <td class="num"><span class="status-pill status-pill--hadir">{{ $g->hadir }}</span></td>
                                    <td class="num"><span class="status-pill status-pill--izin">{{ $g->izin }}</span></td>
                                    <td class="num"><span class="status-pill status-pill--sakit">{{ $g->sakit }}</span></td>
                                    <td class="num"><span class="status-pill status-pill--alpa">{{ $g->alpa }}</span></td>
                                    <td class="num">{{ $g->total }}</td>
                                    <td class="num"><strong>{{ $g->persen !== null ? $g->persen . '%' : '-' }}</strong></td>
                                </tr>
                            @empty
                                <tr><td colspan="9" class="empty-note">Tidak ada guru yang cocok dengan pencarian.</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>

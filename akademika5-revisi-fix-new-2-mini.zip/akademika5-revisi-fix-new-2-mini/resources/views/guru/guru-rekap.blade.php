<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Absensi Siswa - Dashboard Guru - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        /* Card Layout untuk Rekap Absensi */
        .rekap-card {
            display: flex;
            flex-direction: column;
            gap: 0.65rem;
            width: 100%;
            padding: 1.1rem 1.35rem;
        }

        .rekap-card__top {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .rekap-card__title {
            font-family: var(--font-body);
            font-size: 0.95rem;
            font-weight: 600;
            text-transform: uppercase;
            color: var(--dash-ink);
            letter-spacing: 0.02em;
            margin: 0;
            line-height: 1.3;
        }

        .rekap-card__meta {
            font-size: 0.8125rem;
            color: var(--dash-muted);
            white-space: nowrap;
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
        }

        .rekap-card__bottom {
            display: flex;
            align-items: center;
            gap: 0.55rem;
            flex-wrap: wrap;
        }

        .rekap-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.28rem 0.75rem;
            border-radius: var(--radius-pill);
            font-weight: 700;
            font-size: 0.775rem;
            line-height: 1;
            white-space: nowrap;
        }
        .rekap-badge--rate {
            background: #dbeafe;
            color: #1d4ed8;
            border: 1px solid rgba(29, 78, 216, 0.2);
            font-weight: 800;
        }
        [data-theme="dark"] .rekap-badge--rate {
            background: rgba(59, 130, 246, 0.2);
            color: #93c5fd;
            border-color: rgba(59, 130, 246, 0.3);
        }

        .rekap-badge--hadir {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid rgba(21, 128, 61, 0.2);
        }
        [data-theme="dark"] .rekap-badge--hadir {
            background: rgba(34, 197, 94, 0.18);
            color: #86efac;
            border-color: rgba(34, 197, 94, 0.3);
        }

        .rekap-badge--sakit {
            background: #e0f2fe;
            color: #0369a1;
            border: 1px solid rgba(3, 105, 161, 0.2);
        }
        [data-theme="dark"] .rekap-badge--sakit {
            background: rgba(14, 165, 233, 0.18);
            color: #7dd3fc;
            border-color: rgba(14, 165, 233, 0.3);
        }

        .rekap-badge--izin {
            background: #fef3c7;
            color: #b45309;
            border: 1px solid rgba(180, 83, 9, 0.2);
        }
        [data-theme="dark"] .rekap-badge--izin {
            background: rgba(245, 158, 11, 0.18);
            color: #fde68a;
            border-color: rgba(245, 158, 11, 0.3);
        }

        .rekap-badge--alpa {
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid rgba(185, 28, 28, 0.2);
        }
        [data-theme="dark"] .rekap-badge--alpa {
            background: rgba(239, 68, 68, 0.18);
            color: #fca5a5;
            border-color: rgba(239, 68, 68, 0.3);
        }
        
        .btn-download-all {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: #16a34a;
            color: #ffffff;
            font-weight: 700;
            font-size: 0.85rem;
            padding: 0.6rem 1.15rem;
            border-radius: var(--radius-pill);
            text-decoration: none;
            transition: all 0.2s;
            border: none;
            box-shadow: 0 2px 4px rgba(22, 163, 74, 0.2);
            white-space: nowrap;
        }
        .btn-download-all:hover {
            background: #15803d;
            transform: translateY(-1px);
        }
        .btn-download-all svg {
            width: 18px;
            height: 18px;
            fill: currentColor;
        }

        @media (max-width: 640px) {
            .rekap-card__top {
                flex-direction: column;
                align-items: flex-start;
                gap: 0.25rem;
            }
            .rekap-card__meta {
                margin-left: 0;
            }
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        @include('partials.guru-sidebar', ['aktif' => 'rekap'])

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Rekap Absensi Setiap Kelas</h1>
                    </div>
                    <div class="dash-tools">
                        <form method="GET" action="{{ route('guru.rekap') }}" class="dash-search" role="search">
                            <input type="search" name="q" value="{{ $search }}" placeholder="Cari kelas..." aria-label="Search class">
                            <input type="hidden" name="ta" value="{{ $ta_mulai }}">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </form>

                        <a href="{{ route('guru.rekap.export', ['kelas' => 'all', 'ta' => $ta_mulai]) }}" class="btn-download-all" title="Unduh format spreadsheet excel semua kelas (TA {{ $ta_label }})">
                            <svg viewBox="0 0 24 24"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
                            <span>Unduh Excel Semua Kelas</span>
                        </a>
                    </div>
                </header>

                <!-- Tahun ajaran: data rekap & file Excel mengikuti tahun ajaran terpilih -->
                <form method="GET" action="{{ route('guru.rekap') }}" class="log-filter" aria-label="Pilih tahun ajaran">
                    <input type="hidden" name="q" value="{{ $search }}">
                    <div class="log-filter__field">
                        <label for="filter-ta">Tahun Ajaran</label>
                        <select id="filter-ta" name="ta" onchange="this.form.submit()">
                            @foreach (collect($ta_daftar)->push($ta_mulai)->unique()->sortDesc() as $th)
                                <option value="{{ $th }}" {{ $th === $ta_mulai ? 'selected' : '' }}>{{ $th }}/{{ $th + 1 }}</option>
                            @endforeach
                        </select>
                    </div>
                    <noscript><button type="submit" class="dash-btn">Terapkan</button></noscript>
                </form>
                <p class="log-filter__info">Rekap untuk tahun ajaran <strong>{{ $ta_label }}</strong> (1 Juli {{ $ta_mulai }} &ndash; 30 Juni {{ $ta_mulai + 1 }}).</p>

                <ul class="dash-list">
                    @forelse($rekapPerKelas as $item)
                        <li class="dash-item">
                            <div class="dash-card rekap-card">
                                <div class="rekap-card__top">
                                    <h2 class="rekap-card__title">Rekap Absensi {{ $item->kelas }}</h2>
                                    <span class="rekap-card__meta">{{ $item->total_siswa }} Siswa &bull; {{ $item->total_hari }} Hari Presensi</span>
                                </div>
                                
                                <div class="rekap-card__bottom">
                                    <span class="rekap-badge rekap-badge--rate">Kehadiran: {{ $item->persen !== null ? $item->persen . '%' : '-' }}</span>
                                    <span class="rekap-badge rekap-badge--hadir">Hadir: {{ $item->hadir }}</span>
                                    <span class="rekap-badge rekap-badge--sakit">Sakit: {{ $item->sakit }}</span>
                                    <span class="rekap-badge rekap-badge--izin">Izin: {{ $item->izin }}</span>
                                    <span class="rekap-badge rekap-badge--alpa">Alpa: {{ $item->alpa }}</span>
                                </div>
                            </div>
                            <a href="{{ route('guru.rekap.export', ['kelas' => $item->kelas, 'ta' => $ta_mulai]) }}" class="dash-action" aria-label="Unduh rekap absensi {{ $item->kelas }}" title="Download spreadsheet (.xls) kelas {{ $item->kelas }}" style="text-decoration: none; display: flex; align-items: center; justify-content: center;">
                                <img class="dash-icon" src="{{ asset('media/vector/download-icon.png') }}" alt="" width="24" height="24">
                            </a>
                        </li>
                    @empty
                        <li class="dash-item" style="padding: 2.5rem 1rem; text-align: center; color: var(--dash-muted); display: block;">
                            <p style="font-size: 0.95rem;">Tidak ada data kelas yang cocok dengan pencarian.</p>
                        </li>
                    @endforelse
                </ul>
            </div>
        </main>
    </div>
</body>
</html>

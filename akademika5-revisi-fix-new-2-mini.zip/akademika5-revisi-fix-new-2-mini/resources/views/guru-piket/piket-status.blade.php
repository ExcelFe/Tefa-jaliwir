<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Guru - Dashboard Guru Piket - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .dash-card--status {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: var(--space-3);
            width: 100%;
            padding: var(--space-3) var(--space-4);
        }
        .dash-card__content {
            flex: 1;
            min-width: 0;
        }
        .dash-card__teaching {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-top: 0.35rem;
            font-size: 0.875rem;
            color: var(--dash-muted);
        }
        .dash-card__teaching-badge {
            display: inline-block;
            padding: 0.15rem 0.6rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 600;
            background: color-mix(in srgb, var(--dash-accent) 18%, transparent);
            color: var(--dash-accent);
            border: 1px solid color-mix(in srgb, var(--dash-accent) 30%, transparent);
            white-space: nowrap;
        }
        .dash-card__right-actions {
            display: flex;
            align-items: center;
            gap: var(--space-3);
            flex-shrink: 0;
        }
        .btn-detail-jadwal {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.45rem 0.9rem;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: var(--radius-pill);
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            color: var(--dash-ink);
            cursor: pointer;
            transition: all 0.15s ease;
            white-space: nowrap;
        }
        .btn-detail-jadwal:hover {
            background: var(--dash-hover);
            border-color: var(--dash-accent);
            color: var(--dash-accent);
        }
        .date-banner-info {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: var(--space-2);
            padding: var(--space-3) var(--space-4);
            margin-bottom: var(--space-4);
            border: 1px solid var(--dash-edge);
            border-radius: var(--radius-md);
            background: var(--dash-surface);
            box-shadow: var(--dash-shadow);
        }
        .date-banner-info__day {
            font-family: var(--font-heading);
            font-size: 1.25rem;
            text-transform: uppercase;
            letter-spacing: 0.02em;
        }
        .date-banner-info__meta {
            font-size: 0.85rem;
            color: var(--dash-muted);
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru piket">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru piket">
                <a class="dash-menu__item" href="{{ route('piket.status') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="{{ route('piket.absen') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24">
                    Absen Guru
                </a>
                <a class="dash-menu__item" href="{{ route('piket.jadwal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                     <span class="dash-account__name">{{ session('nama_guru') ?? session('email_akun') ?? 'Guru Piket' }}</span>
            
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-piket-status').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-piket-status" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>


        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Status Guru</h1>
                    </div>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search name" aria-label="Search name" id="search-guru" oninput="filterGuruList()">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </div>
                        <button type="button" class="dash-icon-btn" aria-label="Filter" onclick="toggleFilterStatus()">
                            <img class="dash-icon" src="{{ asset('media/vector/filter-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>

                <!-- Tanggal Hari Ini Banner -->
                <div class="date-banner-info">
                    <div>
                        <div class="date-banner-info__day">{{ $tanggalHariIni }}</div>
                        <div class="date-banner-info__meta">Jadwal Aktif Hari: <strong style="text-transform: capitalize;">{{ $hariDb }}</strong> &bull; Total Guru Terdaftar: <strong>{{ count($dataGuruStatus) }}</strong></div>
                    </div>
                    <div>
                        @include('partials.status-guru-legend', ['data' => $dataGuruStatus, 'kolom' => 'status_absen'])
                    </div>
                </div>

                <!-- Daftar Status Semua Guru -->
                <ul class="dash-list" id="guru-status-list">
                    @forelse ($dataGuruStatus as $item)
                        @php $statusSlug = \App\Support\StatusGuru::slug($item->status_absen); @endphp
                        <li class="guru-item-card" data-nama="{{ strtolower($item->nama) }}" data-status="{{ $statusSlug }}" style="list-style: none;">
                            <div class="dash-jadwal-card dash-jadwal-card--st-{{ $statusSlug }}">
                                <div class="dash-jadwal-card__info">
                                    <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                        <span class="dash-jadwal-card__subject">{{ $item->nama }}</span>
                                        <span class="status-pill status-pill--{{ $statusSlug }}">
                                            {{ $item->status_absen }}
                                        </span>
                                    </div>
                                    <span class="dash-card__teaching">
                                        <span class="dash-card__teaching-badge">Sedang Mengajar:</span>
                                        <span>{{ $item->sedang_ngajar }}</span>
                                    </span>
                                </div>

                                <div class="dash-card__right-actions">
                                    <span class="dash-jadwal-card__time">{{ $tanggalHariIni }}</span>
                                    <button type="button" class="btn-detail-jadwal" data-modal-open="modal-jadwal-{{ $item->kode_guru }}" aria-label="Lihat jadwal mengajar {{ $item->nama }} hari ini">
                                        <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="16" height="16" style="width: 1rem; height: 1rem;">
                                        Detail
                                    </button>
                                </div>
                            </div>
                        </li>

                        <!-- Modal Detail Jadwal Guru Hari Ini (tanpa pindah halaman) -->
                        <div class="dash-modal" id="modal-jadwal-{{ $item->kode_guru }}" role="dialog" aria-modal="true" aria-labelledby="modal-jadwal-title-{{ $item->kode_guru }}">
                            <div class="dash-modal__box dash-modal__box--wide" tabindex="-1">
                                <div class="dash-modal__head" style="border-bottom: 1px solid var(--dash-edge);">
                                    <h2 class="dash-modal__title" id="modal-jadwal-title-{{ $item->kode_guru }}">Jadwal Mengajar Hari Ini</h2>
                                    <p style="margin: 0.25rem 0 0; color: var(--dash-muted); font-size: 0.9rem;">
                                        <strong>{{ $item->nama }}</strong> &bull; {{ $tanggalHariIni }}
                                    </p>
                                </div>
                                <div class="dash-modal__body dash-modal__body--table" style="padding-top: 1rem;">
                                    <table class="dash-table">
                                        <caption class="dash-sr">Jadwal Mengajar {{ $item->nama }} Hari Ini</caption>
                                        <thead>
                                            <tr>
                                                <th scope="col" style="width: 4rem;">Jam Ke</th>
                                                <th scope="col" style="width: 8rem;">Waktu</th>
                                                <th scope="col">Mata Pelajaran</th>
                                                <th scope="col" style="width: 8rem;">Kelas</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @forelse ($item->jadwal_hari_ini as $jadwal)
                                                <tr>
                                                    <td>{{ $jadwal->jam_sekolah ?? '-' }}</td>
                                                    <td style="font-weight: 600;">{{ $jadwal->waktu_pelajaran ?? ($jadwal->jam_mulai . ' - ' . $jadwal->jam_selesai) }}</td>
                                                    <td class="dash-table__name" style="font-weight: 600;">{{ $jadwal->nama_mapel }}</td>
                                                    <td>
                                                        <span style="display: inline-block; padding: 0.2rem 0.6rem; border-radius: var(--radius-pill); font-weight: 600; font-size: 0.8rem; background: var(--dash-hover);">
                                                            {{ $jadwal->kelas }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            @empty
                                                <tr>
                                                    <td colspan="4" style="padding: 2.5rem 1rem; color: var(--dash-muted); text-align: center;">
                                                        Tidak ada jadwal mengajar pada hari {{ ucfirst($hariDb) }}.
                                                    </td>
                                                </tr>
                                            @endforelse
                                        </tbody>
                                    </table>
                                </div>
                                <div class="dash-modal__foot" style="border-top: 1px solid var(--dash-edge);">
                                    <button type="button" class="dash-btn" data-modal-close>Tutup</button>
                                </div>
                            </div>
                        </div>
                    @empty
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Belum ada data guru terdaftar.</span>
                            </div>
                        </li>
                    @endforelse
                </ul>
            </div>
        </main>
    </div>

    <script>
        function filterGuruList() {
            const input = document.getElementById('search-guru');
            const filter = input.value.toLowerCase().trim();
            const items = document.querySelectorAll('.guru-item-card');

            items.forEach(item => {
                const nama = item.getAttribute('data-nama') || '';
                if (nama.indexOf(filter) > -1) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        const urutanFilterStatus = ['all', 'hadir', 'izin', 'sakit', 'alpa', 'belum'];
        const labelFilterStatus = { all: 'Semua status', hadir: 'Hadir', izin: 'Izin', sakit: 'Sakit', alpa: 'Alpa', belum: 'Belum Diabsen' };
        let filterHadirState = 'all';
        function toggleFilterStatus() {
            const idx = urutanFilterStatus.indexOf(filterHadirState);
            filterHadirState = urutanFilterStatus[(idx + 1) % urutanFilterStatus.length];

            document.querySelectorAll('.guru-item-card').forEach(item => {
                const status = item.getAttribute('data-status');
                item.style.display = (filterHadirState === 'all' || filterHadirState === status) ? '' : 'none';
            });

            const tombol = document.querySelector('[onclick="toggleFilterStatus()"]');
            if (tombol) {
                tombol.setAttribute('title', 'Filter status: ' + labelFilterStatus[filterHadirState] + ' (klik untuk ganti)');
            }
        }
    </script>
</body>
</html>

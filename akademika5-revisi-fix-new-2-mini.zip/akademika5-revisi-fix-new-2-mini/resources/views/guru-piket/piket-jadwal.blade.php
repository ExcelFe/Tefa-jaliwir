<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal - Dashboard Guru Piket - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .class-selector-wrap {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: var(--space-2);
            margin-bottom: var(--space-4);
            padding: var(--space-3) var(--space-4);
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: var(--radius-md);
            box-shadow: var(--dash-shadow);
        }
        .class-badge {
            display: inline-block;
            padding: 0.25rem 0.75rem;
            border-radius: var(--radius-pill);
            background: color-mix(in srgb, var(--dash-accent) 15%, transparent);
            color: var(--dash-accent);
            font-weight: 700;
            font-size: 0.9rem;
        }
        .class-select-form select {
            padding: 0.4rem 0.8rem;
            border-radius: var(--radius-pill);
            border: 1px solid var(--dash-edge);
            background: var(--dash-surface);
            color: var(--dash-ink);
            font: inherit;
            font-size: 0.85rem;
            outline: none;
            cursor: pointer;
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru piket">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru piket">
                <a class="dash-menu__item" href="{{ route('piket.status') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="{{ route('piket.absen') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24">
                    Absen Guru
                </a>
                <a class="dash-menu__item" href="{{ route('piket.jadwal') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <span class="dash-account__name">{{ session('nama_guru') ?? session('email_akun') ?? 'Guru Piket' }}</span>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-piket-jadwal').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-piket-jadwal" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Jadwal Pelajaran</h1>
                    </div>
                </header>

                <!-- Class selector -->
                <div class="class-selector-wrap">
                    <div style="display: flex; align-items: center; gap: 0.75rem;">
                        <span style="font-size: 0.9rem; color: var(--dash-muted);">Kelas Terpilih:</span>
                        <span class="class-badge">{{ $kelasPilihan }}</span>
                    </div>

                    @if (isset($daftarKelas) && $daftarKelas->count() > 0)
                        <form method="GET" action="{{ route('piket.jadwal') }}" class="class-select-form" style="display: flex; align-items: center; gap: 0.5rem;">
                            <input type="hidden" name="hari" value="{{ $hariPilihan }}">
                            <label for="select-kelas" style="font-size: 0.85rem; color: var(--dash-muted);">Pilih Kelas:</label>
                            <select id="select-kelas" name="kelas" onchange="this.form.submit()">
                                @foreach ($daftarKelas as $k)
                                    <option value="{{ $k }}" {{ $kelasPilihan === $k ? 'selected' : '' }}>{{ $k }}</option>
                                @endforeach
                            </select>
                        </form>
                    @endif
                </div>

                <section class="dash-section" aria-labelledby="jadwal-hari-ini-piket">
                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: var(--space-2);">
                        <h2 class="dash-subtitle" id="jadwal-hari-ini-piket" style="margin: 0;">
                            Jadwal Hari {{ ucfirst($hariPilihan) }}
                        </h2>
                        <span style="font-size: 0.85rem; color: var(--dash-muted);">
                            Total Mapel: <strong>{{ $jadwalList->count() }}</strong>
                        </span>
                    </div>

                    <!-- Day-of-week tabs -->
                    <div class="dash-daytabs" role="tablist" aria-label="Pilih hari">
                        @foreach (['senin' => 'Senin', 'selasa' => 'Selasa', 'rabu' => 'Rabu', 'kamis' => 'Kamis', 'jumat' => 'Jumat'] as $key => $label)
                            <a href="{{ route('piket.jadwal', ['hari' => $key, 'kelas' => $kelasPilihan]) }}"
                               class="dash-daytab {{ $hariPilihan === $key ? 'is-active' : '' }}"
                               role="tab"
                               aria-selected="{{ $hariPilihan === $key ? 'true' : 'false' }}"
                               style="text-decoration: none; display: inline-flex; align-items: center; justify-content: center;">
                                {{ $label }}
                            </a>
                        @endforeach
                    </div>

                    <!-- Schedule cards from database -->
                    <ul class="dash-list">
                        @forelse ($jadwalList as $jadwal)
                            <li>
                                <div class="dash-jadwal-card {{ $jadwal->is_ongoing ? 'dash-jadwal-card--on' : ($jadwal->is_finished ? 'dash-jadwal-card--done' : 'dash-jadwal-card--off') }}">
                                    <div class="dash-jadwal-card__info">
                                        <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                            <span class="dash-jadwal-card__subject">{{ $jadwal->nama_mapel }}</span>
                                            <span style="font-size: 0.75rem; padding: 0.15rem 0.5rem; border-radius: var(--radius-pill); font-weight: 600; background: var(--dash-hover); color: var(--dash-muted);">
                                                Jam ke-{{ $jadwal->jam_sekolah }}
                                            </span>
                                            @if ($jadwal->is_ongoing)
                                                <span style="font-size: 0.75rem; padding: 0.15rem 0.5rem; border-radius: var(--radius-pill); font-weight: 600; background: color-mix(in srgb, #22c55e 20%, transparent); color: #16a34a;">
                                                    ● Sedang Berlangsung
                                                </span>
                                            @elseif ($jadwal->is_finished)
                                                <span class="tag-selesai">✓ Selesai</span>
                                            @endif
                                        </div>
                                        <span class="dash-jadwal-card__teacher" style="margin-top: 0.25rem;">
                                            Pengajar: <strong>{{ $jadwal->nama_guru }}</strong>
                                        </span>
                                    </div>
                                    <span class="dash-jadwal-card__time">{{ $jadwal->waktu_pelajaran }}</span>
                                </div>
                            </li>
                        @empty
                            <li class="dash-item">
                                <div class="dash-card">
                                    <span class="dash-card__name">Tidak ada jadwal pelajaran untuk kelas {{ $kelasPilihan }} pada hari {{ ucfirst($hariPilihan) }}.</span>
                                </div>
                            </li>
                        @endforelse
                    </ul>
                </section>
            </div>
        </main>
    </div>
</body>
</html>

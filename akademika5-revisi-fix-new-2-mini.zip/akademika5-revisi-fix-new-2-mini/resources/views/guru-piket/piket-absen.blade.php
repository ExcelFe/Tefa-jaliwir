<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absen Guru - Dashboard Guru Piket - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}?v={{ filemtime(public_path('css/main.css')) }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}?v={{ filemtime(public_path('js/main.js')) }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .alert-success-piket {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: var(--space-3) var(--space-4);
            margin-bottom: var(--space-4);
            background: color-mix(in srgb, #22c55e 15%, transparent);
            border: 1px solid color-mix(in srgb, #22c55e 40%, transparent);
            border-radius: var(--radius-md);
            color: #15803d;
            font-weight: 600;
        }
        .alert-error-piket {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: var(--space-3) var(--space-4);
            margin-bottom: var(--space-4);
            background: color-mix(in srgb, #ef4444 15%, transparent);
            border: 1px solid color-mix(in srgb, #ef4444 40%, transparent);
            border-radius: var(--radius-md);
            color: #b91c1c;
            font-weight: 600;
        }
        .modal-date-picker {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--dash-surface);
            padding: 0.35rem 0.75rem;
            border: 1px solid var(--dash-edge);
            border-radius: var(--radius-pill);
        }
        .modal-date-picker input[type="date"] {
            border: none;
            background: transparent;
            font: inherit;
            color: var(--dash-ink);
            outline: none;
            font-size: 0.85rem;
            cursor: pointer;
        }
        .absen-stats-tag {
            display: inline-block;
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.15rem 0.55rem;
            border-radius: var(--radius-pill);
            margin-right: 0.35rem;
            margin-top: 0.25rem;
        }
        .absen-stats-tag--hadir {
            background: #dcfce7;
            color: #15803d;
        }
        .absen-stats-tag--izin {
            background: #fef9c3;
            color: #a16207;
        }
        .absen-stats-tag--sakit {
            background: #e0f2fe;
            color: #0369a1;
        }
        .absen-stats-tag--alpa {
            background: #fee2e2;
            color: #b91c1c;
        }
        .piket-radio {
            appearance: none;
            -webkit-appearance: none;
            width: 1.35rem;
            height: 1.35rem;
            border-radius: 50%;
            cursor: pointer;
            vertical-align: middle;
            transition: all 0.15s ease;
            display: inline-grid;
            place-content: center;
        }
        .piket-radio::after {
            content: "";
            width: 0.55rem;
            height: 0.55rem;
            border-radius: 50%;
            background: var(--white);
            transform: scale(0);
            transition: transform 0.15s ease;
        }
        .piket-radio:checked::after {
            transform: scale(1);
        }
        .piket-radio--hadir {
            box-shadow: inset 0 0 0 2px #22c55e;
        }
        .piket-radio--hadir:checked {
            background: #22c55e;
            box-shadow: none;
        }
        .piket-radio--izin {
            box-shadow: inset 0 0 0 2px #eab308;
        }
        .piket-radio--izin:checked {
            background: #eab308;
            box-shadow: none;
        }
        .piket-radio--sakit {
            box-shadow: inset 0 0 0 2px #0284c7;
        }
        .piket-radio--sakit:checked {
            background: #0284c7;
            box-shadow: none;
        }
        .piket-radio--alpa {
            box-shadow: inset 0 0 0 2px #ef4444;
        }
        .piket-radio--alpa:checked {
            background: #ef4444;
            box-shadow: none;
        }
        .dash-action-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .btn-delete-piket-absen {
            background: none;
            border: none;
            color: #ef4444;
            cursor: pointer;
            padding: 0.4rem;
            border-radius: var(--radius-sm);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            transition: background 0.15s ease, transform 0.15s ease;
        }
        .btn-delete-piket-absen:hover {
            background: #fee2e2;
            transform: scale(1.1);
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu guru piket">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman guru piket">
                <a class="dash-menu__item" href="{{ route('piket.status') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
                <a class="dash-menu__item" href="{{ route('piket.absen') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24">
                    Absen Guru
                </a>
                <a class="dash-menu__item" href="{{ route('piket.jadwal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
            </nav>

            <div class="dash-account">
                <div class="dash-account__info">
                    <span class="dash-avatar"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <span class="dash-account__name">{{ session('nama_guru') ?? session('email_akun') ?? 'Guru Piket' }}</span>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-piket-absen').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-piket-absen" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Log Absensi Guru</h1>
                    </div>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search log..." aria-label="Search log" id="search-log" oninput="filterLogs()">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </div>
                        <button type="button" class="dash-btn" id="btn-open-modal-add" data-modal-open="modal-absen">
                            {{ $sudahAbsen ? 'Edit Absensi Hari Ini' : 'Mulai Absensi' }}
                            <img class="dash-icon" src="{{ asset('media/vector/add-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>

                <!-- Filter Log Absensi Guru: rentang tanggal + status -->
                <form method="GET" action="{{ route('piket.absen') }}" class="log-filter" aria-label="Filter log absensi guru">
                    <div class="log-filter__field">
                        <label for="filter-dari">Dari tanggal</label>
                        <input type="date" id="filter-dari" name="dari" value="{{ $filterDari }}">
                    </div>
                    <div class="log-filter__field">
                        <label for="filter-sampai">Sampai tanggal</label>
                        <input type="date" id="filter-sampai" name="sampai" value="{{ $filterSampai }}">
                    </div>
                    <div class="log-filter__field">
                        <label for="filter-status">Memuat status</label>
                        <select id="filter-status" name="status">
                            <option value="">Semua status</option>
                            <option value="H" {{ $filterStatus === 'H' ? 'selected' : '' }}>Hadir</option>
                            <option value="I" {{ $filterStatus === 'I' ? 'selected' : '' }}>Izin</option>
                            <option value="S" {{ $filterStatus === 'S' ? 'selected' : '' }}>Sakit</option>
                            <option value="A" {{ $filterStatus === 'A' ? 'selected' : '' }}>Alpa</option>
                        </select>
                    </div>
                    <div class="log-filter__actions">
                        <button type="submit" class="dash-btn">Terapkan</button>
                        <a href="{{ route('piket.absen') }}" class="dash-btn dash-btn--ghost" style="text-decoration: none;">Reset</a>
                    </div>
                </form>
                <p class="log-filter__info">Menampilkan <strong>{{ $logAbsensi->count() }}</strong> log absensi.</p>

                @if (session('sukses'))
                    <div class="alert-success-piket">
                        <span>{{ session('sukses') }}</span>
                        <button type="button" onclick="this.parentElement.remove()" style="background:none; border:none; color:inherit; cursor:pointer; font-weight:bold; font-size:1.2rem;">&times;</button>
                    </div>
                @endif

                @if (session('error'))
                    <div class="alert-error-piket">
                        <span>{{ session('error') }}</span>
                        <button type="button" onclick="this.parentElement.remove()" style="background:none; border:none; color:inherit; cursor:pointer; font-weight:bold; font-size:1.2rem;">&times;</button>
                    </div>
                @endif

                <ul class="dash-list" id="log-list">
                    @forelse ($logAbsensi as $item)
                        <li class="dash-item log-item" data-meta="{{ strtolower($item->tanggal_formatted . ' ' . $item->tanggal) }}">
                            <div class="dash-card">
                                <span class="dash-card__name">Absensi Guru</span>
                                <span class="dash-card__meta" style="font-weight: 600;">{{ $item->tanggal_formatted }}</span>
                                <div style="margin-top: 0.35rem;">
                                    <span class="absen-stats-tag absen-stats-tag--hadir">Hadir: {{ $item->hadir }}</span>
                                    <span class="absen-stats-tag absen-stats-tag--izin">Izin: {{ $item->izin }}</span>
                                    <span class="absen-stats-tag absen-stats-tag--sakit">Sakit: {{ $item->sakit }}</span>
                                    <span class="absen-stats-tag absen-stats-tag--alpa">Alpa: {{ $item->alpa }}</span>
                                </div>
                            </div>
                            <div class="dash-action-group">
                                <a href="{{ route('piket.absen.detail', ['tanggal' => $item->tanggal]) }}" class="dash-action" aria-label="Lihat detail absensi guru, {{ $item->tanggal_formatted }}" title="Lihat Detail Absensi">
                                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="22" height="22">
                                </a>
                                <button type="button" class="dash-action btn-edit-log" data-tanggal="{{ $item->tanggal }}" aria-label="Edit absensi guru, {{ $item->tanggal_formatted }}" title="Edit Absensi">
                                    <img class="dash-icon" src="{{ asset('media/vector/edit-icon.png') }}" alt="" width="22" height="22">
                                </button>
                                <form action="{{ route('piket.absen.hapus') }}" method="POST" onsubmit="return confirm('Apakah Anda yakin ingin menghapus seluruh log absensi guru pada tanggal {{ $item->tanggal_formatted }}?');" style="display:inline;">
                                    @csrf
                                    @method('DELETE')
                                    <input type="hidden" name="tanggal" value="{{ $item->tanggal }}">
                                    <button type="submit" class="btn-delete-piket-absen" title="Hapus Log Absensi">
                                        <svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg>
                                    </button>
                                </form>
                            </div>
                        </li>
                    @empty
                        <li class="dash-item" style="padding: 2.5rem 1rem; text-align: center; color: var(--dash-muted); display: block;">
                            <p style="font-size: 0.95rem;">Belum ada riwayat absensi guru.</p>
                            <small>Klik tombol <strong>"Mulai Absensi"</strong> di atas untuk memulai pencatatan kehadiran guru.</small>
                        </li>
                    @endforelse
                </ul>
            </div>
        </main>
    </div>

    <!-- Pop-up: Form Mulai / Edit Absensi Guru (Real data dari database) -->
    <div class="dash-modal" id="modal-absen" role="dialog" aria-modal="true" aria-labelledby="modal-absen-title">
        <form class="dash-modal__box dash-modal__box--wide" id="form-piket-absen" action="{{ route('piket.absen.simpan') }}" method="post" tabindex="-1" novalidate>
            @csrf
            <button type="button" class="dash-modal__close" data-modal-close aria-label="Tutup">&times;</button>
            <div class="dash-modal__head" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem; border-bottom: 1px solid var(--dash-edge);">
                <div>
                    <h2 class="dash-modal__title" id="modal-absen-title">
                        {{ $sudahAbsen ? 'Edit Absensi Guru' : 'Mulai Absensi Guru' }}
                    </h2>
                    <p id="modal-absen-subtitle" style="margin: 0.2rem 0 0; color: var(--dash-muted); font-size: 0.85rem;">
                        {{ $tanggalHariIni }} &bull; Total Guru Terdaftar: {{ count($guruList) }}
                    </p>
                </div>
                <div style="display: flex; align-items: center; gap: 1rem; flex-wrap: wrap;">
                    <label style="display: flex; align-items: center; gap: 0.4rem; cursor: pointer; font-size: 0.85rem; font-weight: 600; color: #15803d;">
                        <input class="dash-check dash-check--ok" type="checkbox" id="check-semua-hadir" style="width: 1.25rem; height: 1.25rem;">
                        <span>Semua Hadir (Nihil)</span>
                    </label>
                    <div class="modal-date-picker">
                        <label for="tanggal_input" style="font-size: 0.8rem; font-weight: 600; color: var(--dash-muted);">Tanggal:</label>
                        <input type="date" id="tanggal_input" name="tanggal" value="{{ date('Y-m-d') }}" required>
                    </div>
                </div>
            </div>
            <div class="dash-modal__body dash-modal__body--table" style="max-height: 55vh; overflow-y: auto;">
                <table class="dash-table">
                    <caption class="dash-sr">Daftar kehadiran guru</caption>
                    <thead>
                        <tr>
                            <th scope="col" rowspan="2" style="width: 3.5rem; text-align: center;">No.</th>
                            <th scope="col" rowspan="2" class="dash-table__name">Nama Guru</th>
                            <th scope="colgroup" colspan="4" style="text-align: center;">Kehadiran</th>
                        </tr>
                        <tr>
                            <th scope="col" style="width: 5rem; text-align: center; color: #15803d;">Hadir</th>
                            <th scope="col" style="width: 5rem; text-align: center; color: #a16207;">Izin</th>
                            <th scope="col" style="width: 5rem; text-align: center; color: #0369a1;">Sakit</th>
                            <th scope="col" style="width: 5rem; text-align: center; color: #b91c1c;">Alpa</th>
                        </tr>
                    </thead>
                    <tbody id="tbody-guru-absen">
                        @foreach ($guruList as $index => $guru)
                            @php
                                $absenRecord = $absenHariIni[$guru->kode_guru] ?? null;
                                $currentStatus = $absenRecord ? strtoupper($absenRecord->status) : 'H';
                            @endphp
                            <tr class="guru-row" data-kodeguru="{{ $guru->kode_guru }}">
                                <td style="text-align: center;">{{ $index + 1 }}</td>
                                <td class="dash-table__name" style="font-weight: 600;">
                                    {{ $guru->nama }}
                                    @if (!empty($guru->mapel))
                                        <div style="font-size: 0.75rem; color: var(--dash-muted); font-weight: normal;">{{ $guru->mapel }}</div>
                                    @endif
                                </td>
                                <td style="text-align: center;">
                                    <input class="piket-radio piket-radio--hadir" type="radio" name="kehadiran[{{ $guru->kode_guru }}]" value="H" {{ $currentStatus === 'H' ? 'checked' : '' }} aria-label="Hadir: {{ $guru->nama }}">
                                </td>
                                <td style="text-align: center;">
                                    <input class="piket-radio piket-radio--izin" type="radio" name="kehadiran[{{ $guru->kode_guru }}]" value="I" {{ $currentStatus === 'I' ? 'checked' : '' }} aria-label="Izin: {{ $guru->nama }}">
                                </td>
                                <td style="text-align: center;">
                                    <input class="piket-radio piket-radio--sakit" type="radio" name="kehadiran[{{ $guru->kode_guru }}]" value="S" {{ $currentStatus === 'S' ? 'checked' : '' }} aria-label="Sakit: {{ $guru->nama }}">
                                </td>
                                <td style="text-align: center;">
                                    <input class="piket-radio piket-radio--alpa" type="radio" name="kehadiran[{{ $guru->kode_guru }}]" value="A" {{ $currentStatus === 'A' ? 'checked' : '' }} aria-label="Alpa: {{ $guru->nama }}">
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <div class="dash-modal__foot" style="border-top: 1px solid var(--dash-edge);">
                <button type="button" class="dash-btn dash-btn--ghost" data-modal-close>Batal</button>
                <button type="submit" class="dash-btn" id="btn-submit-absen">Simpan Absensi</button>
            </div>
        </form>
    </div>

    <script>
        function filterLogs() {
            const input = document.getElementById('search-log');
            const filter = input.value.toLowerCase().trim();
            const items = document.querySelectorAll('.log-item');

            items.forEach(item => {
                const meta = item.getAttribute('data-meta') || '';
                if (meta.indexOf(filter) > -1) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        document.addEventListener('DOMContentLoaded', () => {
            const modal = document.getElementById('modal-absen');
            const dateInput = document.getElementById('tanggal_input');
            const modalTitle = document.getElementById('modal-absen-title');
            const modalSubtitle = document.getElementById('modal-absen-subtitle');
            const checkSemuaHadir = document.getElementById('check-semua-hadir');

            // Fitur centang semua hadir
            if (checkSemuaHadir) {
                checkSemuaHadir.addEventListener('change', () => {
                    if (checkSemuaHadir.checked) {
                        document.querySelectorAll('#tbody-guru-absen .piket-radio--hadir').forEach(r => {
                            r.checked = true;
                        });
                    }
                });
            }

            // Uncheck "Semua Hadir" jika ada radio selain hadir yang diklik
            document.querySelectorAll('#tbody-guru-absen input[type="radio"]').forEach(radio => {
                radio.addEventListener('change', () => {
                    if (radio.value !== 'H' && checkSemuaHadir) {
                        checkSemuaHadir.checked = false;
                    }
                });
            });

            // Ambil data absensi via AJAX saat tanggal diganti di dalam modal
            async function loadAbsenForDate(dateVal) {
                try {
                    const res = await fetch(`{{ route('piket.absen.data') }}?tanggal=${encodeURIComponent(dateVal)}`);
                    const data = await res.json();

                    if (data.exists) {
                        modalTitle.textContent = `Edit Absensi Guru (${data.tanggal_formatted})`;
                        modalSubtitle.innerHTML = `<strong>${data.tanggal_formatted}</strong> &bull; Mode Pembaruan Data`;
                        let allHadir = true;

                        for (const [kodeGuru, status] of Object.entries(data.absensi)) {
                            const radio = document.querySelector(`input[name="kehadiran[${kodeGuru}]"][value="${status}"]`);
                            if (radio) {
                                radio.checked = true;
                            }
                            if (status !== 'H') allHadir = false;
                        }
                        if (checkSemuaHadir) checkSemuaHadir.checked = allHadir;
                    } else {
                        modalTitle.textContent = `Mulai Absensi Guru (${data.tanggal_formatted})`;
                        modalSubtitle.innerHTML = `<strong>${data.tanggal_formatted}</strong> &bull; Belum Ada Catatan Absensi`;
                        document.querySelectorAll('#tbody-guru-absen .piket-radio--hadir').forEach(r => {
                            r.checked = true;
                        });
                        if (checkSemuaHadir) checkSemuaHadir.checked = true;
                    }
                } catch (e) {
                    console.error('Gagal mengambil data absensi:', e);
                }
            }

            if (dateInput) {
                dateInput.addEventListener('change', () => {
                    loadAbsenForDate(dateInput.value);
                });
            }

            // Tombol Edit pada setiap baris log
            document.querySelectorAll('.btn-edit-log').forEach(btn => {
                btn.addEventListener('click', () => {
                    const tgl = btn.getAttribute('data-tanggal');
                    if (dateInput) {
                        dateInput.value = tgl;
                    }
                    loadAbsenForDate(tgl);
                    if (modal) {
                        modal.classList.add('is-open');
                    }
                });
            });

            // Cek URL query param ?edit=YYYY-MM-DD jika diarahkan dari halaman detail
            const urlParams = new URLSearchParams(window.location.search);
            const editDate = urlParams.get('edit');
            if (editDate) {
                if (dateInput) dateInput.value = editDate;
                loadAbsenForDate(editDate);
                if (modal) modal.classList.add('is-open');
            }
        });
    </script>
</body>
</html>

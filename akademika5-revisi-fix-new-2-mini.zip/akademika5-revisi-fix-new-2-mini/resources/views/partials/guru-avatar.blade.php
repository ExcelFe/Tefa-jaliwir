{{-- Foto guru bila ada, jika tidak ada tampil avatar inisial. Param: $foto, $nama, $ukuran (px, opsional) --}}
@php
    $ukuranAvatar = $ukuran ?? 56;
@endphp
@if (!empty($foto))
    <img class="guru-avatar" src="{{ $foto }}" alt="Foto {{ $nama }}" width="{{ $ukuranAvatar }}" height="{{ $ukuranAvatar }}" loading="lazy" style="width: {{ $ukuranAvatar }}px; height: {{ $ukuranAvatar }}px;">
@else
    <span class="guru-avatar guru-avatar--inisial" role="img" aria-label="{{ $nama }}" style="width: {{ $ukuranAvatar }}px; height: {{ $ukuranAvatar }}px; font-size: {{ round($ukuranAvatar * 0.36) }}px;">{{ \App\Support\GuruFoto::inisial($nama) }}</span>
@endif

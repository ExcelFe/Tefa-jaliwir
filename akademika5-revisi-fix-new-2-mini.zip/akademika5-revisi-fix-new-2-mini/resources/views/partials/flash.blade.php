{{-- Pesan flash umum (error/info) untuk dashboard --}}
@if (session('error') || session('info'))
    <div role="alert" style="margin: 0 0 1rem; padding: 0.75rem 1rem; border-radius: 12px; font-size: 0.9rem; font-weight: 600; border: 1px solid {{ session('error') ? '#fca5a5' : '#93c5fd' }}; background: {{ session('error') ? '#fee2e2' : '#dbeafe' }}; color: {{ session('error') ? '#b91c1c' : '#1d4ed8' }};">
        {{ session('error') ?? session('info') }}
    </div>
@endif

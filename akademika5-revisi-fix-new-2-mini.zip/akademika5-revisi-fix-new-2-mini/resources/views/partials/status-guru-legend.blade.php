{{-- Legenda warna + jumlah per status guru. Param: $data (collection), $kolom (nama properti status) --}}
@php
    $hitungStatus = [];
    foreach (\App\Support\StatusGuru::DAFTAR as $slugStatus => $labelStatus) {
        $hitungStatus[$slugStatus] = $data->filter(
            fn ($d) => \App\Support\StatusGuru::slug($d->{$kolom}) === $slugStatus
        )->count();
    }
@endphp
<div class="status-legend">
    @foreach (\App\Support\StatusGuru::DAFTAR as $slugStatus => $labelStatus)
        <span class="status-chip status-chip--{{ $slugStatus }}">
            <span class="status-chip__dot"></span>{{ $labelStatus }}: <strong>{{ $hitungStatus[$slugStatus] }}</strong>
        </span>
    @endforeach
</div>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Guru - Dashboard Siswa - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        .date-filter-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: var(--space-2);
            padding: var(--space-3) var(--space-4);
            margin-bottom: var(--space-4);
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: var(--radius-md);
            box-shadow: var(--dash-shadow);
        }
        .date-filter-input {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.35rem 0.75rem;
            border-radius: var(--radius-pill);
            border: 1px solid var(--dash-edge);
            background: var(--dash-surface);
        }
        .date-filter-input input[type="date"] {
            border: none;
            background: transparent;
            font: inherit;
            color: var(--dash-ink);
            outline: none;
            font-size: 0.85rem;
            cursor: pointer;
        }
        .badge-status-pill {
            display: inline-block;
            padding: 0.2rem 0.65rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 700;
            text-transform: capitalize;
        }
        .badge-status--hadir {
            background: color-mix(in srgb, #22c55e 18%, transparent);
            color: #16a34a;
            border: 1px solid color-mix(in srgb, #22c55e 35%, transparent);
        }
        .badge-status--tidak-hadir {
            background: color-mix(in srgb, #ef4444 18%, transparent);
            color: #dc2626;
            border: 1px solid color-mix(in srgb, #ef4444 35%, transparent);
        }
        .badge-status--izin {
            background: color-mix(in srgb, #f59e0b 18%, transparent);
            color: #d97706;
            border: 1px solid color-mix(in srgb, #f59e0b 35%, transparent);
        }
        .badge-status--sakit {
            background: color-mix(in srgb, #3b82f6 18%, transparent);
            color: #2563eb;
            border: 1px solid color-mix(in srgb, #3b82f6 35%, transparent);
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu siswa">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman siswa">
                <a class="dash-menu__item" href="{{ route('siswa.jadwal') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
                <a class="dash-menu__item" href="{{ route('siswa.status') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" title="{{ $namaMurid }}" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">{{ $namaMurid }}</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">Kelas: {{ $kelas }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-siswa-status').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-siswa-status" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @include('partials.flash')
                <header class="dash-head">
                    <div class="dash-head__title">
                        <h1 class="dash-title">Status Guru</h1>
                    </div>
                    <div class="dash-tools">
                        <div class="dash-search" role="search">
                            <input type="search" placeholder="Search nama atau mapel..." aria-label="Cari guru" id="search-guru" oninput="filterGuruList()">
                            <img class="dash-icon" src="{{ asset('media/vector/search-icon.png') }}" alt="" width="24" height="24">
                        </div>
                        <button type="button" class="dash-icon-btn" aria-label="Filter Kehadiran" title="Klik untuk filter status: Semua → Hadir → Izin → Sakit → Alpa → Belum Diabsen" onclick="toggleFilterStatus()">
                            <img class="dash-icon" src="{{ asset('media/vector/filter-icon.png') }}" alt="" width="24" height="24">
                        </button>
                    </div>
                </header>

                <!-- Date Filter Bar -->
                <div class="date-filter-bar">
                    <div>
                        <div style="font-family: var(--font-heading); font-size: 1.15rem; text-transform: uppercase;">
                            {{ $tanggalFormatted }}
                        </div>
                        @include('partials.status-guru-legend', ['data' => $dataGuru, 'kolom' => 'status'])
                    </div>
                    <form method="GET" action="{{ route('siswa.status') }}" style="display: flex; align-items: center; gap: 0.5rem;">
                        <div class="date-filter-input">
                            <label for="filter-tanggal" style="font-size: 0.8rem; font-weight: 600; color: var(--dash-muted);">Pilih Tanggal:</label>
                            <input type="date" id="filter-tanggal" name="tanggal" value="{{ $tanggalPilihan }}" onchange="this.form.submit()">
                        </div>
                        <a href="{{ route('siswa.status') }}" class="dash-btn dash-btn--ghost" style="padding: 0.4rem 0.8rem; font-size: 0.8rem; text-decoration: none;">Hari Ini</a>
                    </form>
                </div>

                <!-- Teacher Status Cards from Database -->
                <ul class="dash-list" id="guru-status-list">
                    @forelse ($dataGuru as $guru)
                        @php $statusSlug = \App\Support\StatusGuru::slug($guru->status); @endphp
                        <li class="guru-item-card" data-nama="{{ strtolower($guru->nama . ' ' . $guru->mapel) }}" data-status="{{ $statusSlug }}" style="list-style: none;">
                            <div class="dash-jadwal-card dash-jadwal-card--st-{{ $statusSlug }}">
                                @include('partials.guru-avatar', ['foto' => $guru->foto, 'nama' => $guru->nama, 'ukuran' => 56])
                                <div class="dash-jadwal-card__info">
                                    <div style="display: flex; align-items: center; gap: 0.5rem; flex-wrap: wrap;">
                                        <span class="dash-jadwal-card__subject">{{ $guru->nama }}</span>
                                        <span class="status-pill status-pill--{{ $statusSlug }}">
                                            {{ $guru->status }}
                                        </span>
                                    </div>
                                    <span class="dash-jadwal-card__teacher" style="margin-top: 0.2rem;">
                                        Mata Pelajaran: <strong>{{ $guru->mapel }}</strong>
                                    </span>
                                </div>
                                <span class="dash-jadwal-card__time">
                                    {{ $guru->tanggal_formatted }}
                                </span>
                            </div>
                        </li>
                    @empty
                        <li class="dash-item">
                            <div class="dash-card">
                                <span class="dash-card__name">Belum ada data guru pada tanggal ini.</span>
                            </div>
                        </li>
                    @endforelse
                </ul>
            </div>
        </main>
    </div>

    <script>
        function filterGuruList() {
            const input = document.getElementById('search-guru');
            const filter = input.value.toLowerCase().trim();
            const items = document.querySelectorAll('.guru-item-card');

            items.forEach(item => {
                const nama = item.getAttribute('data-nama') || '';
                if (nama.indexOf(filter) > -1) {
                    item.style.display = '';
                } else {
                    item.style.display = 'none';
                }
            });
        }

        const urutanFilterStatus = ['all', 'hadir', 'izin', 'sakit', 'alpa', 'belum'];
        const labelFilterStatus = { all: 'Semua status', hadir: 'Hadir', izin: 'Izin', sakit: 'Sakit', alpa: 'Alpa', belum: 'Belum Diabsen' };
        let filterHadirState = 'all';
        function toggleFilterStatus() {
            const idx = urutanFilterStatus.indexOf(filterHadirState);
            filterHadirState = urutanFilterStatus[(idx + 1) % urutanFilterStatus.length];

            document.querySelectorAll('.guru-item-card').forEach(item => {
                const status = item.getAttribute('data-status');
                item.style.display = (filterHadirState === 'all' || filterHadirState === status) ? '' : 'none';
            });

            const tombol = document.querySelector('[onclick="toggleFilterStatus()"]');
            if (tombol) {
                tombol.setAttribute('title', 'Filter status: ' + labelFilterStatus[filterHadirState] + ' (klik untuk ganti)');
            }
        }
    </script>
</body>
</html>

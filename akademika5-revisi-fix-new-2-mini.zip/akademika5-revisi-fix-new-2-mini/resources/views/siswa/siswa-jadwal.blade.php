<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal Siswa - SMK TI Bali Global Badung</title>

    <link rel="stylesheet" href="{{ asset('css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('css/animation.css') }}">
    <script defer src="{{ asset('js/main.js') }}"></script>
    <script defer src="{{ asset('js/animation.js') }}"></script>
    <style>
        /* Header Profil Siswa */
        .student-profile-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            flex-wrap: wrap;
            margin-bottom: var(--space-3);
        }
        .student-profile-name-badge {
            display: inline-flex;
            align-items: center;
            gap: 0.65rem;
        }
        .student-profile-avatar {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: #1e293b;
            color: #ffffff;
            display: grid;
            place-items: center;
            flex-shrink: 0;
        }
        [data-theme="dark"] .student-profile-avatar {
            background: #3b82f6;
        }
        .student-profile-name {
            font-family: var(--font-heading);
            font-size: clamp(1.2rem, 2.8vw, 1.65rem);
            font-weight: 400;
            letter-spacing: 0.03em;
            color: var(--dash-ink);
            text-transform: uppercase;
        }
        .student-profile-date {
            font-size: 0.825rem;
            font-weight: 600;
            color: #3b82f6;
            margin-left: 0.25rem;
        }

        /* Section Title Anton */
        .schedule-main-heading {
            font-family: var(--font-heading);
            font-size: clamp(1.35rem, 3.2vw, 1.85rem);
            font-weight: 400;
            letter-spacing: 0.02em;
            color: var(--dash-ink);
            text-transform: uppercase;
            margin: 0 0 var(--space-3) 0;
        }

        /* Hero Schedule Container (Outer Card matching dashboard surface) */
        .hero-schedule-wrapper {
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: 22px;
            padding: 16px;
            box-shadow: var(--dash-shadow);
            margin-bottom: var(--space-4);
            transition: all 0.2s ease;
        }

        /* Hero Schedule Card (Inner Card matching reference layout) */
        .hero-schedule-card {
            background: radial-gradient(circle at 92% 25%, rgba(59, 130, 246, 0.12) 0%, rgba(255, 255, 255, 0) 55%), #ffffff;
            border: 1.5px solid #3b82f6;
            border-radius: 16px;
            padding: 22px 26px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: var(--space-4);
            margin-bottom: 0;
            transition: all 0.2s ease;
        }
        [data-theme="dark"] .hero-schedule-wrapper {
            background: var(--dash-surface);
            border-color: var(--dash-edge);
        }
        [data-theme="dark"] .hero-schedule-card {
            background: radial-gradient(circle at 92% 25%, rgba(96, 165, 250, 0.16) 0%, rgba(37, 47, 66, 0) 55%), var(--dash-surface);
            border-color: #60a5fa;
        }
        .hero-schedule-card__left {
            flex: 1;
            min-width: 0;
        }
        .hero-schedule-card__kicker-row {
            display: flex;
            align-items: center;
            gap: 0.65rem;
            margin-bottom: 0.4rem;
        }
        .hero-schedule-card__kicker {
            font-weight: 800;
            font-size: 0.88rem;
            color: #2563eb;
        }
        [data-theme="dark"] .hero-schedule-card__kicker {
            color: #60a5fa;
        }
        .hero-schedule-card__jam-badge {
            background: var(--dash-surface);
            color: var(--dash-muted);
            border: 1px solid var(--dash-edge);
            padding: 0.15rem 0.65rem;
            border-radius: var(--radius-pill);
            font-size: 0.75rem;
            font-weight: 600;
        }
        [data-theme="dark"] .hero-schedule-card__jam-badge {
            background: rgba(255, 255, 255, 0.1);
            border-color: rgba(255, 255, 255, 0.2);
            color: #cbd5e1;
        }
        .hero-schedule-card__time {
            font-size: 0.85rem;
            color: var(--dash-muted);
            margin-bottom: 0.35rem;
            font-weight: 500;
        }
        .hero-schedule-card__subject {
            font-family: var(--font-heading);
            font-size: clamp(1.6rem, 3.8vw, 2.35rem);
            font-weight: 400;
            line-height: 1.15;
            letter-spacing: 0.02em;
            text-transform: uppercase;
            color: var(--dash-ink);
            margin: 0 0 0.5rem 0;
        }
        .hero-schedule-card__status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.85rem;
            font-weight: 600;
            color: var(--dash-ink);
        }
        .hero-status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
        }
        .hero-status-dot--ongoing {
            background: #16a34a;
            box-shadow: 0 0 0 4px rgba(22, 163, 74, 0.25);
        }
        .hero-status-dot--upcoming {
            background: #f59e0b;
            box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.25);
        }
        .hero-status-dot--finished {
            background: #2563eb;
            box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.25);
        }

        /* Kotak Pengajar sebelah kanan */
        .hero-schedule-card__right {
            flex-shrink: 0;
            text-align: center;
            padding: 0.25rem 0.5rem;
            min-width: 130px;
        }
        .hero-teacher-heading {
            display: block;
            font-size: 0.75rem;
            font-weight: 800;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: var(--dash-ink);
            margin-bottom: 0.4rem;
        }
        .hero-teacher-squircle {
            width: 78px;
            height: 86px;
            border: 1.5px dashed #60a5fa;
            border-radius: 16px;
            margin: 0 auto 0.45rem auto;
            display: grid;
            place-items: center;
            background: rgba(59, 130, 246, 0.05);
            color: #2563eb;
        }
        [data-theme="dark"] .hero-teacher-squircle {
            background: rgba(96, 165, 250, 0.12);
            border-color: rgba(96, 165, 250, 0.45);
            color: #60a5fa;
        }
        .hero-teacher-squircle--foto {
            border-style: solid;
            padding: 0;
            overflow: hidden;
        }
        .hero-teacher-squircle--foto img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: top center;
            display: block;
        }
        .hero-teacher-name {
            font-size: 0.78rem;
            font-weight: 700;
            color: var(--dash-ink);
            line-height: 1.25;
            max-width: 140px;
            margin: 0 auto 0.4rem auto;
        }
        .hero-teacher-badge {
            display: inline-block;
            padding: 0.18rem 0.75rem;
            border-radius: var(--radius-pill);
            font-size: 0.72rem;
            font-weight: 700;
        }
        .hero-teacher-badge--hadir {
            background: #dcfce7;
            color: #15803d;
            border: 1px solid color-mix(in srgb, #22c55e 30%, transparent);
        }
        .hero-teacher-badge--tidak {
            background: #fee2e2;
            color: #dc2626;
            border: 1px solid color-mix(in srgb, #ef4444 30%, transparent);
        }
        .hero-teacher-badge--izin {
            background: #fef9c3;
            color: #a16207;
            border: 1px solid #fde047;
        }
        .hero-teacher-badge--sakit {
            background: #ede9fe;
            color: #6d28d9;
            border: 1px solid #c4b5fd;
        }

        /* Banner info kelas milik siswa */
        .student-class-info-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: var(--space-2);
            padding: var(--space-3) var(--space-4);
            margin-bottom: var(--space-4);
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            border-radius: var(--radius-md);
            box-shadow: var(--dash-shadow);
        }
        .pdf-btn {
            display: inline-flex;
            align-items: center;
            gap: 0.35rem;
            padding: 0.35rem 0.75rem;
            font-size: 0.8rem;
            font-weight: 600;
            border-radius: var(--radius-pill);
            background: var(--dash-surface);
            border: 1px solid var(--dash-edge);
            color: var(--dash-ink);
            text-decoration: none;
            transition: all 0.15s ease;
        }
        .pdf-btn:hover {
            border-color: var(--dash-accent);
            color: var(--dash-accent);
            background: var(--dash-hover);
        }
    </style>
</head>
<body class="dash-body">
    <div class="dash">
        <!-- Dimmed area behind the sidebar on tablet/phone (click closes it) -->
        <div class="dash-scrim" data-sidebar-close></div>

        <!-- Sidebar: minimize + brand (top) | page menu (middle) | account + settings (bottom) -->
        <aside class="dash-sidebar" id="sidebar" aria-label="Menu siswa">
            <div class="dash-sidebar__top">
                <button type="button" class="dash-icon-btn" data-sidebar-close aria-label="Tutup sidebar">
                    <img class="dash-icon" src="{{ asset('media/vector/minimize-icon.png') }}" alt="" width="24" height="24">
                </button>
                <span class="dash-brand">Globaliti Badung</span>
            </div>

            <nav class="dash-menu" aria-label="Halaman siswa">
                <a class="dash-menu__item" href="{{ route('siswa.jadwal') }}" aria-current="page">
                    <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="24" height="24">
                    Jadwal
                </a>
                <a class="dash-menu__item" href="{{ route('siswa.status') }}">
                    <img class="dash-icon" src="{{ asset('media/vector/status-icon.png') }}" alt="" width="24" height="24">
                    Status Guru
                </a>
            </nav>

            <div class="dash-account" style="display: flex; align-items: center; justify-content: space-between; gap: 0.5rem;">
                <div class="dash-account__info" style="display: flex; align-items: center; gap: 0.65rem; min-width: 0; flex: 1; overflow: hidden;">
                    <span class="dash-avatar" style="flex-shrink: 0;"><img class="dash-icon" src="{{ asset('media/vector/absensi-icon.png') }}" alt="" width="24" height="24"></span>
                    <div style="min-width: 0; flex: 1; overflow: hidden; display: flex; flex-direction: column;">
                        <span class="dash-account__name" title="{{ $namaMurid }}" style="display: block; font-weight: 700; text-transform: uppercase; font-size: 0.8rem; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; line-height: 1.25;">{{ $namaMurid }}</span>
                        <span style="font-size: 0.72rem; color: var(--dash-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; margin-top: 0.15rem;">Kelas: {{ $kelas }}</span>
                    </div>
                </div>
                <button type="button" class="dash-icon-btn" data-settings-toggle aria-label="Pengaturan" aria-expanded="false" aria-controls="settings-menu" style="flex-shrink: 0; margin-left: 0.25rem;">
                    <img class="dash-icon" src="{{ asset('media/vector/setting-icon.png') }}" alt="" width="24" height="24">
                </button>

                <!-- Settings menu: opens above the account container -->
                <div class="dash-settings" id="settings-menu">
                    <button type="button" class="dash-settings__item" role="switch" aria-checked="false" data-theme-toggle>
                        <img class="dash-icon dash-icon--light" src="{{ asset('media/vector/lightmode-icon.png') }}" alt="" width="24" height="24">
                        <img class="dash-icon dash-icon--dark" src="{{ asset('media/vector/darkmode-icon.png') }}" alt="" width="24" height="24">
                        Appearance Mode
                        <span class="dash-switch" aria-hidden="true"></span>
                    </button>

                    <!-- Learn More: sub-menu shows on hover, to the right -->
                    <div class="dash-learn">
                        <button type="button" class="dash-settings__item" aria-haspopup="true">
                            <img class="dash-icon" src="{{ asset('media/vector/info-icon.png') }}" alt="" width="24" height="24">
                            Learn More
                            <img class="dash-icon dash-icon--end" src="{{ asset('media/vector/right-arrow-icon.png') }}" alt="" width="24" height="24">
                        </button>
                        <div class="dash-submenu">
                            <div class="dash-submenu__box">
                                <a class="dash-settings__item" href="#">Kebijakan Privasi</a>
                                <a class="dash-settings__item" href="#">Syarat &amp; Ketentuan</a>
                                <a class="dash-settings__item" href="#">Panduan Pengguna</a>
                            </div>
                        </div>
                    </div>

                    <!-- Log Out -->
                    <a class="dash-settings__item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form-siswa-jadwal').submit();">
                        <img class="dash-icon" src="{{ asset('media/vector/log-out-icon.png') }}" alt="" width="24" height="24">
                        Log Out
                    </a>
                    <form id="logout-form-siswa-jadwal" action="{{ route('logout') }}" method="POST" style="display:none;">
                        @csrf
                    </form>
                </div>
            </div>
        </aside>

        <!-- Shown while the sidebar is closed (always above the page on tablet/phone) -->
        <div class="dash-topbar">
            <button type="button" class="dash-icon-btn" data-sidebar-open aria-label="Buka sidebar" aria-expanded="true" aria-controls="sidebar">
                <img class="dash-icon" src="{{ asset('media/vector/maximize-icon.png') }}" alt="" width="24" height="24">
            </button>
            <div class="dash-brand-closed">Globaliti Badung</div>
        </div>

        <main class="dash-main">
            <div class="dash-content">
                @include('partials.flash')

                <!-- 1. IDENTITAS SISWA DI KONTEN: NAMA ASLI & TANGGAL HARI INI -->
                <div class="student-profile-header">
                    <div class="student-profile-name-badge">
                        <div class="student-profile-avatar">
                            <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                            </svg>
                        </div>
                        <h1 class="student-profile-name">{{ $namaMurid }}</h1>
                    </div>
                    <span class="student-profile-date">{{ $tanggalHariIni }}</span>
                </div>

                <!-- 2. JUDUL SECTION: JADWAL HARI INI (PER KELAS) -->
                <h2 class="schedule-main-heading">JADWAL HARI INI (PER KELAS)</h2>

                <!-- 3. HERO CARD JADWAL REAL-TIME HARI INI (CURRENT / UPCOMING LESSON) -->
                @if ($heroJadwal)
                    <div class="hero-schedule-wrapper">
                        <div class="hero-schedule-card">
                            <div class="hero-schedule-card__left">
                                <div class="hero-schedule-card__kicker-row">
                                    <span class="hero-schedule-card__kicker">{{ $heroJadwal->kicker }}</span>
                                    <span class="hero-schedule-card__jam-badge">jam ke {{ $heroJadwal->jam_ke }}</span>
                                </div>
                                <div class="hero-schedule-card__time">{{ $heroJadwal->waktu }}</div>
                                <h3 class="hero-schedule-card__subject">{{ $heroJadwal->mapel }}</h3>
                                <div class="hero-schedule-card__status">
                                    <span class="hero-status-dot hero-status-dot--{{ $heroJadwal->status_slug }}"></span>
                                    <span>{{ $heroJadwal->status_text }}</span>
                                </div>
                            </div>

                            <div class="hero-schedule-card__right">
                                <span class="hero-teacher-heading">PENGAJAR</span>
                                <div class="hero-teacher-squircle {{ !empty($heroJadwal->foto) ? 'hero-teacher-squircle--foto' : '' }}">
                                    @if (!empty($heroJadwal->foto))
                                        <img src="{{ $heroJadwal->foto }}" alt="Foto {{ $heroJadwal->guru }}">
                                    @else
                                        <svg width="34" height="34" viewBox="0 0 24 24" fill="currentColor">
                                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                                        </svg>
                                    @endif
                                </div>
                                <div class="hero-teacher-name">{{ $heroJadwal->guru }}</div>
                                @php
                                    $statusGuruLower = strtolower($heroJadwal->status_guru);
                                    $statusBadgeClass = match($statusGuruLower) {
                                        'hadir' => 'hadir',
                                        'tidak hadir', 'alpa' => 'tidak',
                                        'izin' => 'izin',
                                        'sakit' => 'sakit',
                                        default => 'hadir',
                                    };
                                @endphp
                                <span class="hero-teacher-badge hero-teacher-badge--{{ $statusBadgeClass }}">
                                    {{ $heroJadwal->status_guru }}
                                </span>
                            </div>
                        </div>
                    </div>
                @else
                    <div class="hero-schedule-wrapper">
                        <div class="hero-schedule-card">
                            <div class="hero-schedule-card__left">
                                <div class="hero-schedule-card__kicker-row">
                                    <span class="hero-schedule-card__kicker">Informasi Jadwal</span>
                                </div>
                                <h3 class="hero-schedule-card__subject">Tidak Ada Jadwal Hari Ini</h3>
                                <div class="hero-schedule-card__time">Hari ini tidak ada kegiatan belajar mengajar aktif untuk kelas Anda.</div>
                            </div>
                        </div>
                    </div>
                @endif

                <!-- 4. BANNER INFO KELAS ANDA & DOWNLOAD PDF -->
                <div class="student-class-info-bar">
                    <div style="display: flex; align-items: center; gap: 0.6rem;">
                        <span style="font-size: 0.9rem; color: var(--dash-muted);">Jadwal Kelas:</span>
                        <span style="display: inline-block; padding: 0.2rem 0.75rem; border-radius: var(--radius-pill); background: color-mix(in srgb, var(--dash-accent) 15%, transparent); color: var(--dash-accent); font-weight: 700; font-size: 0.9rem;">
                            {{ $kelas }}
                        </span>
                    </div>

                    <div>
                        @if (str_starts_with($kelas, 'X ') || $kelas === 'X')
                            <a href="{{ asset('jadwal/jadwal-siang.pdf') }}" target="_blank" rel="noopener" class="pdf-btn" title="Download Jadwal Lengkap Kelas X (Siang)">
                                <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="16" height="16" style="width: 1rem; height: 1rem;">
                                Download PDF Jadwal (Kelas X Sesi Siang)
                            </a>
                        @else
                            <a href="{{ asset('jadwal/jadwal-pagi.pdf') }}" target="_blank" rel="noopener" class="pdf-btn" title="Download Jadwal Lengkap Kelas XI & XII (Pagi)">
                                <img class="dash-icon" src="{{ asset('media/vector/jadwal-icon.png') }}" alt="" width="16" height="16" style="width: 1rem; height: 1rem;">
                                Download PDF Jadwal (Kelas XI &amp; XII Sesi Pagi)
                            </a>
                        @endif
                    </div>
                </div>

                <!-- 5. DAFTAR JADWAL MINGGUAN KELAS SISWA & TAB HARI -->
                <section class="dash-section" aria-labelledby="jadwal-mingguan">
                    <div style="display: flex; justify-content: space-between; align-items: baseline; margin-bottom: var(--space-2);">
                        <h2 class="dash-subtitle" id="jadwal-mingguan" style="margin: 0;">
                            Jadwal Hari {{ ucfirst($hariPilihan) }}
                        </h2>
                        <span style="font-size: 0.85rem; color: var(--dash-muted);">
                            Total Mapel: <strong>{{ $jadwalList->count() }}</strong>
                        </span>
                    </div>

                    <!-- Day-of-week tabs (Senin - Jumat) -->
                    <div class="dash-daytabs" role="tablist" aria-label="Pilih hari">
                        @foreach (['senin' => 'Senin', 'selasa' => 'Selasa', 'rabu' => 'Rabu', 'kamis' => 'Kamis', 'jumat' => 'Jumat'] as $key => $label)
                            <a href="{{ route('siswa.jadwal', ['hari' => $key]) }}"
                               class="dash-daytab {{ $hariPilihan === $key ? 'is-active' : '' }}"
                               role="tab"
                               aria-selected="{{ $hariPilihan === $key ? 'true' : 'false' }}"
                               style="text-decoration: none; display: inline-flex; align-items: center; justify-content: center;">
                                {{ $label }}
                            </a>
                        @endforeach
                    </div>

                    <!-- List Kartu Jadwal Pelajaran -->
                    <ul class="dash-list">
                        @forelse ($jadwalList as $jadwal)
                            <li>
                                <div class="dash-jadwal-card {{ $jadwal->is_ongoing ? 'dash-jadwal-card--on' : ($jadwal->is_finished ? 'dash-jadwal-card--done' : 'dash-jadwal-card--off') }}">
                                    @include('partials.guru-avatar', ['foto' => $jadwal->foto, 'nama' => $jadwal->guru, 'ukuran' => 52])
                                    <div class="dash-jadwal-card__info">
                                        <div style="display: flex; align-items: center; gap: 0.6rem; flex-wrap: wrap;">
                                            <span class="dash-jadwal-card__subject">{{ $jadwal->mapel }}</span>
                                            <span style="font-size: 0.75rem; padding: 0.15rem 0.5rem; border-radius: var(--radius-pill); font-weight: 600; background: var(--dash-hover); color: var(--dash-muted);">
                                                {{ $jadwal->jam_ke }}
                                            </span>
                                            @if ($jadwal->is_ongoing)
                                                <span style="font-size: 0.75rem; padding: 0.15rem 0.5rem; border-radius: var(--radius-pill); font-weight: 600; background: color-mix(in srgb, #22c55e 20%, transparent); color: #16a34a;">
                                                    ● Sedang Berlangsung
                                                </span>
                                            @elseif ($jadwal->is_finished)
                                                <span class="tag-selesai">✓ Selesai</span>
                                            @endif
                                        </div>
                                        <span class="dash-jadwal-card__teacher" style="margin-top: 0.25rem;">
                                            Pengajar: <strong>{{ $jadwal->guru }}</strong>
                                        </span>
                                    </div>
                                    <span class="dash-jadwal-card__time">
                                        {{ $jadwal->waktu }}
                                    </span>
                                </div>
                            </li>
                        @empty
                            <li class="dash-item">
                                <div class="dash-card">
                                    <span class="dash-card__name">Tidak ada jadwal pelajaran untuk kelas Anda pada hari {{ ucfirst($hariPilihan) }}.</span>
                                </div>
                            </li>
                        @endforelse
                    </ul>
                </section>
            </div>
        </main>
    </div>
</body>
</html>
